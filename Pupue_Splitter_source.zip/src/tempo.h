/*
 * Tempo (BPM) + beat phase estimation from a mono signal.
 * Spectral-flux onset envelope -> autocorrelation with a tempo prior
 * (log-normal around 120 BPM) -> fine period search with a comb filter
 * -> phase of the beat grid.
 */
#pragma once
#include <vector>
#include <complex>
#include <cmath>

namespace tempo
{

static void fft(std::vector<std::complex<float>> &a)
{
	size_t n = a.size();
	for (size_t i = 1, j = 0; i < n; ++i)
	{
		size_t bit = n >> 1;
		for (; j & bit; bit >>= 1) j ^= bit;
		j ^= bit;
		if (i < j) std::swap(a[i], a[j]);
	}
	for (size_t len = 2; len <= n; len <<= 1)
	{
		float ang = -2.f * 3.14159265358979f / (float)len;
		std::complex<float> wl(std::cos(ang), std::sin(ang));
		for (size_t i = 0; i < n; i += len)
		{
			std::complex<float> w(1, 0);
			for (size_t k = 0; k < len / 2; ++k)
			{
				std::complex<float> u = a[i + k], v = a[i + k + len / 2] * w;
				a[i + k] = u + v;
				a[i + k + len / 2] = u - v;
				w *= wl;
			}
		}
	}
}

struct Result
{
	double bpm = 0;       // 0 = not found
	double firstBeat = 0; // seconds: a beat falls here (and every 60/bpm s around it)
	double confidence = 0;
};

// mono: samples at `rate` (any rate; downsampled internally)
static Result estimate(const std::vector<float> &mono, unsigned rate)
{
	Result res;
	// ---- downsample to ~11 kHz
	int dec = std::max(1, (int)(rate / 11025));
	double sr = (double)rate / dec;
	std::vector<float> x(mono.size() / dec);
	for (size_t i = 0; i < x.size(); ++i)
	{
		float s = 0;
		for (int k = 0; k < dec; ++k) s += mono[i * dec + k];
		x[i] = s / dec;
	}
	const int N = 1024, HOP = 128;
	if (x.size() < (size_t)N * 8) return res;
	size_t nFrames = (x.size() - N) / HOP;
	double envRate = sr / HOP;
	// ---- onset envelope (log-magnitude spectral flux)
	std::vector<float> win(N);
	for (int i = 0; i < N; ++i) win[i] = 0.5f - 0.5f * std::cos(2 * 3.14159265358979f * i / N);
	std::vector<float> prev(N / 2, 0.f), env(nFrames, 0.f);
	std::vector<std::complex<float>> buf(N);
	for (size_t f = 0; f < nFrames; ++f)
	{
		for (int i = 0; i < N; ++i) buf[i] = std::complex<float>(x[f * HOP + i] * win[i], 0);
		fft(buf);
		float flux = 0;
		for (int b = 1; b < N / 2; ++b)
		{
			float m = std::log1p(1000.f * std::abs(buf[b]));
			float d = m - prev[b];
			if (d > 0 && f > 0) flux += d;
			prev[b] = m;
		}
		env[f] = flux;
	}
	// remove the slow trend (local mean over ~0.4 s), half-wave rectify, normalize
	{
		int W = std::max(1, (int)(0.2 * envRate));
		std::vector<double> cs(nFrames + 1, 0);
		for (size_t i = 0; i < nFrames; ++i) cs[i + 1] = cs[i] + env[i];
		std::vector<float> e2(nFrames);
		double sum = 0;
		for (size_t i = 0; i < nFrames; ++i)
		{
			size_t a = i > (size_t)W ? i - W : 0, b = std::min(nFrames, i + W + 1);
			float mean = (float)((cs[b] - cs[a]) / (b - a));
			e2[i] = std::max(0.f, env[i] - mean);
			sum += e2[i] * e2[i];
		}
		if (sum <= 0) return res;
		float nrm = (float)(1.0 / std::sqrt(sum / nFrames));
		for (auto &v : e2) v *= nrm;
		env.swap(e2);
	}
	// ---- autocorrelation over 40..240 BPM with a tempo prior
	int lagMin = (int)std::floor(envRate * 60.0 / 240.0), lagMax = (int)std::ceil(envRate * 60.0 / 40.0);
	if ((size_t)lagMax * 3 >= nFrames) return res;
	std::vector<double> ac(lagMax + 2, 0);
	for (int L = lagMin - 1; L <= lagMax + 1; ++L)
	{
		double s = 0;
		for (size_t i = 0; i + L < nFrames; ++i) s += env[i] * env[i + L];
		ac[L] = s / (nFrames - L);
	}
	// harmonic-enhanced score: lag L also supported by 2L and L/2 ... ; prior around 120 BPM (1 octave sigma)
	auto score = [&](double L) -> double {
		auto acAt = [&](double l) -> double {
			if (l < lagMin - 1 || l > lagMax + 1) return 0;
			int i = (int)l; double fr = l - i;
			return ac[i] * (1 - fr) + (i + 1 <= lagMax + 1 ? ac[i + 1] : 0) * fr;
		};
		double bpm = 60.0 * envRate / L;
		double oct = std::log2(bpm / 120.0);
		double prior = std::exp(-0.5 * oct * oct / (0.9 * 0.9));
		return (acAt(L) + 0.5 * acAt(2 * L) + 0.25 * acAt(L / 2)) * prior;
	};
	double best = -1, bestL = 0;
	for (int L = lagMin; L <= lagMax; ++L)
	{
		double s = score(L);
		if (s > best) { best = s; bestL = L; }
	}
	if (best <= 0) return res;
	// ---- fine search: comb filter energy over the whole excerpt for periods around bestL
	auto comb = [&](double P, double *phaseOut) -> double {
		int steps = std::max(8, (int)(P * 2));
		double bestS = -1, bestPh = 0;
		for (int k = 0; k < steps; ++k)
		{
			double ph = P * k / steps, s = 0;
			int cnt = 0;
			for (double t = ph; t < nFrames - 1; t += P)
			{
				int i = (int)t; double fr = t - i;
				s += env[i] * (1 - fr) + env[i + 1] * fr;
				++cnt;
			}
			s /= std::max(1, cnt);
			if (s > bestS) { bestS = s; bestPh = ph; }
		}
		if (phaseOut) *phaseOut = bestPh;
		return bestS;
	};
	// fine period search around a lag
	auto refine = [&](double L0, double &cOut) -> double {
		double bp = L0, bc = -1;
		for (double P = L0 * 0.96; P <= L0 * 1.04; P += 0.02)
		{
			double c = comb(P, nullptr);
			if (c > bc) { bc = c; bp = P; }
		}
		for (double P = bp - 0.02; P <= bp + 0.02; P += 0.004)
		{
			double c = comb(P, nullptr);
			if (c > bc) { bc = c; bp = P; }
		}
		cOut = bc;
		return bp;
	};
	auto gridMean = [&](double P, double ph) -> double {
		double s = 0; int cnt = 0;
		for (double t = ph; t < nFrames - 1; t += P)
		{
			int i = (int)t; double fr = t - i;
			s += env[i] * (1 - fr) + env[i + 1] * fr;
			++cnt;
		}
		return cnt ? s / cnt : 0;
	};
	double bestC;
	double bestP = refine(bestL, bestC);
	// "2/3" error: the grid lands on every other beat and the off-beats between them.
	// Then both third-points of the period are as strong as the grid itself -> real beat is 2/3 of it.
	{
		double ph0;
		double S = comb(bestP, &ph0);
		double T1 = gridMean(bestP, ph0 + bestP / 3), T2 = gridMean(bestP, ph0 + 2 * bestP / 3);
		double fast = 60.0 * envRate / (bestP * 2 / 3);
		if (getenv("BPMDBG")) fprintf(stderr, "bpm %.2f S %.3f T1 %.3f T2 %.3f half %.3f\n", 60.0 * envRate / bestP, S, T1, T2, gridMean(bestP, ph0 + bestP / 2));
		if (std::min(T1, T2) >= 0.5 * S && fast <= 210)
		{
			double c2;
			bestP = refine(bestP * 2 / 3, c2);
			bestC = c2;
		}
	}
	// half-time error: the off-beats are as strong as the beats -> double the tempo
	{
		double ph0;
		double S = comb(bestP, &ph0);
		double Hm = gridMean(bestP, ph0 + bestP / 2);
		double fast = 60.0 * envRate / (bestP / 2);
		if (Hm >= 0.85 * S && fast <= 200)
		{
			double c2;
			bestP = refine(bestP / 2, c2);
			bestC = c2;
		}
	}
	double ph = 0;
	comb(bestP, &ph);
	res.bpm = 60.0 * envRate / bestP;
	// envelope frame f covers samples [f*HOP, f*HOP+N); the flux peaks around the frame centre
	res.firstBeat = (ph * HOP + N * 0.5) / sr;
	// confidence: comb peak vs. average envelope (=1 after normalization... use mean)
	double mean = 0;
	for (float v : env) mean += v;
	mean /= nFrames;
	res.confidence = mean > 0 ? bestC / mean : 0;
	// snap to a near-integer BPM (game music is nearly always an integer tempo)
	double r = std::round(res.bpm);
	if (std::fabs(res.bpm - r) < 0.15 && r > 0)
	{
		res.bpm = r;
		comb(60.0 * envRate / r, &ph);
		res.firstBeat = (ph * HOP + N * 0.5) / sr;
	}
	return res;
}

} // namespace tempo
