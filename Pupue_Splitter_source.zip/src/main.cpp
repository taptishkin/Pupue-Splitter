/*
 * mini2sf Splitter
 * Drag a .mini2sf (or .2sf) file onto the exe: every SSEQ track of the
 * sequence is rendered to its own WAV next to the source file.
 *
 * Sequencer/sound engine: SSEQ Player by Naram Qashat (CyberBotX),
 * based on FeOS Sound System by fincs (WTFPL). Decompression: zlib.
 */

#include <cstdio>
#include <cstdarg>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include <filesystem>
#include <functional>
#include <atomic>

#include "zlib.h"
#include "sseqplayer/SDAT.h"
#include "sseqplayer/Player.h"
#include "sseqplayer/common.h"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace fs = std::filesystem;

#ifdef KEYLOG
static size_t g_frame = 0;
static bool g_log = false;
void keylog_hook(int ch, unsigned timer, int fmt, int trk, int base, int tune, int sp, int sl, int md)
{
	if (g_log) fprintf(stderr, "%zu %d %u %d %d %d %d %d %d %d\n", g_frame, ch, timer & 0xFFFF, fmt, trk, base, tune, sp, sl, md);
}
#endif
static const char *APP_NAME = "Pupue Splitter 3.2 (Nintendo DS .mini2sf / PlayStation .minipsf / Game Boy Advance .minigsf / Nintendo 64 .miniusf / SNES .spc / Mega Drive .vgm / NES .nsf / Game Boy .gbs)";

// ---------------------------------------------------------------- console / log
struct Cancelled : std::exception { const char *what() const noexcept override { return "cancelled"; } };
static std::function<void(const std::string &)> g_outSink; // set by the GUI: receives all log text
static thread_local bool t_quiet = false;
static thread_local std::function<void(const std::string &)> *t_sink = nullptr; // per-thread log (GUI background jobs)
static thread_local double t_songSeconds = 0;                                     // song length incl. fade, set by every format                   // preview thread: no log output
static thread_local std::atomic<bool> *t_cancel = nullptr;  // worker thread: cancel request

static void out(const std::string &s)
{
	if (t_cancel && t_cancel->load()) throw Cancelled();
	if (t_quiet) return;
	if (t_sink) { (*t_sink)(s); return; }
	if (g_outSink) { g_outSink(s); return; }
#ifdef _WIN32
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	DWORD mode;
	if (h != INVALID_HANDLE_VALUE && GetConsoleMode(h, &mode))
	{
		int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
		std::wstring w(n, L'\0');
		MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
		DWORD written;
		WriteConsoleW(h, w.data(), (DWORD)w.size(), &written, nullptr);
		return;
	}
#endif
	fwrite(s.data(), 1, s.size(), stdout);
	fflush(stdout);
}

static std::string u8(const fs::path &p)
{
	auto s = p.u8string();
	return std::string(s.begin(), s.end());
}

static std::string fmt(const char *f, ...)
{
	char buf[2048];
	va_list ap;
	va_start(ap, f);
	vsnprintf(buf, sizeof(buf), f, ap);
	va_end(ap);
	return buf;
}

// ---------------------------------------------------------------- file io
static FILE *openFile(const fs::path &p, const char *mode)
{
#ifdef _WIN32
	std::wstring m(mode, mode + strlen(mode));
	return _wfopen(p.c_str(), m.c_str());
#else
	return fopen(p.c_str(), mode);
#endif
}

static std::vector<uint8_t> readFile(const fs::path &p)
{
	FILE *f = openFile(p, "rb");
	if (!f)
		throw std::runtime_error("cannot open file: " + u8(p));
	std::vector<uint8_t> d;
	uint8_t buf[65536];
	size_t n;
	while ((n = fread(buf, 1, sizeof(buf), f)) > 0)
		d.insert(d.end(), buf, buf + n);
	fclose(f);
	return d;
}

static inline uint32_t rd32(const uint8_t *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24); }
static inline uint16_t rd16(const uint8_t *p) { return p[0] | (p[1] << 8); }

// ---------------------------------------------------------------- PSF / 2SF
struct Patch
{
	uint32_t offset;
	std::vector<uint8_t> data;
};

struct PSFFile
{
	uint8_t version = 0;
	std::vector<uint8_t> program; // raw decompressed program (PSF1: PS-X EXE)
	std::vector<Patch> patches;   // 2SF: parsed program blocks
	std::vector<uint8_t> reserved; // reserved area (USF: ROM/state chunks)
	std::map<std::string, std::string> tags;
};

static std::string lower(std::string s)
{
	for (auto &c : s)
		c = (char)tolower((unsigned char)c);
	return s;
}

static std::string trim(const std::string &s)
{
	size_t a = 0, b = s.size();
	while (a < b && (unsigned char)s[a] <= 32) ++a;
	while (b > a && (unsigned char)s[b - 1] <= 32) --b;
	return s.substr(a, b - a);
}

static std::vector<uint8_t> inflateAll(const uint8_t *src, size_t len)
{
	std::vector<uint8_t> outBuf;
	z_stream zs;
	memset(&zs, 0, sizeof(zs));
	if (inflateInit(&zs) != Z_OK)
		throw std::runtime_error("zlib init failed");
	zs.next_in = const_cast<Bytef *>(src);
	zs.avail_in = (uInt)len;
	std::vector<uint8_t> chunk(1 << 20);
	int ret;
	do
	{
		zs.next_out = chunk.data();
		zs.avail_out = (uInt)chunk.size();
		ret = inflate(&zs, Z_NO_FLUSH);
		if (ret != Z_OK && ret != Z_STREAM_END)
		{
			inflateEnd(&zs);
			throw std::runtime_error("corrupt compressed data in file");
		}
		outBuf.insert(outBuf.end(), chunk.data(), chunk.data() + (chunk.size() - zs.avail_out));
	} while (ret != Z_STREAM_END);
	inflateEnd(&zs);
	return outBuf;
}

static PSFFile readPSF(const fs::path &p, uint8_t expectVersion = 0x24)
{
	auto d = readFile(p);
	if (d.size() < 16 || memcmp(d.data(), "PSF", 3) != 0)
		throw std::runtime_error("not a PSF-family file: " + u8(p));
	if (d[3] != expectVersion)
		throw std::runtime_error("unexpected file type (PSF version byte) in: " + u8(p));
	uint32_t rsz = rd32(&d[4]), psz = rd32(&d[8]);
	if (16ull + rsz + psz > d.size())
		throw std::runtime_error("truncated 2SF file: " + u8(p));
	PSFFile f;
	f.version = d[3];
	f.reserved.assign(d.begin() + 16, d.begin() + 16 + rsz);
	if (psz && expectVersion != 0x24)
		f.program = inflateAll(&d[16 + rsz], psz);
	else if (psz)
	{
		auto prog = inflateAll(&d[16 + rsz], psz);
		size_t pos = 0;
		while (pos + 8 <= prog.size())
		{
			uint32_t off = rd32(&prog[pos]), sz = rd32(&prog[pos + 4]);
			pos += 8;
			if (pos + sz > prog.size())
				sz = (uint32_t)(prog.size() - pos);
			Patch pt;
			pt.offset = off;
			pt.data.assign(prog.begin() + pos, prog.begin() + pos + sz);
			f.patches.push_back(std::move(pt));
			pos += sz;
		}
	}
	size_t tagPos = 16 + rsz + psz;
	if (tagPos + 5 <= d.size() && memcmp(&d[tagPos], "[TAG]", 5) == 0)
	{
		std::string t(d.begin() + tagPos + 5, d.end());
		size_t s = 0;
		while (s < t.size())
		{
			size_t e = t.find('\n', s);
			if (e == std::string::npos) e = t.size();
			std::string line = t.substr(s, e - s);
			size_t eq = line.find('=');
			if (eq != std::string::npos)
			{
				std::string k = lower(trim(line.substr(0, eq))), v = trim(line.substr(eq + 1));
				if (f.tags.count(k))
					f.tags[k] += "\n" + v;
				else
					f.tags[k] = v;
			}
			s = e + 1;
		}
	}
	return f;
}

static void applyPatches(std::vector<uint8_t> &rom, const std::vector<Patch> &patches)
{
	for (auto &pt : patches)
	{
		size_t end = (size_t)pt.offset + pt.data.size();
		if (end > rom.size())
			rom.resize(end, 0);
		std::copy(pt.data.begin(), pt.data.end(), rom.begin() + pt.offset);
	}
}

static void loadWithLibs(const fs::path &p, std::vector<uint8_t> &rom, int depth, PSFFile *topOut)
{
	if (depth > 10)
		throw std::runtime_error("_lib nesting too deep");
	PSFFile f = readPSF(p);
	fs::path dir = p.parent_path();
	if (f.tags.count("_lib"))
		loadWithLibs(dir / fs::u8path(f.tags["_lib"]), rom, depth + 1, nullptr);
	applyPatches(rom, f.patches);
	for (int i = 2; i < 100; ++i)
	{
		std::string k = "_lib" + std::to_string(i);
		if (!f.tags.count(k))
			break;
		loadWithLibs(dir / fs::u8path(f.tags[k]), rom, depth + 1, nullptr);
	}
	if (topOut)
		*topOut = std::move(f);
}

static double parseTime(const std::string &s)
{
	// formats: "ss", "mm:ss", "hh:mm:ss", fractional seconds with '.' or ','
	if (s.empty())
		return 0;
	double total = 0, cur = 0, frac = 0, fracDiv = 1;
	bool inFrac = false;
	for (char c : s)
	{
		if (c >= '0' && c <= '9')
		{
			if (inFrac) { fracDiv *= 10; frac += (c - '0') / fracDiv; }
			else cur = cur * 10 + (c - '0');
		}
		else if (c == ':')
		{
			total = (total + cur + frac) * 60;
			cur = 0; frac = 0; fracDiv = 1; inFrac = false;
		}
		else if (c == '.' || c == ',')
			inFrac = true;
		else if (c == ' ')
			continue;
		else
			break;
	}
	return total + cur + frac;
}

// ---------------------------------------------------------------- SDAT lookup
struct SdatRef
{
	size_t offset, size;
};

static std::vector<SdatRef> findSDATs(const std::vector<uint8_t> &rom)
{
	std::vector<SdatRef> r;
	static const uint8_t sig[8] = { 'S', 'D', 'A', 'T', 0xFF, 0xFE, 0x00, 0x01 };
	for (size_t i = 0; i + 0x40 < rom.size(); i += 4)
	{
		if (rom[i] != 'S' || memcmp(&rom[i], sig, 8) != 0)
			continue;
		uint32_t sz = rd32(&rom[i + 8]);
		if (sz < 0x40 || i + sz > rom.size())
			sz = (uint32_t)(rom.size() - i);
		r.push_back({ i, sz });
	}
	return r;
}

static std::string seqSymbol(const std::vector<uint8_t> &s, uint32_t seq)
{
	if (s.size() < 0x40) return "";
	uint32_t symb = rd32(&s[0x10]);
	if (!symb || symb + 12 > s.size()) return "";
	uint32_t rec = rd32(&s[symb + 8]);
	uint32_t o = symb + rec;
	if (o + 4 > s.size()) return "";
	uint32_t n = rd32(&s[o]);
	if (seq >= n || o + 8 + seq * 4 > s.size()) return "";
	uint32_t so = rd32(&s[o + 4 + seq * 4]);
	if (!so || symb + so >= s.size()) return "";
	std::string name;
	for (size_t i = symb + so; i < s.size() && s[i]; ++i)
		name += (char)s[i];
	return name;
}

static uint32_t seqCount(const std::vector<uint8_t> &s)
{
	uint32_t info = rd32(&s[0x18]);
	if (!info || info + 12 > s.size()) return 0;
	uint32_t o = info + rd32(&s[info + 8]);
	if (o + 4 > s.size()) return 0;
	return rd32(&s[o]);
}

static std::string sanitize(std::string s)
{
	for (auto &c : s)
		if (strchr("<>:\"/\\|?*", c) || (unsigned char)c < 32)
			c = '_';
	return s;
}

// ---------------------------------------------------------------- render
// one note of a stem (seconds from the start of the song); key -1 = unpitched (drum hit)
struct NoteEv { double t = 0, dur = -1; int key = -1; int vel = 100; };
typedef std::map<std::string, std::vector<NoteEv>> NoteMap;
static thread_local size_t t_curFrame = 0; // 2SF: output frame of the sequencer tick being processed

struct Options
{
	unsigned rate = 44100;
	double defaultLength = 0; // 0 = auto (loop detection)
	int loops = 2;
	double defaultFade = 10;
	bool fadeSet = false, rateSet = false;
	std::string trackSel; // -t: tracks to split from multi-track files
	bool mix = false;
	int interpolation = INTERPOLATION_SINC;
	bool psfByVoice = false; // PSF: one stem per SPU voice instead of per instrument sample
	NoteMap *notes = nullptr; // exact notes per stem key (formats that know them: DS, PS1)

	// ---- used by the GUI
	fs::path outDir;                               // empty = next to the source file
	const std::set<std::string> *only = nullptr;   // stem keys to render (null = all)
	struct StemDesc { std::string key; };
	std::vector<StemDesc> *analysis = nullptr;      // analyze only: list the stems and return
	std::function<bool(const float *lr, size_t frames)> preview; // stream the full mix (44100 Hz), false = stop

	bool wants(const std::string &k) const { return !only || only->count(k) > 0; }
	fs::path outFor(const fs::path &in) const
	{
		if (!outDir.empty()) return outDir;
		fs::path d = in.parent_path();
		return d.empty() ? fs::current_path() : d;
	}
};

// collects frames and hands them to Options::preview in chunks
struct PreviewFeeder
{
	const Options &opt;
	std::vector<float> buf;
	explicit PreviewFeeder(const Options &o) : opt(o) { buf.reserve(4096 * 2); }
	void push(float l, float r)
	{
		buf.push_back(l); buf.push_back(r);
		if (buf.size() >= 4096 * 2) flush();
	}
	void flush()
	{
		if (buf.empty()) return;
		bool go = opt.preview(buf.data(), buf.size() / 2);
		buf.clear();
		if (!go) throw Cancelled();
	}
};

static inline int32_t muldiv7(int32_t val, uint8_t mul)
{
	return mul == 127 ? val : ((val * mul) >> 7);
}

struct RenderPlan
{
	size_t totalFrames;
	size_t fadeStart;
	size_t fadeLen;
	bool fadeOut;
};

// Renders the sequence; for every output frame calls cb(frame, acc) where
// acc[t*2], acc[t*2+1] is the L/R output of SSEQ track t (0..15).
// If plan.totalFrames == 0 the length is found automatically (end/loops).
template <typename CB>
static size_t renderPass(SDAT &sdat, const Options &opt, RenderPlan &plan, bool autoLen, std::map<int, std::set<int>> &progs, const char *label, CB cb)
{
	sseqSeed(0x2F5D);
	auto player = std::make_unique<Player>();
	player->sampleRate = opt.rate;
	player->interpolation = (Interpolation)opt.interpolation;
	player->Setup(sdat.sseq.get());
	player->sseqVol = Cnv_Scale(sdat.sseq->info.vol);
	player->Timer();

	const double spc = SecondsPerClockCycle;
	const double sps = 1.0 / opt.rate;
	float acc[32];
	size_t frames = 0, silentRun = 0;
	bool fading = false;
	int lastPct = -1;
	while (frames < plan.totalFrames)
	{
		memset(acc, 0, sizeof(acc));
#ifdef KEYLOG
		g_frame = frames;
#endif
		player->secondsIntoPlayback += sps;
		bool anyActive = false;
		for (int i = 0; i < 16; ++i)
		{
			Channel &chn = player->channels[i];
			if (chn.state <= CS_NONE)
				continue;
			anyActive = true;
			int32_t sample = chn.GenerateSample();
			chn.IncrementSample();
			if (chn.trackId < 0 || chn.trackId >= FSS_MAXTRACKS)
				continue;
			const Track &trk = player->tracks[chn.trackId];
			int tnum = trk.num & 15;
			uint8_t datashift = chn.reg.volumeDiv;
			if (datashift == 3)
				datashift = 4;
			sample = muldiv7(sample, chn.reg.volumeMul) >> datashift;
			acc[tnum * 2] += (float)muldiv7(sample, 127 - chn.reg.panning);
			acc[tnum * 2 + 1] += (float)muldiv7(sample, chn.reg.panning);
			progs[tnum].insert(trk.patch);
		}

		if (plan.fadeOut && frames >= plan.fadeStart)
		{
			float g = plan.fadeLen ? 1.f - (float)(frames - plan.fadeStart) / (float)plan.fadeLen : 0.f;
			if (g < 0) g = 0;
			for (auto &v : acc) v *= g;
		}
		cb(frames, acc);
		++frames;

		if (player->secondsIntoPlayback > player->secondsUntilNextClock)
		{
			t_curFrame = frames;
			player->Timer();
			player->secondsUntilNextClock += spc;
		}

		if (autoLen && !fading)
		{
			bool allEnded = true;
			for (uint8_t i = 0; i < player->nTracks; ++i)
				if (!player->tracks[player->trackIds[i]].state[TS_END])
					allEnded = false;
			if (allEnded && !anyActive)
			{
				if (++silentRun > opt.rate / 4)
				{
					plan.totalFrames = frames;
					plan.fadeOut = false;
					break;
				}
			}
			else
				silentRun = 0;
			uint32_t maxLoops = 0;
			for (int i = 0; i < FSS_MAXTRACKS; ++i)
				maxLoops = std::max(maxLoops, player->loopHits[i]);
			if (maxLoops >= (uint32_t)opt.loops)
			{
				fading = true;
				plan.fadeOut = plan.fadeLen > 0;
				plan.fadeStart = frames;
				plan.totalFrames = frames + plan.fadeLen;
			}
		}
		if (frames % (opt.rate / 2) == 0)
		{
			if (autoLen && !fading)
				out(fmt("\r  %s... %d:%02d   ", label, (int)(frames / opt.rate) / 60, (int)(frames / opt.rate) % 60));
			else
			{
				int pct = (int)(frames * 100 / std::max<size_t>(plan.totalFrames, 1));
				if (pct != lastPct)
				{
					lastPct = pct;
					out(fmt("\r  %s... %d%%   ", label, pct));
				}
			}
		}
	}
	return frames;
}

struct WavStream
{
	FILE *f = nullptr;
	uint32_t frames = 0;
	std::vector<int16_t> buf;
	unsigned rate = 44100;

	void open(const fs::path &p, unsigned r)
	{
		rate = r;
		f = openFile(p, "wb");
		if (!f)
			throw std::runtime_error("cannot write file: " + u8(p));
		uint8_t h[44] = {};
		fwrite(h, 1, 44, f);
		buf.reserve(1 << 16);
	}
	void push(float l, float r)
	{
		auto cv = [](float v) { long s = lrintf(v); if (s > 32767) s = 32767; if (s < -32768) s = -32768; return (int16_t)s; };
		buf.push_back(cv(l));
		buf.push_back(cv(r));
		++frames;
		if (buf.size() >= (1 << 16)) flush();
	}
	void flush()
	{
		if (!buf.empty()) fwrite(buf.data(), 2, buf.size(), f);
		buf.clear();
	}
	void close()
	{
		if (!f) return;
		flush();
		uint32_t dataBytes = frames * 4;
		uint8_t h[44];
		auto w32 = [&](int o, uint32_t v) { h[o] = v & 255; h[o + 1] = (v >> 8) & 255; h[o + 2] = (v >> 16) & 255; h[o + 3] = v >> 24; };
		auto w16 = [&](int o, uint16_t v) { h[o] = v & 255; h[o + 1] = v >> 8; };
		memcpy(h, "RIFF", 4); w32(4, 36 + dataBytes); memcpy(h + 8, "WAVEfmt ", 8);
		w32(16, 16); w16(20, 1); w16(22, 2); w32(24, rate); w32(28, rate * 4); w16(32, 4); w16(34, 16);
		memcpy(h + 36, "data", 4); w32(40, dataBytes);
		fseek(f, 0, SEEK_SET);
		fwrite(h, 1, 44, f);
		fclose(f);
		f = nullptr;
	}
};

static std::atomic<bool> g_psfVoices{ false }; // GUI switch: PSF stems per voice instead of per instrument
#include "psf_split.h"
#include "usf_split.h"
#include "gme_split.h"
#include "tempo.h"
#include "encode.h"
#include "notes.h"
extern "C" int gsf_process_file(const char* utf8path, double ovLen, double ovFade, int mixOnly, unsigned rate);
extern "C" int gsf_process_ex(const char* utf8path, double ovLen, double ovFade, unsigned rate, const char* outRoot, int writeMix, int analyzeOnly,
	void (*stemCb)(void*, const char*), void* ctx, const char* const* only, int onlyCount);
extern "C" int gsf_preview(const char* utf8path, double ovLen, double ovFade, int (*sink)(void*, const float*, size_t), void* ctx);
extern "C" thread_local void (*gsf_log_cb)(void* ctx, const char* text);
extern "C" thread_local void* gsf_log_ctx;
extern "C" thread_local volatile int* gsf_cancel;
extern "C" thread_local double gsf_song_seconds;

namespace gsfglue
{
static thread_local volatile int cancelFlag = 0;
static void logCb(void*, const char* text)
{
	try { out(text); }
	catch (Cancelled&) { cancelFlag = 1; }
}
struct Scope
{
	Scope() { cancelFlag = 0; gsf_log_cb = logCb; gsf_log_ctx = nullptr; gsf_cancel = &cancelFlag; }
	~Scope() { gsf_log_cb = nullptr; gsf_cancel = nullptr; }
};
static int processGSF(const fs::path &inPath, const Options &opt)
{
	Scope sc;
	double len = opt.defaultLength > 0 ? opt.defaultLength : -1, fade = opt.fadeSet ? opt.defaultFade : -1;
	std::string p = u8(inPath);
	bool gui = opt.analysis || opt.preview || opt.only || !opt.outDir.empty() || g_outSink;
	if (opt.preview)
	{
		struct Ctx { const Options *o; bool stopped; } c{ &opt, false };
		gsf_preview(p.c_str(), len, fade, [](void* cx, const float* lr, size_t n) -> int {
			auto* c = (Ctx*)cx;
			if (!c->o->preview(lr, n)) { c->stopped = true; return 0; }
			return 1;
		}, &c);
		t_songSeconds = gsf_song_seconds;
		return 0;
	}
	if (!gui)
	{
		int ok = gsf_process_file(p.c_str(), len, fade, 0, opt.rateSet ? opt.rate : 0);
		if (!ok) throw std::runtime_error("GSF processing failed");
		return 1;
	}
	std::vector<std::string> keys;
	std::vector<const char*> only;
	if (opt.only) { for (auto &k : *opt.only) keys.push_back(k); for (auto &k : keys) only.push_back(k.c_str()); }
	std::string root = opt.outDir.empty() ? std::string() : u8(opt.outDir);
	int ok = gsf_process_ex(p.c_str(), len, fade, opt.rateSet ? opt.rate : 0, root.empty() ? nullptr : root.c_str(), opt.mix ? 1 : 0,
		opt.analysis ? 1 : 0,
		[](void* cx, const char* key) { ((std::vector<Options::StemDesc>*)cx)->push_back({ key }); }, opt.analysis,
		opt.only ? only.data() : nullptr, (int)only.size());
	t_songSeconds = gsf_song_seconds;
	if (cancelFlag) throw Cancelled();
	if (!ok) throw std::runtime_error("GSF processing failed");
	return 1;
}
} // namespace gsfglue

static int process2SF(const fs::path &inPath, const Options &opt)
{
	out("\n=== " + u8(inPath.filename()) + "  [Nintendo DS 2SF]\n");

	std::vector<uint8_t> rom;
	PSFFile top;
	loadWithLibs(inPath, rom, 0, &top);

	// --- which sequence? (NDSto2SF-style rips patch the sequence number into the driver)
	long seq = -1;
	for (auto &pt : top.patches)
		if (!pt.data.empty() && pt.data.size() <= 4)
		{
			uint32_t v = 0;
			for (size_t i = 0; i < pt.data.size(); ++i)
				v |= (uint32_t)pt.data[i] << (8 * i);
			seq = v;
			break;
		}
	std::string stem = u8(inPath.stem());
	long seqFromName = -1;
	{
		size_t i = 0;
		while (i < stem.size() && isxdigit((unsigned char)stem[i])) ++i;
		if (i >= 1 && i <= 4 && (i == stem.size() || stem[i] == ' ' || stem[i] == '-' || stem[i] == '_'))
			seqFromName = strtol(stem.substr(0, i).c_str(), nullptr, 16);
	}
	if (seq < 0)
		seq = seqFromName;
	if (seq < 0)
		throw std::runtime_error("cannot determine the sequence number of this file");

	// --- locate SDAT
	auto sdats = findSDATs(rom);
	if (sdats.empty())
		throw std::runtime_error("no SDAT (sound archive) found in the 2SF/2SFLIB data");
	std::string upStem = stem;
	for (auto &c : upStem) c = (char)toupper((unsigned char)c);
	int chosen = -1;
	std::vector<uint8_t> sd;
	for (size_t i = 0; i < sdats.size(); ++i)
	{
		std::vector<uint8_t> s(rom.begin() + sdats[i].offset, rom.begin() + sdats[i].offset + sdats[i].size);
		if ((uint32_t)seq >= seqCount(s)) continue;
		std::string nm = seqSymbol(s, (uint32_t)seq);
		bool nameMatch = !nm.empty() && upStem.find(nm) != std::string::npos;
		if (chosen < 0 || nameMatch) { chosen = (int)i; sd.swap(s); }
		if (nameMatch) break;
	}
	if (chosen < 0)
		throw std::runtime_error(fmt("sequence #%ld not found in the sound archive", seq));
	rom.clear();
	rom.shrink_to_fit();

	std::string symName = seqSymbol(sd, (uint32_t)seq);
	out(fmt("  sequence #%ld %s\n", seq, symName.c_str()));

	PseudoFile pf;
	pf.data = &sd;
	pf.pos = 0;
	std::unique_ptr<SDAT> sdat(new SDAT(pf, (uint32_t)seq));

	// --- length
	double length = 0, fade = opt.defaultFade;
	bool tagged = false;
	if (top.tags.count("length") && parseTime(top.tags["length"]) > 0)
	{
		length = parseTime(top.tags["length"]);
		tagged = true;
	}
	if (top.tags.count("fade"))
		fade = parseTime(top.tags["fade"]);
	if (!tagged && opt.defaultLength > 0)
	{
		length = opt.defaultLength;
		tagged = true;
	}

	RenderPlan plan;
	plan.fadeLen = (size_t)(fade * opt.rate);
	if (tagged)
	{
		plan.fadeStart = (size_t)(length * opt.rate);
		plan.totalFrames = plan.fadeStart + plan.fadeLen;
		plan.fadeOut = plan.fadeLen > 0;
	}
	else
	{
		plan.fadeStart = 0;
		plan.totalFrames = (size_t)opt.rate * 20 * 60; // hard limit 20 min
		plan.fadeOut = false;
	}
	t_songSeconds = tagged ? (double)plan.totalFrames / opt.rate : 0;

	if (opt.preview)
	{
		PreviewFeeder pf(opt);
		std::map<int, std::set<int>> pr;
		renderPass(*sdat, opt, plan, !tagged, pr, "preview", [&](size_t, const float *acc) {
			float ml = 0, mr = 0;
			for (int t = 0; t < 16; ++t) { ml += acc[t * 2]; mr += acc[t * 2 + 1]; }
			pf.push(ml / 32768.f, mr / 32768.f);
		});
		pf.flush();
		return 0;
	}

	// --- pass 1: find length and levels
	std::map<int, std::set<int>> progs;
	double peakTrack[16] = {}, peakMix = 0;
	out("  analyzing...");
#ifdef KEYLOG
	g_log = true;
#endif
	struct NoteCtx { std::vector<NoteEv> tr[16]; unsigned rate; } nctx;
	nctx.rate = opt.rate;
	if (opt.notes)
	{
		sseqNoteCtx = &nctx;
		sseqNoteHook = [](void *cx, int track, int key, int vel, int len, int tempo, int tempoRate) {
			auto *c = (NoteCtx *)cx;
			NoteEv n;
			n.t = (double)t_curFrame / c->rate;
			n.key = key;
			n.vel = vel;
			double tps = (1.0 / SecondsPerClockCycle) * tempo * (tempoRate / 256.0) / 240.0; // sequencer ticks per second
			n.dur = (len > 0 && tps > 0) ? len / tps : -1;
			auto &v = c->tr[track & 15];
			// a tie note (len -1) lasts until the next note of the track
			if (!v.empty() && v.back().dur < 0) v.back().dur = n.t - v.back().t;
			v.push_back(n);
		};
	}
	struct HookOff { ~HookOff() { sseqNoteHook = nullptr; sseqNoteCtx = nullptr; } } hookOff;
	size_t frames = renderPass(*sdat, opt, plan, !tagged, progs, "analyzing", [&](size_t, const float *acc) {
		float ml = 0, mr = 0;
		for (int t = 0; t < 16; ++t)
		{
			float l = acc[t * 2], r = acc[t * 2 + 1];
			ml += l; mr += r;
			peakTrack[t] = std::max(peakTrack[t], (double)std::max(std::fabs(l), std::fabs(r)));
		}
		peakMix = std::max(peakMix, (double)std::max(std::fabs(ml), std::fabs(mr)));
	});
	t_songSeconds = (double)frames / opt.rate;
	out(fmt("\r  length %d:%05.2f%s\n", (int)(frames / opt.rate) / 60, std::fmod((double)frames / opt.rate, 60.0),
		tagged ? " (from tags, incl. fade)" : ""));

#ifdef KEYLOG
	g_log = false;
#endif
	double peak = peakMix;
	for (double p : peakTrack) peak = std::max(peak, p);
	if (peak < 1.0)
		throw std::runtime_error("the sequence produced no sound");
	// keep the same level as a regular 2SF player; lower all stems equally only if needed
	float gain = 1.0f;
	if (peak > 32000.0)
	{
		gain = (float)(32000.0 / peak);
		out(fmt("  level lowered by %.1f dB to avoid clipping (equally for all stems)\n", -20 * std::log10(gain)));
	}

	// --- pass 2: write stems
	fs::path dir = opt.outFor(inPath);
	WavStream ws[16];
	WavStream mixWs;
	std::vector<std::string> names;
	std::string keys[16];
	for (int t = 0; t < 16; ++t)
	{
		if (peakTrack[t] * gain < 2.0)
			continue; // silent / unused track
		std::string pl;
		for (int p : progs[t]) { if (!pl.empty()) pl += "+"; pl += std::to_string(p); }
		keys[t] = fmt("Track %02d (prg %s)", t, pl.c_str());
	}
	sseqNoteHook = nullptr;
	if (opt.notes)
		for (int t = 0; t < 16; ++t)
			if (!keys[t].empty())
			{
				auto v = nctx.tr[t];
				for (auto &n : v) if (n.dur < 0) n.dur = (double)frames / opt.rate - n.t;
				(*opt.notes)[keys[t]] = v;
			}
	if (opt.analysis)
	{
		for (int t = 0; t < 16; ++t) if (!keys[t].empty()) opt.analysis->push_back({ keys[t] });
		return 0;
	}
	for (int t = 0; t < 16; ++t)
	{
		if (keys[t].empty() || !opt.wants(keys[t])) continue;
		std::string name = sanitize(stem + " - " + keys[t] + ".wav");
		ws[t].open(dir / fs::u8path(name), opt.rate);
		names.push_back(name);
	}
	if (opt.mix)
	{
		std::string name = sanitize(stem + " - Full Mix.wav");
		mixWs.open(dir / fs::u8path(name), opt.rate);
		names.push_back(name);
	}
	RenderPlan plan2 = plan;
	std::map<int, std::set<int>> progs2;
	renderPass(*sdat, opt, plan2, false, progs2, "rendering", [&](size_t, const float *acc) {
		float ml = 0, mr = 0;
		for (int t = 0; t < 16; ++t)
		{
			float l = acc[t * 2] * gain, r = acc[t * 2 + 1] * gain;
			ml += l; mr += r;
			if (ws[t].f) ws[t].push(l, r);
		}
		if (mixWs.f) mixWs.push(ml, mr);
	});
	for (auto &w : ws) w.close();
	mixWs.close();
	out("\r                                \r");
	for (auto &n : names)
		out("  -> " + n + "\n");
	out(fmt("  %d file(s) saved to: %s\n", (int)names.size(), u8(dir).c_str()));
	return (int)names.size();
}

static int processFile(const fs::path &inPath, const Options &opt)
{
	uint8_t hdr[4] = {};
	{
		FILE *f = openFile(inPath, "rb");
		if (!f) throw std::runtime_error("cannot open file: " + u8(inPath));
		size_t n = fread(hdr, 1, 4, f);
		fclose(f);
		std::string ext = lower(u8(inPath.extension()));
		if (ext == ".m3u" || ext == ".m3u8")
			return gmesplit::processM3uFile(inPath, opt);
		if (n >= 4 && (memcmp(hdr, "SNES", 4) == 0 || memcmp(hdr, "Vgm ", 4) == 0 || memcmp(hdr, "NESM", 4) == 0 || memcmp(hdr, "NSFE", 4) == 0 || memcmp(hdr, "GBS", 3) == 0 || (hdr[0] == 0x1F && hdr[1] == 0x8B && (ext == ".vgz" || ext == ".vgm"))))
			return gmesplit::processGme(inPath, opt);
		if (n < 4 || memcmp(hdr, "PSF", 3) != 0)
			throw std::runtime_error("not a PSF-family music file: " + u8(inPath.filename()));
	}
	switch (hdr[3])
	{
		case 0x01: return psfsplit::processPSF(inPath, opt);
		case 0x21: return usfsplit::processUSF(inPath, opt);
		case 0x24: return process2SF(inPath, opt);
		case 0x22: return gsfglue::processGSF(inPath, opt);
		default: throw std::runtime_error(fmt("unsupported PSF type 0x%02X: ", hdr[3]) + u8(inPath.filename()));
	}
}

// ---------------------------------------------------------------- API for the GUI
namespace core
{
struct SongInfo
{
	std::string system;                 // "Nintendo DS 2SF", ...
	std::vector<std::string> tracks;    // track titles (1 entry for single-track formats)
	fs::path file;                      // music file to load (for .m3u: the referenced file)
	std::vector<gmesplit::Job> jobs;    // multi-track (gme) formats
	bool gme = false;
};

static SongInfo probe(const fs::path &in)
{
	SongInfo si;
	si.file = in;
	std::string ext = lower(u8(in.extension()));
	uint8_t hdr[16] = {};
	{
		FILE *f = openFile(in, "rb");
		if (!f) throw std::runtime_error("cannot open file");
		fread(hdr, 1, sizeof hdr, f);
		fclose(f);
	}
	bool isGme = ext == ".m3u" || ext == ".m3u8" || memcmp(hdr, "SNES", 4) == 0 || memcmp(hdr, "Vgm ", 4) == 0 ||
		memcmp(hdr, "NESM", 4) == 0 || memcmp(hdr, "NSFE", 4) == 0 || memcmp(hdr, "GBS", 3) == 0 || (hdr[0] == 0x1F && hdr[1] == 0x8B);
	if (isGme)
	{
		si.gme = true;
		gmesplit::collectJobs(in, si.file, si.jobs);
		std::vector<uint8_t> d = gmesplit::maybeGunzip(readFile(si.file));
		si.system = gmesplit::systemName(d);
		for (auto &j : si.jobs) si.tracks.push_back(j.title);
		if (si.tracks.empty()) throw std::runtime_error("no tracks in this file");
		return si;
	}
	if (memcmp(hdr, "PSF", 3) != 0) throw std::runtime_error("unsupported file type");
	switch (hdr[3])
	{
		case 0x01: si.system = "PlayStation PSF"; break;
		case 0x02: throw std::runtime_error("PlayStation 2 PSF2 is not supported");
		case 0x21: si.system = "Nintendo 64 USF"; break;
		case 0x22: si.system = "Game Boy Advance GSF"; break;
		case 0x24: si.system = "Nintendo DS 2SF"; break;
		default: throw std::runtime_error(fmt("unsupported PSF type 0x%02X", hdr[3]));
	}
	si.tracks.push_back(u8(in.stem()));
	return si;
}

// runs analysis / render / preview (depending on opt) for one track
static void run(const SongInfo &si, int track, const Options &opt)
{
	if (si.gme)
	{
		std::vector<uint8_t> data = gmesplit::maybeGunzip(readFile(si.file));
		gmesplit::processTrack(si.file, data, si.jobs.at(track), opt);
		return;
	}
	processFile(si.file, opt);
}
} // namespace core

// collects up to 120 s of the full mix (mono, 44100 Hz) for tempo detection
static void gui_bpm(const core::SongInfo &si, int track, std::vector<float> &mono, double &secs)
{
	const size_t maxFrames = 44100 * 120;
	mono.clear();
	mono.reserve(maxFrames);
	Options o;
	o.preview = [&](const float *lr, size_t n) {
		for (size_t i = 0; i < n && mono.size() < maxFrames; ++i) mono.push_back(0.5f * (lr[2 * i] + lr[2 * i + 1]));
		return mono.size() < maxFrames;
	};
	bool q = t_quiet;
	t_quiet = true;
	try { core::run(si, track, o); }
	catch (Cancelled &) { if (t_cancel && t_cancel->load()) { t_quiet = q; throw; } }
	t_quiet = q;
	secs = (double)mono.size() / 44100;
}

// ---------------------------------------------------------------- main
static void usage()
{
	out(std::string(APP_NAME) + "\n"
		"Drag and drop music files (or a folder) onto this program:\n"
		"  .mini2sf/.2sf  (Nintendo DS)  -> one WAV per sequence track, next to the file\n"
		"  .minipsf/.psf  (PlayStation)  -> one WAV per SPU voice (with its own reverb), next to the file\n"
		"  .minigsf/.gsf  (Game Boy Advance) -> folder \"<name> - stems\" with full mix + tracks\n"
		"  .miniusf/.usf  (Nintendo 64)  -> one WAV per instrument sample (with its own reverb), next to the file\n"
		"  .spc           (SNES)         -> one WAV per DSP voice (with its own echo), next to the file\n"
		"  .vgm/.vgz      (Mega Drive etc.) -> one WAV per chip channel (FM 1-6, PCM, PSG 1-3, noise), next to the file\n"
		"  .nsf/.nsfe     (NES)          -> one WAV per sound channel; asks which tracks to split\n"
		"  .gbs           (Game Boy)     -> one WAV per sound channel; asks which tracks to split\n"
		"  .m3u           (playlist for NSF/GBS) -> splits the tracks listed in it (titles and lengths from the playlist)\n"
		"The library file (.2sflib/.psflib/.gsflib/.usflib) must be in the same folder.\n\n"
		"Command line: \"Pupue Splitter.exe\" [options] file1 [file2 ...]\n"
		"  -l <time>    length if the file has no length tag (e.g. 2:30)\n"
		"  -f <sec>     fade length (default: from tags, otherwise 10)\n"
		"  -n <loops>   2SF: loops to play when there is no length tag (default 2)\n"
		"  -m           2SF/PSF/USF/SPC/VGM/NSF/GBS: also write the full mix\n"
		"  -t <list>    NSF/GBS/multi-track playlists: tracks to split without asking, e.g. -t 5 or -t 2,7,10-12 or -t all\n"
		"  -r <rate>    2SF/GSF/USF output sample rate (2SF/USF default 44100, GSF 48000; PSF is always 44100)\n"
		"  -i <0..4>    2SF interpolation: 0 none, 1 linear, 2 4-point, 3 6-point, 4 sinc (default)\n"
		"  -q           don't wait for Enter at the end\n");
}

template <typename S>
static int run(const std::vector<S> &args)
{
	Options opt;
	bool noPause = false;
	std::vector<fs::path> files;
	std::set<std::string> onlySet;
	bool analyzeMode = false, bpmMode = false, notesMode = false;
	std::string previewWav;
	int coreTrack = 0;
	auto narrow = [](const S &s) { fs::path p(s); return u8(p); };
	for (size_t i = 0; i < args.size(); ++i)
	{
		std::string a = narrow(args[i]);
		auto next = [&]() -> std::string { if (i + 1 < args.size()) return narrow(args[++i]); return ""; };
		if (a == "-r") { opt.rate = (unsigned)atoi(next().c_str()); opt.rateSet = true; }
		else if (a == "-l") opt.defaultLength = parseTime(next());
		else if (a == "-f") { opt.defaultFade = parseTime(next()); opt.fadeSet = true; }
		else if (a == "-n") opt.loops = std::max(1, atoi(next().c_str()));
		else if (a == "-i") opt.interpolation = std::min(4, std::max(0, atoi(next().c_str())));
		else if (a == "-m") opt.mix = true;
		else if (a == "-t") opt.trackSel = next();
		else if (a == "-q") noPause = true;
		else if (a == "-o") opt.outDir = fs::u8path(next());
		else if (a == "--only") { std::string v = next(); size_t s = 0; while (s <= v.size()) { size_t e = v.find('|', s); if (e == std::string::npos) e = v.size(); if (e > s) onlySet.insert(v.substr(s, e - s)); s = e + 1; } opt.only = &onlySet; }
		else if (a == "--analyze") analyzeMode = true;
		else if (a == "--preview") previewWav = next();
		else if (a == "--track") coreTrack = atoi(next().c_str());
		else if (a == "--bpm") bpmMode = true;
		else if (a == "--psf-voices") opt.psfByVoice = true;
		else if (a == "--notes") notesMode = true;
		else if (a == "--midi-test") { std::string in = next(), mid = next(), wav = next();
			auto si = core::probe(fs::absolute(fs::u8path(in))); NoteMap nm; std::vector<Options::StemDesc> st; Options o = opt; o.analysis = &st; o.notes = &nm;
			t_quiet = true; core::run(si, 0, o); t_quiet = false;
			std::vector<std::pair<std::string, std::vector<NoteEv>>> tr(nm.begin(), nm.end());
			notes::writeMidi(fs::u8path(mid), tr, 125);
			if (!wav.empty() && !tr.empty()) { notes::embedCues(fs::u8path(wav), tr[0].second, 44100); notes::writeLabels(fs::u8path(wav + ".txt"), tr[0].second); }
			out("ok\n"); return 0; }
		else if (a == "--detect") { std::string w = next(); std::vector<float> mono; unsigned r = 0;
			if (!notes::readMono(fs::u8path(w), mono, r)) { out("ERROR: cannot read wav\n"); return 1; }
			auto ns = notes::detect(mono, r);
			out(fmt("%d notes\n", (int)ns.size()));
			for (size_t i = 0; i < ns.size() && i < 40; ++i) out(fmt("  %8.3f  %6.3f  %-4s v%d\n", ns[i].t, ns[i].dur, notes::noteName(ns[i].key).c_str(), ns[i].vel));
			return 0; }
		else if (a == "--encode") { std::string fm = next(), s1 = next(), d1 = next();
			try { enc::convert(fs::u8path(s1), fs::u8path(d1), fm == "mp3" ? enc::MP3 : fm == "flac" ? enc::FLAC : enc::WAV, [](float) {}); out("encoded\n"); return 0; }
			catch (const std::exception &e) { out(std::string("ERROR: ") + e.what() + "\n"); return 1; } }
		else if (a == "-h" || a == "--help" || a == "/?") { usage(); return 0; }
		else files.emplace_back(args[i]);
	}
	if (opt.rate < 8000 || opt.rate > 192000) opt.rate = 44100;

	int failures = 0;
	if (bpmMode)
	{
		for (auto &f : files)
		{
			try
			{
				auto si = core::probe(fs::absolute(f));
				std::vector<float> mono;
				double secs = 0;
				gui_bpm(si, coreTrack, mono, secs);
				auto r = tempo::estimate(mono, 44100);
				out(fmt("BPM %.2f  first beat %.3fs  confidence %.2f  (%s)\n", r.bpm, r.firstBeat, r.confidence, u8(fs::path(f).filename()).c_str()));
			}
			catch (const std::exception &ex) { t_quiet = false; out(std::string("ERROR: ") + ex.what() + "\n"); ++failures; }
		}
		return failures ? 1 : 0;
	}
	if (notesMode)
	{
		for (auto &f : files)
		{
			auto si = core::probe(fs::absolute(f));
			NoteMap nm;
			std::vector<Options::StemDesc> st;
			Options o = opt;
			o.analysis = &st;
			o.notes = &nm;
			t_quiet = true;
			core::run(si, coreTrack, o);
			t_quiet = false;
			for (auto &kv : nm)
			{
				out(fmt("%s: %d notes:", kv.first.c_str(), (int)kv.second.size()));
				for (size_t i = 0; i < kv.second.size() && (i < 8 || getenv("NOTESALL")); ++i) out(fmt(" %.2f/%s/%.2f", kv.second[i].t, notes::noteName(kv.second[i].key).c_str(), kv.second[i].dur));
				out("\n");
			}
		}
		return 0;
	}
	if (analyzeMode || !previewWav.empty())
	{
		// test hooks for the GUI core API
		for (auto &f : files)
		{
			try
			{
				auto si = core::probe(fs::absolute(f));
				out("system: " + si.system + fmt(", %d track(s)\n", (int)si.tracks.size()));
				Options o = opt;
				if (analyzeMode)
				{
					std::vector<Options::StemDesc> st;
					o.analysis = &st;
					core::run(si, coreTrack, o);
					for (auto &s : st) out("STEM: " + s.key + "\n");
				}
				else
				{
					WavStream w;
					w.open(fs::u8path(previewWav), 44100);
					o.preview = [&](const float *lr, size_t n) { for (size_t i = 0; i < n; ++i) w.push(lr[2 * i] * 32767.f, lr[2 * i + 1] * 32767.f); return true; };
					t_quiet = true;
					core::run(si, coreTrack, o);
					t_quiet = false;
					w.close();
					out(fmt("preview frames: %u\n", w.frames));
				}
			}
			catch (const std::exception &ex) { t_quiet = false; out(std::string("ERROR: ") + ex.what() + "\n"); ++failures; }
		}
		return failures ? 1 : 0;
	}
	if (files.empty())
		usage();
	for (auto &f : files)
	{
		try
		{
			fs::path p = fs::absolute(f);
			if (fs::is_directory(p))
			{
				for (auto &e : fs::directory_iterator(p))
				{
					std::string ext = lower(u8(e.path().extension()));
					if (ext == ".mini2sf" || ext == ".2sf" || ext == ".minipsf" || ext == ".psf" || ext == ".minigsf" || ext == ".gsf" || ext == ".miniusf" || ext == ".usf" || ext == ".spc" || ext == ".vgm" || ext == ".vgz" || ext == ".nsf" || ext == ".nsfe" || ext == ".gbs")
					{
						try { processFile(e.path(), opt); }
						catch (const std::exception &ex) { out(std::string("ERROR: ") + ex.what() + "\n"); ++failures; }
					}
				}
			}
			else
				processFile(p, opt);
		}
		catch (const std::exception &ex)
		{
			out(std::string("ERROR: ") + ex.what() + "\n");
			++failures;
		}
	}
#ifdef _WIN32
	if (!noPause)
	{
		out("\nPress Enter to close...");
		getchar();
	}
#else
	(void)noPause;
#endif
	return failures ? 1 : 0;
}

#ifdef _WIN32
#include "gui.h"
static void attachConsole()
{
	if (!AttachConsole(ATTACH_PARENT_PROCESS)) AllocConsole();
	FILE *f;
	freopen_s(&f, "CONOUT$", "w", stdout);
	freopen_s(&f, "CONOUT$", "w", stderr);
	freopen_s(&f, "CONIN$", "r", stdin);
	setvbuf(stdout, nullptr, _IONBF, 0);
	SetStdHandle(STD_OUTPUT_HANDLE, CreateFileW(L"CONOUT$", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr));
	SetStdHandle(STD_INPUT_HANDLE, CreateFileW(L"CONIN$", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr));
	SetConsoleOutputCP(CP_UTF8);
}
int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int)
{
	int argc = 0;
	wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
	std::vector<std::wstring> a;
	for (int i = 1; i < argc; ++i) a.push_back(argv[i]);
	LocalFree(argv);
	// command-line mode: any option (e.g. --cli, -m, -t 3 ...)
	bool cli = false;
	for (auto &x : a) if (!x.empty() && x[0] == L'-') cli = true;
	if (cli)
	{
		attachConsole();
		std::vector<std::wstring> b;
		for (auto &x : a) if (x != L"--cli") b.push_back(x);
		return run(b);
	}
	return gui::runGui(a);
}
#else
int main(int argc, char **argv)
{
	std::vector<std::string> a(argv + 1, argv + argc);
	return run(a);
}
#endif
