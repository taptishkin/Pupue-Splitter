/*
 * Output formats for rendered stems: WAV (as rendered), FLAC (libFLAC, BSD),
 * MP3 (LAME, LGPL; 320 kbps CBR). Converts a 16-bit stereo WAV file.
 * Included from main.cpp.
 */
#pragma once
#include "FLAC/stream_encoder.h"
#include "lame.h"

namespace enc
{
enum Fmt { WAV = 0, FLAC = 1, MP3 = 2 };
static const char *ext(int f) { return f == FLAC ? ".flac" : f == MP3 ? ".mp3" : ".wav"; }

struct WavInfo { unsigned rate = 0, channels = 0, bits = 0; long long dataOff = 0; long long frames = 0; };
static bool readWavInfo(const fs::path &p, WavInfo &wi)
{
	FILE *f = openFile(p, "rb");
	if (!f) return false;
	uint8_t h[12];
	bool ok = false;
	if (fread(h, 1, 12, f) == 12 && !memcmp(h, "RIFF", 4) && !memcmp(h + 8, "WAVE", 4))
	{
		long long pos = 12;
		uint8_t ch[8];
		while (fread(ch, 1, 8, f) == 8)
		{
			uint32_t sz = ch[4] | ch[5] << 8 | ch[6] << 16 | (uint32_t)ch[7] << 24;
			pos += 8;
			if (!memcmp(ch, "fmt ", 4))
			{
				uint8_t fm[16] = {};
				if (fread(fm, 1, std::min<uint32_t>(16, sz), f) < 16) break;
				wi.channels = fm[2] | fm[3] << 8;
				wi.rate = fm[4] | fm[5] << 8 | fm[6] << 16 | (unsigned)fm[7] << 24;
				wi.bits = fm[14] | fm[15] << 8;
			}
			else if (!memcmp(ch, "data", 4))
			{
				wi.dataOff = pos;
				wi.frames = wi.channels ? sz / (2 * wi.channels) : 0;
				ok = wi.rate > 0 && wi.channels == 2 && wi.bits == 16;
				break;
			}
			pos += sz + (sz & 1);
#ifdef _WIN32
			_fseeki64(f, pos, SEEK_SET);
#else
			fseeko(f, pos, SEEK_SET);
#endif
		}
	}
	fclose(f);
	return ok;
}

// prog(fraction) may throw (cancel)
static void convert(const fs::path &src, const fs::path &dst, int fmt, const std::function<void(float)> &prog)
{
	WavInfo wi;
	if (!readWavInfo(src, wi)) throw std::runtime_error("not a 16-bit stereo WAV: " + u8(src));
	FILE *in = openFile(src, "rb");
	if (!in) throw std::runtime_error("cannot read " + u8(src));
#ifdef _WIN32
	_fseeki64(in, wi.dataOff, SEEK_SET);
#else
	fseeko(in, wi.dataOff, SEEK_SET);
#endif
	const size_t CH = 4096;
	std::vector<int16_t> pcm(CH * 2);
	long long done = 0;
	auto progress = [&]() { prog(wi.frames ? (float)done / (float)wi.frames : 1.f); };

	if (fmt == FLAC)
	{
		FLAC__StreamEncoder *e = FLAC__stream_encoder_new();
		if (!e) { fclose(in); throw std::runtime_error("FLAC: out of memory"); }
		FLAC__stream_encoder_set_channels(e, 2);
		FLAC__stream_encoder_set_bits_per_sample(e, 16);
		FLAC__stream_encoder_set_sample_rate(e, wi.rate);
		FLAC__stream_encoder_set_compression_level(e, 5);
		FLAC__stream_encoder_set_total_samples_estimate(e, (FLAC__uint64)wi.frames);
		FILE *outF = openFile(dst, "w+b");
		if (!outF) { FLAC__stream_encoder_delete(e); fclose(in); throw std::runtime_error("cannot write " + u8(dst)); }
		if (FLAC__stream_encoder_init_FILE(e, outF, nullptr, nullptr) != FLAC__STREAM_ENCODER_INIT_STATUS_OK)
		{
			fclose(outF); FLAC__stream_encoder_delete(e); fclose(in);
			throw std::runtime_error("FLAC encoder init failed");
		}
		std::vector<FLAC__int32> buf(CH * 2);
		try
		{
			while (done < wi.frames)
			{
				size_t n = (size_t)std::min<long long>(CH, wi.frames - done);
				n = fread(pcm.data(), 4, n, in);
				if (!n) break;
				for (size_t i = 0; i < n * 2; ++i) buf[i] = pcm[i];
				if (!FLAC__stream_encoder_process_interleaved(e, buf.data(), (unsigned)n)) throw std::runtime_error("FLAC encoding failed");
				done += n;
				progress();
			}
		}
		catch (...) { FLAC__stream_encoder_finish(e); FLAC__stream_encoder_delete(e); fclose(in); std::error_code ec; fs::remove(dst, ec); throw; }
		FLAC__stream_encoder_finish(e); // closes outF
		FLAC__stream_encoder_delete(e);
		fclose(in);
		return;
	}
	if (fmt == MP3)
	{
		lame_t l = lame_init();
		if (!l) { fclose(in); throw std::runtime_error("MP3: out of memory"); }
		lame_set_in_samplerate(l, (int)wi.rate);
		lame_set_num_channels(l, 2);
		lame_set_brate(l, 320);
		lame_set_mode(l, JOINT_STEREO);
		lame_set_quality(l, 2);
		lame_set_bWriteVbrTag(l, 1); // "Info" tag with encoder delay/padding (gapless, stems stay in sync)
		if (lame_init_params(l) < 0) { lame_close(l); fclose(in); throw std::runtime_error("MP3 encoder init failed (sample rate?)"); }
		FILE *outF = openFile(dst, "w+b");
		if (!outF) { lame_close(l); fclose(in); throw std::runtime_error("cannot write " + u8(dst)); }
		std::vector<unsigned char> mp3((size_t)(1.25 * CH) + 7200);
		try
		{
			while (done < wi.frames)
			{
				size_t n = (size_t)std::min<long long>(CH, wi.frames - done);
				n = fread(pcm.data(), 4, n, in);
				if (!n) break;
				int k = lame_encode_buffer_interleaved(l, pcm.data(), (int)n, mp3.data(), (int)mp3.size());
				if (k < 0) throw std::runtime_error("MP3 encoding failed");
				fwrite(mp3.data(), 1, (size_t)k, outF);
				done += n;
				progress();
			}
			int k = lame_encode_flush(l, mp3.data(), (int)mp3.size());
			if (k > 0) fwrite(mp3.data(), 1, (size_t)k, outF);
		}
		catch (...) { lame_close(l); fclose(outF); fclose(in); std::error_code ec; fs::remove(dst, ec); throw; }
		lame_mp3_tags_fid(l, outF);
		lame_close(l);
		fclose(outF);
		fclose(in);
		return;
	}
	// WAV: plain copy
	fclose(in);
	std::error_code ec;
	fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec);
	if (ec) throw std::runtime_error("cannot write " + u8(dst) + ": " + ec.message());
	done = wi.frames;
	progress();
}
} // namespace enc
