/*
 * Notes of a stem: exact ones from the sequencer / sound chip (DS, PS1) or
 * estimated from the audio (onsets + YIN pitch) for the other formats.
 * Writers: Audacity/label .txt, markers inside WAV ("cue " + "LIST/adtl"),
 * Standard MIDI File (one track per stem).
 * Included from main.cpp (NoteEv / NoteMap are defined there).
 */
#pragma once
#include "tempo.h"

namespace notes
{

static std::string noteName(int key)
{
	if (key < 0) return "hit";
	static const char *n[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
	return std::string(n[key % 12]) + std::to_string(key / 12 - 1);
}

// ---------------------------------------------------------------- estimation from audio
// mono: samples at `rate`. Works best on monophonic stems (one chip channel / one instrument line).
static std::vector<NoteEv> detect(const std::vector<float> &mono, unsigned rate)
{
	std::vector<NoteEv> res;
	int dec = std::max(1, (int)std::lround(rate / 22050.0));
	double sr = (double)rate / dec;
	std::vector<float> x(mono.size() / dec);
	for (size_t i = 0; i < x.size(); ++i)
	{
		float s = 0;
		for (int k = 0; k < dec; ++k) s += mono[i * dec + k];
		x[i] = s / dec;
	}
	// frame f = the new samples [f*HOP, (f+1)*HOP); analysis windows end there, so an onset is
	// reported in the frame where it really happens (no look-ahead smearing)
	const int HOP = 128, N = 512, W = 512, PSTEP = 4;
	if (x.size() < (size_t)N * 4) return res;
	size_t nf = x.size() / HOP;
	double fr = sr / HOP;
	auto at = [&](long i) -> float { return (i >= 0 && i < (long)x.size()) ? x[i] : 0.f; };
	std::vector<float> rms(nf), flux(nf), prev(N / 2, 0.f), win(N);
	for (int i = 0; i < N; ++i) win[i] = 0.5f - 0.5f * std::cos(2 * 3.14159265f * i / N);
	std::vector<std::complex<float>> buf(N);
	for (size_t f = 0; f < nf; ++f)
	{
		long end = (long)(f + 1) * HOP;
		double e = 0;
		for (long i = end - 256; i < end; ++i) { float v = at(i); e += v * v; }
		rms[f] = (float)std::sqrt(e / 256);
		for (int i = 0; i < N; ++i) buf[i] = std::complex<float>(at(end - N + i) * win[i], 0);
		tempo::fft(buf);
		float fl = 0;
		for (int b = 1; b < N / 2; ++b)
		{
			float m = std::log1p(1000.f * std::abs(buf[b]));
			float d = m - prev[b];
			if (d > 0 && f > 0) fl += d;
			prev[b] = m;
		}
		flux[f] = fl;
	}
	float peak = 0;
	for (float r : rms) peak = std::max(peak, r);
	if (peak <= 1e-6f) return res;
	float thr = std::max(peak * 0.004f, 3e-5f); // ~ -48 dB of the loudest moment
	// YIN pitch (FFT autocorrelation) every PSTEP frames on the window starting at the frame
	std::vector<float> f0(nf, -1.f);
	{
		const int M = 2 * W;
		std::vector<std::complex<float>> A(M), B(M);
		std::vector<double> cs(M + 1), dn(W, 1.0);
		std::vector<float> p(M);
		int tauMin = std::max(2, (int)(sr / 1800.0)), tauMax = std::min(W - 2, (int)(sr / 45.0));
		for (size_t f = 0; f < nf; f += PSTEP)
		{
			if (rms[f] < thr && (f + 1 >= nf || rms[f + 1] < thr)) continue;
			for (int i = 0; i < M; ++i) p[i] = at((long)f * HOP + i);
			for (int i = 0; i < M; ++i) { A[i] = std::complex<float>(p[i], 0); B[i] = std::complex<float>(i < W ? p[i] : 0.f, 0); }
			tempo::fft(A);
			tempo::fft(B);
			for (int i = 0; i < M; ++i) A[i] = std::conj(A[i] * std::conj(B[i]));
			tempo::fft(A); // = conj(IFFT)*M; the real part is what we need
			cs[0] = 0;
			for (int i = 0; i < M; ++i) cs[i + 1] = cs[i] + (double)p[i] * p[i];
			double e0 = cs[W], run = 0;
			for (int tau = 1; tau < W; ++tau)
			{
				double d = e0 + (cs[tau + W] - cs[tau]) - 2.0 * A[tau].real() / M;
				run += d;
				dn[tau] = run > 0 ? d * tau / run : 1.0;
			}
			int best = -1;
			for (int tau = tauMin; tau <= tauMax; ++tau)
				if (dn[tau] < 0.15 && dn[tau] <= dn[tau - 1] && dn[tau] <= dn[tau + 1]) { best = tau; break; }
			if (best < 0)
			{
				double mv = 1e9; int mt = -1;
				for (int tau = tauMin; tau <= tauMax; ++tau) if (dn[tau] < mv) { mv = dn[tau]; mt = tau; }
				if (mv < 0.3) best = mt;
			}
			if (best > 0)
			{
				double t = best, a = dn[best - 1], b = dn[best], c = dn[best + 1], den = a - 2 * b + c;
				if (std::fabs(den) > 1e-12) t += 0.5 * (a - c) / den;
				float hz = (float)(sr / t);
				for (size_t k = f; k < std::min(nf, f + PSTEP); ++k) f0[k] = hz;
			}
		}
	}
	auto midiOf = [](float hz) { return 69.0 + 12.0 * std::log2(hz / 440.0); };
	// onset peaks (adaptive median threshold)
	std::vector<char> onset(nf, 0);
	{
		int R = 12;
		std::vector<float> w;
		for (size_t f = 1; f + 1 < nf; ++f)
		{
			if (rms[f] < thr) continue;
			size_t a = f > (size_t)R ? f - R : 0, b = std::min(nf, f + R + 1);
			w.assign(flux.begin() + a, flux.begin() + b);
			std::nth_element(w.begin(), w.begin() + w.size() / 2, w.end());
			float med = w[w.size() / 2];
			if (flux[f] > med * 1.8f + 2.0f && flux[f] >= flux[f - 1] && flux[f] >= flux[f + 1]) onset[f] = 1;
		}
	}
	int minGap = std::max(3, (int)(0.06 * fr));
	auto close = [&](long s, long e) {
		if (s < 0 || e - s < std::max(3, (int)(0.025 * fr))) return;
		std::vector<double> ps;
		long pe = s + std::max(1L, (long)((e - s) * 0.7));
		for (long f = s; f < pe; ++f) if (f0[f] > 0) ps.push_back(midiOf(f0[f]));
		NoteEv n;
		n.t = (double)s * HOP / sr;
		n.dur = (double)(e - s) * HOP / sr;
		if (ps.size() * 10 >= (size_t)(pe - s) * 3)
		{
			std::nth_element(ps.begin(), ps.begin() + ps.size() / 2, ps.end());
			n.key = (int)std::lround(ps[ps.size() / 2]);
			if (n.key < 0 || n.key > 127) n.key = -1;
		}
		else n.key = -1;
		float pk = 0;
		for (long f = s; f < e; ++f) pk = std::max(pk, rms[f]);
		n.vel = std::max(20, std::min(127, (int)std::lround(127.0 * std::sqrt(pk / peak))));
		res.push_back(n);
	};
	long start = -1, lastOn = -100000;
	int below = 0, pitchRun = 0;
	double curPitch = -1, candPitch = -1;
	for (long f = 0; f < (long)nf; ++f)
	{
		bool loud = rms[f] >= thr;
		if (start < 0)
		{
			if (loud) { start = f; lastOn = f; curPitch = -1; pitchRun = 0; candPitch = -1; below = 0; }
			continue;
		}
		if (!loud)
		{
			if (++below >= 3) { close(start, f - below + 1); start = -1; }
			continue;
		}
		below = 0;
		bool split = onset[f] && f - lastOn >= minGap;
		if (!split && f0[f] > 0)
		{
			double m = midiOf(f0[f]);
			if (curPitch < 0) curPitch = m;
			else if (std::fabs(m - curPitch) >= 0.8)
			{
				if (candPitch >= 0 && std::fabs(m - candPitch) < 0.5) ++pitchRun;
				else { candPitch = m; pitchRun = 1; }
				if (pitchRun >= 2 * PSTEP && f - lastOn >= minGap) { split = true; f -= pitchRun - 1; }
			}
			else pitchRun = 0;
		}
		if (split)
		{
			close(start, f);
			start = f; lastOn = f;
			curPitch = -1; pitchRun = 0; candPitch = -1;
		}
	}
	if (start >= 0) close(start, (long)nf);
	return res;
}

// reads a 16-bit stereo WAV as mono float
static bool readMono(const fs::path &p, std::vector<float> &mono, unsigned &rate)
{
	enc::WavInfo wi;
	if (!enc::readWavInfo(p, wi)) return false;
	FILE *f = openFile(p, "rb");
	if (!f) return false;
#ifdef _WIN32
	_fseeki64(f, wi.dataOff, SEEK_SET);
#else
	fseeko(f, wi.dataOff, SEEK_SET);
#endif
	mono.clear();
	mono.reserve((size_t)wi.frames);
	std::vector<int16_t> b(8192);
	long long left = wi.frames;
	while (left > 0)
	{
		size_t n = (size_t)std::min<long long>(4096, left);
		n = fread(b.data(), 4, n, f);
		if (!n) break;
		for (size_t i = 0; i < n; ++i) mono.push_back((b[2 * i] + b[2 * i + 1]) * (0.5f / 32768.f));
		left -= n;
	}
	fclose(f);
	rate = wi.rate;
	return true;
}

// ---------------------------------------------------------------- writers
static void writeLabels(const fs::path &p, const std::vector<NoteEv> &ns)
{
	FILE *f = openFile(p, "wb");
	if (!f) throw std::runtime_error("cannot write " + u8(p));
	for (auto &n : ns)
		fprintf(f, "%.6f\t%.6f\t%s\n", n.t, n.t + std::max(0.0, n.dur), noteName(n.key).c_str());
	fclose(f);
}

// appends "cue " + LIST/adtl/labl chunks to a finished WAV (markers show up in VEGAS, Reaper, Audition, Sound Forge)
static void embedCues(const fs::path &p, const std::vector<NoteEv> &ns, unsigned rate)
{
	if (ns.empty()) return;
	FILE *f = openFile(p, "r+b");
	if (!f) throw std::runtime_error("cannot update " + u8(p));
	auto w32 = [](std::vector<uint8_t> &v, uint32_t x) { for (int i = 0; i < 4; ++i) v.push_back((x >> (8 * i)) & 255); };
	auto tag = [](std::vector<uint8_t> &v, const char *t) { v.insert(v.end(), t, t + 4); };
	std::vector<uint8_t> cue, lst;
	tag(cue, "cue ");
	w32(cue, 4 + 24 * (uint32_t)ns.size());
	w32(cue, (uint32_t)ns.size());
	for (size_t i = 0; i < ns.size(); ++i)
	{
		uint32_t pos = (uint32_t)std::llround(ns[i].t * rate);
		w32(cue, (uint32_t)i + 1); w32(cue, pos); tag(cue, "data"); w32(cue, 0); w32(cue, 0); w32(cue, pos);
	}
	std::vector<uint8_t> adtl;
	tag(adtl, "adtl");
	for (size_t i = 0; i < ns.size(); ++i)
	{
		std::string s = noteName(ns[i].key);
		uint32_t sz = 4 + (uint32_t)s.size() + 1;
		tag(adtl, "labl"); w32(adtl, sz); w32(adtl, (uint32_t)i + 1);
		adtl.insert(adtl.end(), s.begin(), s.end());
		adtl.push_back(0);
		if (sz & 1) adtl.push_back(0);
	}
	tag(lst, "LIST");
	w32(lst, (uint32_t)adtl.size());
	lst.insert(lst.end(), adtl.begin(), adtl.end());
	fseek(f, 0, SEEK_END);
	long end = ftell(f);
	if (end & 1) { fputc(0, f); ++end; }
	fwrite(cue.data(), 1, cue.size(), f);
	fwrite(lst.data(), 1, lst.size(), f);
	uint32_t riff = (uint32_t)(end + cue.size() + lst.size() - 8);
	fseek(f, 4, SEEK_SET);
	uint8_t b[4] = { (uint8_t)(riff & 255), (uint8_t)((riff >> 8) & 255), (uint8_t)((riff >> 16) & 255), (uint8_t)(riff >> 24) };
	fwrite(b, 1, 4, f);
	fclose(f);
}

// Standard MIDI File, format 1, one track per stem. Times are mapped with a constant tempo
// (the detected BPM), so the notes line up with the DAW's bar grid.
static void writeMidi(const fs::path &p, const std::vector<std::pair<std::string, std::vector<NoteEv>>> &tracks, double bpm)
{
	if (bpm < 20 || bpm > 400) bpm = 120;
	const int PPQ = 480;
	auto vlq = [](std::vector<uint8_t> &v, uint32_t x) {
		uint8_t t[5]; int n = 0;
		t[n++] = x & 0x7F;
		while (x >>= 7) t[n++] = 0x80 | (x & 0x7F);
		while (n) v.push_back(t[--n]);
	};
	auto be32 = [](std::vector<uint8_t> &v, uint32_t x) { for (int i = 3; i >= 0; --i) v.push_back((x >> (8 * i)) & 255); };
	auto chunk = [&](std::vector<uint8_t> &out, const char *id, const std::vector<uint8_t> &data) {
		out.insert(out.end(), id, id + 4); be32(out, (uint32_t)data.size()); out.insert(out.end(), data.begin(), data.end());
	};
	auto ticks = [&](double sec) { return (uint32_t)std::llround(std::max(0.0, sec) * bpm / 60.0 * PPQ); };
	std::vector<uint8_t> file;
	{
		std::vector<uint8_t> h = { 0, 1 };
		uint16_t nt = (uint16_t)(tracks.size() + 1);
		h.push_back(nt >> 8); h.push_back(nt & 255);
		h.push_back(PPQ >> 8); h.push_back(PPQ & 255);
		chunk(file, "MThd", h);
	}
	{
		std::vector<uint8_t> t;
		uint32_t us = (uint32_t)std::llround(60000000.0 / bpm);
		t.push_back(0); t.push_back(0xFF); t.push_back(0x51); t.push_back(3);
		t.push_back((us >> 16) & 255); t.push_back((us >> 8) & 255); t.push_back(us & 255);
		t.push_back(0); t.push_back(0xFF); t.push_back(0x58); t.push_back(4); t.push_back(4); t.push_back(2); t.push_back(24); t.push_back(8);
		t.push_back(0); t.push_back(0xFF); t.push_back(0x2F); t.push_back(0);
		chunk(file, "MTrk", t);
	}
	int chan = 0;
	for (auto &tr : tracks)
	{
		bool drums = true;
		for (auto &n : tr.second) if (n.key >= 0) { drums = false; break; }
		int ch = drums ? 9 : chan;
		if (!drums) { chan = (chan + 1) % 16; if (chan == 9) chan = 10; }
		struct Ev { uint32_t tk; int on; int key; int vel; };
		std::vector<Ev> ev;
		for (auto &n : tr.second)
		{
			int key = n.key >= 0 ? n.key : 38; // unpitched: snare on the drum channel
			uint32_t a = ticks(n.t), b = std::max(a + 1, ticks(n.t + std::max(0.01, n.dur)));
			ev.push_back({ a, 1, key, std::max(1, std::min(127, n.vel)) });
			ev.push_back({ b, 0, key, 0 });
		}
		std::stable_sort(ev.begin(), ev.end(), [](const Ev &x, const Ev &y) { return x.tk != y.tk ? x.tk < y.tk : x.on < y.on; });
		std::vector<uint8_t> t;
		t.push_back(0); t.push_back(0xFF); t.push_back(0x03);
		vlq(t, (uint32_t)tr.first.size());
		t.insert(t.end(), tr.first.begin(), tr.first.end());
		uint32_t last = 0;
		std::map<int, int> active; // key -> open note count (avoid stuck notes when notes overlap)
		for (auto &e : ev)
		{
			if (!e.on)
			{
				auto it = active.find(e.key);
				if (it == active.end() || it->second <= 0) continue;
				if (--it->second > 0) continue; // still held by an overlapping note
			}
			else
			{
				if (active[e.key]++ > 0)
				{
					// retrigger: close the previous one first
					vlq(t, e.tk - last); last = e.tk;
					t.push_back(0x80 | ch); t.push_back(e.key & 127); t.push_back(0);
				}
			}
			vlq(t, e.tk - last); last = e.tk;
			t.push_back((e.on ? 0x90 : 0x80) | ch); t.push_back(e.key & 127); t.push_back(e.on ? e.vel : 0);
		}
		t.push_back(0); t.push_back(0xFF); t.push_back(0x2F); t.push_back(0);
		chunk(file, "MTrk", t);
	}
	FILE *f = openFile(p, "wb");
	if (!f) throw std::runtime_error("cannot write " + u8(p));
	fwrite(file.data(), 1, file.size(), f);
	fclose(f);
}

} // namespace notes
