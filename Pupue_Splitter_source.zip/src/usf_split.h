/*
 * USF (Nintendo 64) part of the splitter.
 * Emulation: lazyusf2 (kode54, based on mupen64plus; GPL), HLE audio.
 * Splitting: every voice in the RSP audio command list is tagged with the
 * ADPCM codebook it plays (= the sample / instrument). For each instrument
 * the song is emulated again with all other voices' contributions removed
 * right after their ENVMIXER step, so each stem includes the game's own
 * reverb/echo processing applied to that instrument only.
 * Included from main.cpp.
 */
#pragma once

extern "C" {
#include "lazyusf2/usf/usf.h"
#include "lazyusf2/rsp_hle/usfcap.h"
}

namespace usfsplit
{

struct UsfSong
{
	std::vector<std::vector<uint8_t>> sections; // reserved sections in upload order
	bool compare = false, fifofull = false;
	std::map<std::string, std::string> tags;
};

static void loadChain(const fs::path &p, UsfSong &s, int depth, bool top)
{
	if (depth > 10)
		throw std::runtime_error("_lib nesting too deep");
	PSFFile f = readPSF(p, 0x21);
	fs::path dir = p.parent_path();
	if (f.tags.count("_lib"))
	{
		fs::path lp = dir / fs::u8path(f.tags["_lib"]);
		if (!fs::exists(lp))
			throw std::runtime_error("library not found: " + f.tags["_lib"] + " (put it next to the .miniusf)");
		loadChain(lp, s, depth + 1, false);
	}
	if (!f.reserved.empty())
		s.sections.push_back(f.reserved);
	for (int i = 2; i < 100; ++i)
	{
		std::string k = "_lib" + std::to_string(i);
		if (!f.tags.count(k)) break;
		loadChain(dir / fs::u8path(f.tags[k]), s, depth + 1, false);
	}
	if (f.tags.count("_enablecompare")) s.compare = true;
	if (f.tags.count("_enablefifofull")) s.fifofull = true;
	if (top) s.tags = f.tags;
}

struct Emu
{
	std::vector<uint8_t> mem;
	void *st() { return mem.data(); }
	explicit Emu(const UsfSong &s)
	{
		mem.resize(usf_get_state_size());
		usf_clear(st());
		usf_set_compare(st(), s.compare ? 1 : 0);
		usf_set_fifo_full(st(), s.fifofull ? 1 : 0);
		usf_set_hle_audio(st(), 1);
		for (auto &sec : s.sections)
			if (usf_upload_section(st(), sec.data(), sec.size()) < 0)
				throw std::runtime_error("invalid USF data");
	}
	~Emu() { usf_shutdown(st()); }
};

struct KeyStat
{
	double energy = 0;
	std::map<uint32_t, double> voices;
};

struct StatCtx
{
	std::map<uint32_t, KeyStat> keys;
	bool unsupportedSeen = false;
};
static void statCb(void *ctx, uint32_t key, uint32_t voice, double e)
{
	auto *c = (StatCtx *)ctx;
	auto &k = c->keys[key];
	k.energy += e;
	k.voices[voice] += e;
}
struct KeepCtx
{
	std::set<uint32_t> solo;
};
static int keepCb(void *ctx, uint32_t key, uint32_t)
{
	return ((KeepCtx *)ctx)->solo.count(key) ? 1 : 0;
}

// renders the whole song; cb(frame, l, r) with int16 values (already in the emulator's own scale)
template <typename CB>
static void renderUSF(const UsfSong &song, unsigned rate, size_t total, const char *label, CB cb)
{
	Emu emu(song);
	std::vector<int16_t> buf(2 * 2048);
	size_t done = 0;
	int lastPct = -1;
	while (done < total)
	{
		size_t n = std::min<size_t>(2048, total - done);
		const char *err = usf_render_resampled(emu.st(), buf.data(), n, (int32_t)rate);
		if (err)
			throw std::runtime_error(std::string("N64 emulation error: ") + err);
		for (size_t i = 0; i < n; ++i)
			cb(done + i, buf[2 * i], buf[2 * i + 1]);
		done += n;
		int pct = (int)(done * 100 / total);
		if (pct != lastPct) { lastPct = pct; out(fmt("\r  %s... %d%%   ", label, pct)); }
	}
}

static int processUSF(const fs::path &inPath, const Options &opt)
{
	out("\n=== " + u8(inPath.filename()) + "  [Nintendo 64 USF]\n");
	UsfSong song;
	loadChain(inPath, song, 0, true);
	if (song.sections.empty())
		throw std::runtime_error("no ROM/state data in the USF files");

	double length = 0, fade = opt.defaultFade;
	if (song.tags.count("length")) length = parseTime(song.tags["length"]);
	if (song.tags.count("fade")) fade = parseTime(song.tags["fade"]);
	if (opt.defaultLength > 0 && length <= 0) length = opt.defaultLength;
	if (length <= 0) length = 150;
	double volume = 1.0;
	if (song.tags.count("volume")) { double v = atof(song.tags["volume"].c_str()); if (v > 0) volume = v; }

	int32_t nativeRate = 0;
	{
		Emu probe(song);
		const char *err = usf_render(probe.st(), nullptr, 0, &nativeRate);
		if (err) throw std::runtime_error(std::string("N64 emulation error: ") + err);
	}
	const unsigned rate = opt.rateSet ? opt.rate : 44100;
	size_t fadeStart = (size_t)(length * rate), fadeLen = (size_t)(fade * rate);
	size_t total = fadeStart + fadeLen;
	t_songSeconds = (double)total / rate;
	auto gainAt = [&](size_t f) -> float {
		float g = (float)volume;
		if (f >= fadeStart) g *= fadeLen ? std::max(0.f, 1.f - (float)(f - fadeStart) / (float)fadeLen) : 0.f;
		return g;
	};
	out(fmt("  length %d:%02d + fade %gs, console audio %d Hz -> %u Hz\n", (int)length / 60, (int)length % 60, fade, nativeRate, rate));

	fs::path dir = opt.outFor(inPath);
	std::string stem = u8(inPath.stem());

	if (opt.preview)
	{
		PreviewFeeder pf(opt);
		usfcap_stat = nullptr; usfcap_keep = nullptr; usfcap_ctx = nullptr;
		renderUSF(song, rate, total, "preview", [&](size_t f, int16_t l, int16_t r) { float g = gainAt(f) / 32768.f; pf.push(l * g, r * g); });
		pf.flush();
		return 0;
	}

	// pass 1: full mix + which instruments play
	StatCtx sctx;
	usfcap_unsupported = 0;
	usfcap_stat = statCb; usfcap_keep = nullptr; usfcap_ctx = &sctx;
	WavStream mixWs;
	if (opt.mix && !opt.analysis) mixWs.open(dir / fs::u8path(sanitize(stem + " - Full Mix.wav")), rate);
	try
	{
		renderUSF(song, rate, total, "analyzing", [&](size_t f, int16_t l, int16_t r) {
			if (mixWs.f) { float g = gainAt(f); mixWs.push(l * g, r * g); }
		});
	}
	catch (...) { usfcap_stat = nullptr; usfcap_ctx = nullptr; throw; }
	usfcap_stat = nullptr; usfcap_ctx = nullptr;
	mixWs.close();

	double totalE = 0;
	for (auto &kv : sctx.keys) totalE += kv.second.energy;
	if (sctx.keys.empty() || totalE <= 0)
	{
		out("\r  ! This game's audio microcode is not supported for splitting (no voices found).\n");
		if (!opt.mix)
		{
			WavStream w;
			w.open(dir / fs::u8path(sanitize(stem + " - Full Mix.wav")), rate);
			renderUSF(song, rate, total, "rendering mix", [&](size_t f, int16_t l, int16_t r) { float g = gainAt(f); w.push(l * g, r * g); });
			w.close();
		}
		out("\r  only the full mix was saved\n");
		return 1;
	}
	// instruments sorted by loudness; drop inaudible ones (< -60 dB of the total)
	std::vector<std::pair<uint32_t, double>> keys;
	for (auto &kv : sctx.keys)
		if (kv.second.energy > totalE * 1e-6) keys.push_back({ kv.first, kv.second.energy });
	std::sort(keys.begin(), keys.end(), [](auto &a, auto &b) { return a.first < b.first; });
#ifdef USFSTATS
	for (auto &kv : sctx.keys) { fprintf(stderr, "key %08X  %.2f%%  voices:", kv.first, 100 * kv.second.energy / totalE); for (auto &v : kv.second.voices) fprintf(stderr, " %06X(%.1f%%)", v.first, 100 * v.second / kv.second.energy); fprintf(stderr, "\n"); }
	if (getenv("USFSTATSONLY")) return 0;
#endif
	out(fmt("\r  %d instrument samples found                \n", (int)keys.size()));
	auto keyName = [&](size_t i) { return fmt("Inst %02d (smp %06X)", (int)i + 1, keys[i].first & 0xFFFFFF); };
	if (opt.analysis)
	{
		for (size_t i = 0; i < keys.size(); ++i) opt.analysis->push_back({ keyName(i) });
		return 0;
	}

	// one emulation pass per instrument
	std::vector<std::string> names;
	KeepCtx kctx;
	usfcap_keep = keepCb; usfcap_ctx = &kctx;
	// output with every instrument removed (DC offsets of the effect chain etc.);
	// subtracted from each stem so the stems add up to the full mix
	std::vector<float> base(total * 2, 0.f);
	try
	{
		kctx.solo.clear();
		renderUSF(song, rate, total, "baseline", [&](size_t f, int16_t l, int16_t r) { float g = gainAt(f); base[2 * f] = l * g; base[2 * f + 1] = r * g; });
		for (size_t i = 0; i < keys.size(); ++i)
		{
			if (!opt.wants(keyName(i))) continue;
			kctx.solo = { keys[i].first };
			std::string name = sanitize(stem + " - " + keyName(i) + ".wav");
			WavStream w;
			w.open(dir / fs::u8path(name), rate);
			std::string label = fmt("instrument %d/%d", (int)i + 1, (int)keys.size());
			renderUSF(song, rate, total, label.c_str(), [&](size_t f, int16_t l, int16_t r) { float g = gainAt(f); w.push(l * g - base[2 * f], r * g - base[2 * f + 1]); });
			w.close();
			names.push_back(name);
		}
	}
	catch (...) { usfcap_keep = nullptr; usfcap_ctx = nullptr; throw; }
	usfcap_keep = nullptr; usfcap_ctx = nullptr;

	out("\r                                \r");
	for (auto &n : names) out("  -> " + n + "\n");
	if (opt.mix) out("  -> " + sanitize(stem + " - Full Mix.wav") + "\n");
	out(fmt("  %d file(s) saved to: %s\n", (int)names.size() + (opt.mix ? 1 : 0), u8(dir).c_str()));
	return (int)names.size();
}

} // namespace usfsplit
