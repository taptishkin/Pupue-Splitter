/*
 * Pupue Splitter — GUI (Windows): "Nintendo 3DS" style, two screens.
 * Dear ImGui (MIT) + Win32 + Direct3D 11, waveOut player, stb_image GIF.
 * Included from main.cpp (uses core:: and the helpers there).
 *
 * Live stem mixing: after a file is analyzed, every stem (+ the full mix) is
 * rendered in the background into a temp folder ("stem cache"). While it is
 * being built the player streams the full mix straight from the emulator;
 * once it is ready the player mixes the stems that are ticked on the bottom
 * screen in real time, seeking is instant, and "Render" just copies files.
 */
#pragma once
#ifdef _WIN32

#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <shellapi.h>
#include <shobjidl.h>
#include <mmsystem.h>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <deque>
#include <chrono>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_GIF
#define STBI_NO_STDIO
#include "stb_image.h"

#define RES_KONATA_GIF 101
#define RES_POUPE_WAV 102

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace gui
{

// ================================================================ language
static int g_lang = 0; // 0 English, 1 Russian
static int g_fmt = 0;  // output format: enc::WAV / FLAC / MP3, 3 = MIDI
static bool g_markers = false; // write note markers next to the stems
static const int FMT_MIDI = 3;
static const char *tr(const char *en, const char *ru) { return g_lang == 1 ? ru : en; }
static void loadLang()
{
	DWORD v = 0, sz = sizeof v;
	if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Language", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS)
		g_lang = v == 1 ? 1 : 0;
	v = 0; sz = sizeof v;
	if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Format", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS)
		g_fmt = v <= 2 ? (int)v : 0;
	v = 0; sz = sizeof v;
	if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Markers", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS)
		g_markers = false; // note markers were removed from the UI
}
static void saveLang()
{
	DWORD v = (DWORD)g_lang;
	RegSetKeyValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Language", REG_DWORD, &v, sizeof v);
	v = (DWORD)g_fmt;
	RegSetKeyValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Format", REG_DWORD, &v, sizeof v);
	v = g_markers ? 1 : 0;
	RegSetKeyValueW(HKEY_CURRENT_USER, L"Software\\PupueSplitter", L"Markers", REG_DWORD, &v, sizeof v);
}

// ================================================================ small helpers
static std::pair<const uint8_t *, size_t> resource(int id)
{
	HRSRC r = FindResourceW(nullptr, MAKEINTRESOURCEW(id), (LPCWSTR)RT_RCDATA);
	if (!r) return { nullptr, 0 };
	HGLOBAL g = LoadResource(nullptr, r);
	if (!g) return { nullptr, 0 };
	return { (const uint8_t *)LockResource(g), (size_t)SizeofResource(nullptr, r) };
}

static double nowSec()
{
	using namespace std::chrono;
	return duration<double>(steady_clock::now().time_since_epoch()).count();
}

static std::string mmss(double s)
{
	if (s < 0) s = 0;
	int t = (int)s;
	return fmt("%d:%02d", t / 60, t % 60);
}

// ================================================================ log model
// Receives everything the splitter core prints. '\r' starts a progress line.
struct LogModel
{
	std::mutex m;
	std::vector<std::string> lines;
	std::string cur;
	void add(const std::string &s)
	{
		std::lock_guard<std::mutex> lk(m);
		for (char c : s)
		{
			if (c == '\r') { cur.clear(); continue; }
			if (c == '\n')
			{
				std::string t = trim(cur);
				if (!t.empty()) lines.push_back(t);
				if (lines.size() > 300) lines.erase(lines.begin(), lines.begin() + 100);
				cur.clear();
				continue;
			}
			cur += c;
		}
	}
	void clear() { std::lock_guard<std::mutex> lk(m); lines.clear(); cur.clear(); }
	void snapshot(std::vector<std::string> &l, std::string &c)
	{
		std::lock_guard<std::mutex> lk(m);
		l = lines;
		c = cur;
	}
};
static LogModel g_log;

// "label... 42%" -> label, 0.42
static bool parseProgress(const std::string &line, std::string &label, float &frac)
{
	size_t pct = line.rfind('%');
	if (pct == std::string::npos) return false;
	size_t a = pct;
	while (a > 0 && isdigit((unsigned char)line[a - 1])) --a;
	if (a == pct) return false;
	frac = atoi(line.substr(a, pct - a).c_str()) / 100.f;
	size_t dots = line.find("...");
	label = trim(dots == std::string::npos ? line.substr(0, a) : line.substr(0, dots));
	return true;
}

// overall progress of a render job from its current progress line
static float overallProgress(const std::string &plabel, float pfrac)
{
	size_t sl = plabel.find('/');
	if (sl != std::string::npos)
	{
		size_t b0 = sl;
		while (b0 > 0 && isdigit((unsigned char)plabel[b0 - 1])) --b0;
		int i = atoi(plabel.substr(b0, sl - b0).c_str()), n = atoi(plabel.substr(sl + 1).c_str());
		if (n > 0 && i > 0) return std::min(1.f, ((i - 1) + pfrac) / n);
	}
	if (plabel.find("analyzing") != std::string::npos) return pfrac * 0.3f;
	if (plabel.find("baseline") != std::string::npos) return 0.3f + pfrac * 0.05f;
	if (plabel.find("rendering") != std::string::npos) return 0.3f + pfrac * 0.7f;
	return pfrac;
}

// ================================================================ background jobs
struct Worker
{
	std::thread th;
	std::atomic<bool> busy{ false };
	std::atomic<bool> cancel{ false };
	std::atomic<int> finished{ 0 }; // set when a job ended: 1 ok, 2 cancelled, 3 error
	std::mutex m;
	std::string error;
	int kind = 0; // 1 analyze, 2 render, 3 stem cache
	std::function<void(const std::string &)> sink;

	// logTo: separate log for this job (nullptr = the main log)
	bool start(int k, std::function<void()> fn, LogModel *logTo = nullptr)
	{
		if (busy) return false;
		if (th.joinable()) th.join();
		busy = true;
		cancel = false;
		finished = 0;
		kind = k;
		if (logTo) sink = [logTo](const std::string &s) { logTo->add(s); };
		else sink = nullptr;
		th = std::thread([this, fn]() {
			t_cancel = &cancel;
			t_sink = sink ? &sink : nullptr;
			int res = 1;
			try { fn(); }
			catch (Cancelled &) { res = 2; }
			catch (const std::exception &e) { std::lock_guard<std::mutex> lk(m); error = e.what(); res = 3; }
			catch (...) { std::lock_guard<std::mutex> lk(m); error = "unknown error"; res = 3; }
			t_cancel = nullptr;
			t_sink = nullptr;
			busy = false;
			finished = res;
		});
		return true;
	}
	void join() { cancel = true; if (th.joinable()) th.join(); busy = false; }
};

// ================================================================ WAV reading (stem cache)
struct WavInfo { unsigned rate = 0; long long dataOff = 0; long long frames = 0; };
static bool readWavInfo(const fs::path &p, WavInfo &wi)
{
	FILE *f = openFile(p, "rb");
	if (!f) return false;
	uint8_t h[12];
	bool ok = false;
	if (fread(h, 1, 12, f) == 12 && !memcmp(h, "RIFF", 4) && !memcmp(h + 8, "WAVE", 4))
	{
		long long pos = 12;
		uint8_t ch[8];
		while (fread(ch, 1, 8, f) == 8)
		{
			uint32_t sz = ch[4] | ch[5] << 8 | ch[6] << 16 | (uint32_t)ch[7] << 24;
			pos += 8;
			if (!memcmp(ch, "fmt ", 4))
			{
				uint8_t fm[16] = {};
				fread(fm, 1, std::min<uint32_t>(16, sz), f);
				unsigned chn = fm[2] | fm[3] << 8, bits = fm[14] | fm[15] << 8;
				wi.rate = fm[4] | fm[5] << 8 | fm[6] << 16 | (unsigned)fm[7] << 24;
				if (chn != 2 || bits != 16) break;
			}
			else if (!memcmp(ch, "data", 4))
			{
				wi.dataOff = pos;
				wi.frames = sz / 4;
				ok = wi.rate > 0;
				break;
			}
			pos += sz + (sz & 1);
			_fseeki64(f, pos, SEEK_SET);
		}
	}
	fclose(f);
	return ok;
}

// ================================================================ stem cache
static fs::path g_tempRoot;
static int g_cacheCounter = 0;

static void cleanupStaleTemp()
{
	wchar_t tmp[MAX_PATH + 1];
	GetTempPathW(MAX_PATH, tmp);
	fs::path root = fs::path(tmp) / L"PupueSplitter";
	std::error_code ec;
	if (fs::exists(root, ec))
		for (auto &e : fs::directory_iterator(root, ec))
		{
			DWORD pid = (DWORD)wcstoul(e.path().filename().c_str(), nullptr, 10);
			if (pid == GetCurrentProcessId()) continue;
			HANDLE h = pid ? OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid) : nullptr;
			if (h) { CloseHandle(h); continue; }
			fs::remove_all(e.path(), ec);
		}
	g_tempRoot = root / std::to_wstring(GetCurrentProcessId());
}

struct StemCache
{
	Worker w;
	LogModel log;
	std::atomic<int> state{ 0 }; // 0 none, 1 building, 2 ready, 3 failed
	fs::path dir;
	std::vector<fs::path> stemFile; // per stem (same order as the stem list), empty if missing
	fs::path mixFile;
	unsigned rate = 0;
	long long frames = 0;
	NoteMap notes; // exact notes per stem key (DS / PS1)

	void reset()
	{
		w.join();
		notes.clear();
		std::error_code ec;
		if (!dir.empty()) fs::remove_all(dir, ec);
		dir.clear();
		stemFile.clear();
		mixFile.clear();
		rate = 0;
		frames = 0;
		state = 0;
		log.clear();
	}
	void build(const core::SongInfo &si, int track, const std::vector<std::string> &keys)
	{
		reset();
		dir = g_tempRoot / std::to_wstring(++g_cacheCounter);
		std::error_code ec;
		fs::create_directories(dir, ec);
		state = 1;
		fs::path d = dir;
		w.start(3, [this, si, track, keys, d]() {
			Options o;
			o.outDir = d;
			o.mix = true;
			core::run(si, track, o);
			// map the files to the stems
			std::vector<fs::path> wavs;
			std::error_code ec2;
			for (auto &e : fs::recursive_directory_iterator(d, ec2))
				if (e.is_regular_file() && lower(u8(e.path().extension())) == ".wav") wavs.push_back(e.path());
			std::vector<fs::path> sf(keys.size());
			std::vector<char> used(wavs.size(), 0);
			for (size_t k = 0; k < keys.size(); ++k)
			{
				std::string want = sanitize(keys[k]);
				for (size_t i = 0; i < wavs.size(); ++i)
				{
					std::string st = u8(wavs[i].stem());
					if (!used[i] && st.size() >= want.size() && st.compare(st.size() - want.size(), want.size(), want) == 0)
					{
						sf[k] = wavs[i];
						used[i] = 1;
						break;
					}
				}
			}
			fs::path mix;
			for (size_t i = 0; i < wavs.size(); ++i) if (!used[i]) { mix = wavs[i]; break; }
			unsigned r = 0;
			long long fr = 0;
			for (auto &p : sf)
				if (!p.empty()) { WavInfo wi; if (readWavInfo(p, wi)) { r = wi.rate; fr = std::max(fr, wi.frames); } }
			if (!r && !mix.empty()) { WavInfo wi; if (readWavInfo(mix, wi)) { r = wi.rate; fr = wi.frames; } }
			if (!r) throw std::runtime_error("stem cache: no audio produced");
			stemFile = sf;
			mixFile = mix;
			rate = r;
			frames = fr;
		}, &log);
	}
	// called from the UI thread every frame
	int poll()
	{
		int f = w.finished.exchange(0);
		if (f == 1) state = 2;
		else if (f) state = 3;
		return f;
	}
	float progress()
	{
		std::vector<std::string> l;
		std::string c, lab;
		float fr = 0;
		log.snapshot(l, c);
		if (!parseProgress(c, lab, fr)) return 0;
		return overallProgress(lab, fr);
	}
};

// ================================================================ audio player
struct AudioPlayer
{
	enum Mode { None = 0, Stream = 1, Cache = 2 };
	std::atomic<int> mode{ None };
	std::thread prod, dev;
	std::atomic<bool> stopFlag{ false };
	std::atomic<bool> active{ false };    // device running
	std::atomic<bool> prodDone{ false };
	std::atomic<bool> buffering{ false };
	std::atomic<bool> paused{ false };
	std::atomic<long long> startFrame{ 0 };
	std::atomic<long long> playedFrames{ 0 };
	std::atomic<float> volume{ 0.8f };
	unsigned rate = 44100;
	std::string error;
	// stream source
	std::mutex m;
	std::condition_variable cv;
	std::deque<float> ring;
	size_t maxBuffered = 44100 * 2 * 3;
	// cache source
	struct CF { FILE *f; long long off; int stem; };
	std::vector<CF> files;
	long long cacheFrames = 0, cachePos = 0;
	const std::atomic<char> *mask = nullptr;
	// what was sent to the sound card (mono, after volume), for the screen "vibration"
	static const int SCOPE = 16384;
	float scope[SCOPE] = {};
	std::atomic<long long> scopeWritten{ 0 };
	// mono samples that are audible right now (oldest first)
	void scopeNow(float *outv, int n) const
	{
		long long end = playedFrames.load(), w = scopeWritten.load();
		if (end > w) end = w;
		for (int i = 0; i < n; ++i)
		{
			long long k = end - n + i;
			outv[i] = (k >= 0 && w - k < SCOPE) ? scope[k & (SCOPE - 1)] : 0.f;
		}
	}
	std::vector<int16_t> rd;

	double position() const { return (double)(startFrame + playedFrames) / (double)rate; }

	void startStream(const core::SongInfo &si, int track, double sec, bool startPaused = false)
	{
		stop();
		paused = startPaused;
		mode = Stream;
		rate = 44100;
		long long skip = (long long)(std::max(0.0, sec) * rate);
		startFrame = skip;
		playedFrames = 0;
		scopeWritten = 0;
		prodDone = false;
		buffering = true;
		stopFlag = false;
		ring.clear();
		core::SongInfo copy = si;
		prod = std::thread([this, copy, track, skip]() {
			t_quiet = true;
			long long toSkip = skip;
			Options o;
			o.preview = [this, &toSkip](const float *lr, size_t n) {
				if (toSkip > 0)
				{
					size_t d = (size_t)std::min<long long>(toSkip, (long long)n);
					toSkip -= d;
					lr += d * 2;
					n -= d;
					if (stopFlag) return false;
					if (!n) return true;
				}
				std::unique_lock<std::mutex> lk(m);
				cv.wait(lk, [&] { return stopFlag || ring.size() < maxBuffered; });
				if (stopFlag) return false;
				ring.insert(ring.end(), lr, lr + n * 2);
				cv.notify_all();
				return true;
			};
			try { core::run(copy, track, o); }
			catch (Cancelled &) {}
			catch (const std::exception &e) { std::lock_guard<std::mutex> lk(m); error = e.what(); }
			catch (...) {}
			prodDone = true;
			cv.notify_all();
		});
		active = true;
		dev = std::thread([this]() { deviceLoop(); });
	}

	bool startCache(const StemCache &c, const std::atomic<char> *liveMask, double sec, bool startPaused = false)
	{
		stop();
		paused = startPaused;
		files.clear();
		bool anyStem = false;
		for (size_t i = 0; i < c.stemFile.size(); ++i)
		{
			if (c.stemFile[i].empty()) continue;
			WavInfo wi;
			if (!readWavInfo(c.stemFile[i], wi)) continue;
			FILE *f = openFile(c.stemFile[i], "rb");
			if (!f) continue;
			files.push_back({ f, wi.dataOff, (int)i });
			anyStem = true;
		}
		if (!anyStem && !c.mixFile.empty())
		{
			WavInfo wi;
			FILE *f = readWavInfo(c.mixFile, wi) ? openFile(c.mixFile, "rb") : nullptr;
			if (f) files.push_back({ f, wi.dataOff, -1 });
		}
		if (files.empty()) return false;
		mode = Cache;
		rate = c.rate;
		cacheFrames = c.frames;
		mask = liveMask;
		cachePos = std::min<long long>((long long)(std::max(0.0, sec) * rate), cacheFrames);
		startFrame = cachePos;
		playedFrames = 0;
		scopeWritten = 0;
		buffering = false;
		stopFlag = false;
		active = true;
		dev = std::thread([this]() { deviceLoop(); });
		return true;
	}

	// fills interleaved stereo float; returns frames, 0 = nothing yet, -1 = end
	int pull(float *lr, int n)
	{
		if (mode == Stream)
		{
			std::unique_lock<std::mutex> lk(m);
			cv.wait_for(lk, std::chrono::milliseconds(25), [&] { return stopFlag || ring.size() >= (size_t)n * 2 || prodDone; });
			int k = 0;
			while (k < n && ring.size() >= 2)
			{
				lr[k * 2] = ring.front(); ring.pop_front();
				lr[k * 2 + 1] = ring.front(); ring.pop_front();
				++k;
			}
			cv.notify_all();
			if (k == 0 && prodDone) return -1;
			buffering = (k == 0);
			return k;
		}
		long long left = cacheFrames - cachePos;
		if (left <= 0) return -1;
		int k = (int)std::min<long long>(n, left);
		std::fill(lr, lr + k * 2, 0.f);
		rd.resize((size_t)k * 2);
		for (auto &cf : files)
		{
			if (cf.stem >= 0 && mask && !mask[cf.stem].load()) continue;
			_fseeki64(cf.f, cf.off + cachePos * 4, SEEK_SET);
			size_t got = fread(rd.data(), 4, (size_t)k, cf.f);
			for (size_t i = 0; i < got * 2; ++i) lr[i] += rd[i] * (1.f / 32768.f);
		}
		cachePos += k;
		return k;
	}

	void deviceLoop()
	{
		WAVEFORMATEX wf = {};
		wf.wFormatTag = WAVE_FORMAT_PCM;
		wf.nChannels = 2;
		wf.nSamplesPerSec = rate;
		wf.wBitsPerSample = 16;
		wf.nBlockAlign = 4;
		wf.nAvgBytesPerSec = rate * 4;
		HANDLE ev = CreateEventW(nullptr, FALSE, FALSE, nullptr);
		HWAVEOUT wo = nullptr;
		if (waveOutOpen(&wo, WAVE_MAPPER, &wf, (DWORD_PTR)ev, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR)
		{
			{ std::lock_guard<std::mutex> lk(m); error = "cannot open the audio device"; }
			active = false;
			CloseHandle(ev);
			return;
		}
		const int NB = 6, FR = 1536;
		std::vector<std::vector<int16_t>> bufs(NB, std::vector<int16_t>(FR * 2));
		std::vector<float> tmp(FR * 2);
		WAVEHDR hdr[NB] = {};
		for (int i = 0; i < NB; ++i)
		{
			hdr[i].lpData = (LPSTR)bufs[i].data();
			hdr[i].dwBufferLength = FR * 4;
			hdr[i].dwFlags = WHDR_DONE;
		}
		bool srcEnded = false;
		bool devPaused = false;
		while (!stopFlag)
		{
			bool p = paused;
			if (p != devPaused) { if (p) waveOutPause(wo); else waveOutRestart(wo); devPaused = p; }
			bool anyQueued = false;
			for (int i = 0; i < NB && !stopFlag; ++i)
			{
				if (!(hdr[i].dwFlags & WHDR_DONE)) { anyQueued = true; continue; }
				if (hdr[i].dwFlags & WHDR_PREPARED) waveOutUnprepareHeader(wo, &hdr[i], sizeof(WAVEHDR));
				if (srcEnded) continue;
				int n = pull(tmp.data(), FR);
				if (n < 0) { srcEnded = true; continue; }
				if (n == 0) continue;
				float vol = volume;
				for (int s = 0; s < n * 2; ++s)
				{
					long x = lrintf(tmp[s] * vol * 32767.f);
					bufs[i][s] = (int16_t)(x > 32767 ? 32767 : x < -32768 ? -32768 : x);
				}
				{
					long long wpos = scopeWritten.load();
					for (int s = 0; s < n; ++s) scope[(wpos + s) & (SCOPE - 1)] = 0.5f * (tmp[2 * s] + tmp[2 * s + 1]) * vol;
					scopeWritten = wpos + n;
				}
				hdr[i].dwBufferLength = n * 4;
				hdr[i].dwFlags = 0;
				waveOutPrepareHeader(wo, &hdr[i], sizeof(WAVEHDR));
				waveOutWrite(wo, &hdr[i], sizeof(WAVEHDR));
				anyQueued = true;
			}
			MMTIME mt = {};
			mt.wType = TIME_SAMPLES;
			if (waveOutGetPosition(wo, &mt, sizeof mt) == MMSYSERR_NOERROR && mt.wType == TIME_SAMPLES)
				playedFrames = (long long)mt.u.sample;
			if (srcEnded && !anyQueued) break;
			WaitForSingleObject(ev, 15);
		}
		waveOutReset(wo);
		for (int i = 0; i < NB; ++i)
			if (hdr[i].dwFlags & WHDR_PREPARED) waveOutUnprepareHeader(wo, &hdr[i], sizeof(WAVEHDR));
		waveOutClose(wo);
		CloseHandle(ev);
		active = false;
	}

	void stop()
	{
		stopFlag = true;
		cv.notify_all();
		if (prod.joinable()) prod.join();
		if (dev.joinable()) dev.join();
		for (auto &cf : files) fclose(cf.f);
		files.clear();
		active = false;
		paused = false;
		mode = None;
	}
};

// ================================================================ D3D11
static ID3D11Device *g_dev = nullptr;
static ID3D11DeviceContext *g_ctx = nullptr;
static IDXGISwapChain *g_swap = nullptr;
static ID3D11RenderTargetView *g_rtv = nullptr;
static UINT g_resizeW = 0, g_resizeH = 0;
static HWND g_hwnd = nullptr;

static void createRT()
{
	ID3D11Texture2D *bb = nullptr;
	g_swap->GetBuffer(0, IID_PPV_ARGS(&bb));
	if (bb) { g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv); bb->Release(); }
}
static void cleanupRT() { if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; } }
static bool createDevice(HWND hwnd)
{
	DXGI_SWAP_CHAIN_DESC sd = {};
	sd.BufferCount = 2;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;
	sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hwnd;
	sd.SampleDesc.Count = 1;
	sd.Windowed = TRUE;
	sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	D3D_FEATURE_LEVEL fl;
	const D3D_FEATURE_LEVEL fls[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
	HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
	if (hr == DXGI_ERROR_UNSUPPORTED)
		hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
	if (hr != S_OK) return false;
	createRT();
	return true;
}
static void cleanupDevice()
{
	cleanupRT();
	if (g_swap) { g_swap->Release(); g_swap = nullptr; }
	if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; }
	if (g_dev) { g_dev->Release(); g_dev = nullptr; }
}

static ID3D11ShaderResourceView *makeTexture(const uint8_t *rgba, int w, int h)
{
	D3D11_TEXTURE2D_DESC d = {};
	d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1;
	d.Format = DXGI_FORMAT_R8G8B8A8_UNORM; d.SampleDesc.Count = 1;
	d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	ID3D11Texture2D *tex = nullptr;
	D3D11_SUBRESOURCE_DATA sr = {};
	sr.pSysMem = rgba; sr.SysMemPitch = w * 4;
	if (FAILED(g_dev->CreateTexture2D(&d, &sr, &tex))) return nullptr;
	D3D11_SHADER_RESOURCE_VIEW_DESC sv = {};
	sv.Format = d.Format; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
	ID3D11ShaderResourceView *srv = nullptr;
	g_dev->CreateShaderResourceView(tex, &sv, &srv);
	tex->Release();
	return srv;
}

// ================================================================ animated GIF
struct Gif
{
	std::vector<ID3D11ShaderResourceView *> frames;
	std::vector<int> delays;
	int w = 0, h = 0;
	double t = 0;
	size_t cur = 0;
	void load(const uint8_t *data, size_t size)
	{
		if (!data) return;
		int *dl = nullptr, z = 0, comp = 0;
		stbi_uc *px = stbi_load_gif_from_memory(data, (int)size, &dl, &w, &h, &z, &comp, 4);
		if (!px) return;
		for (int i = 0; i < z; ++i)
		{
			frames.push_back(makeTexture(px + (size_t)i * w * h * 4, w, h));
			delays.push_back(dl && dl[i] > 10 ? dl[i] : 60);
		}
		stbi_image_free(px);
		if (dl) STBI_FREE(dl);
	}
	// one arm wave = 9 frames (0..8 and 9..17 are two waves); frac 0..1 inside the wave, frame 0 = arms up
	void setWave(long long wave, double frac)
	{
		if (frames.size() < 18) return;
		int base = (wave & 1) ? 9 : 0;
		double total = 0;
		for (int i = 0; i < 9; ++i) total += delays[base + i];
		double t = frac * total;
		int k = 0;
		while (k < 8 && t >= delays[base + k]) { t -= delays[base + k]; ++k; }
		cur = base + k;
	}
	void advance(double dt)
	{
		if (frames.empty()) return;
		t += dt * 1000.0;
		while (t >= delays[cur]) { t -= delays[cur]; cur = (cur + 1) % frames.size(); }
	}
};

// ================================================================ dialogs
static std::wstring widen(const char *s)
{
	int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
	std::wstring w(n > 0 ? n - 1 : 0, L'\0');
	if (n > 1) MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
	return w;
}
static bool pickFolder(std::wstring &outPath)
{
	IFileOpenDialog *d = nullptr;
	if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&d)))) return false;
	DWORD o; d->GetOptions(&o); d->SetOptions(o | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
	d->SetTitle(widen(tr("Where to save the stems", u8"Куда сохранять дорожки")).c_str());
	bool ok = false;
	if (SUCCEEDED(d->Show(g_hwnd)))
	{
		IShellItem *it = nullptr;
		if (SUCCEEDED(d->GetResult(&it)))
		{
			PWSTR p = nullptr;
			if (SUCCEEDED(it->GetDisplayName(SIGDN_FILESYSPATH, &p))) { outPath = p; CoTaskMemFree(p); ok = true; }
			it->Release();
		}
	}
	d->Release();
	return ok;
}
static bool pickFile(std::wstring &outPath)
{
	IFileOpenDialog *d = nullptr;
	if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&d)))) return false;
	std::wstring n1 = widen(tr("Game music", u8"Музыка из игр")), n2 = widen(tr("All files", u8"Все файлы"));
	COMDLG_FILTERSPEC f[2] = {
		{ n1.c_str(), L"*.mini2sf;*.2sf;*.minipsf;*.psf;*.minigsf;*.gsf;*.miniusf;*.usf;*.spc;*.vgm;*.vgz;*.nsf;*.nsfe;*.gbs;*.m3u" },
		{ n2.c_str(), L"*.*" } };
	d->SetFileTypes(2, f);
	d->SetTitle(widen(tr("Choose a music file", u8"Выбери файл с музыкой")).c_str());
	bool ok = false;
	if (SUCCEEDED(d->Show(g_hwnd)))
	{
		IShellItem *it = nullptr;
		if (SUCCEEDED(d->GetResult(&it)))
		{
			PWSTR p = nullptr;
			if (SUCCEEDED(it->GetDisplayName(SIGDN_FILESYSPATH, &p))) { outPath = p; CoTaskMemFree(p); ok = true; }
			it->Release();
		}
	}
	d->Release();
	return ok;
}

// ================================================================ application state
struct App
{
	// file
	bool loaded = false;
	fs::path src;
	core::SongInfo si;
	int track = 0;
	double duration = 0; // seconds incl. fade (0 = unknown)
	// stems
	std::mutex stemMx;
	std::vector<std::string> stems;
	std::vector<char> checked;
	std::unique_ptr<std::atomic<char>[]> live; // mirror of `checked` for the audio thread
	size_t liveN = 0;
	bool stemsReady = false;
	bool wantMix = false;
	// output
	fs::path outDir;
	bool outCustom = false;
	// jobs
	Worker worker;     // analysis / render
	StemCache cache;   // background stem renderer for live mixing
	Worker bpmW;       // tempo detection
	std::atomic<double> bpm{ 0 }, beatPhase{ 0 };
	std::atomic<int> bpmState{ 0 }; // 0 none, 1 running, 2 done
	AudioPlayer player;
	int lastFiles = 0;
	fs::path lastOut;
	double doneAt = -1;
	std::string message; double messageAt = -1; bool messageErr = false;
	// timeline
	bool scrubbing = false;
	float scrubFrac = 0;
	double pendingSeek = -1; // shown until the player catches up
	// visuals
	Gif konata;
	// playlist of the folder (single-track formats); multi-track files (NSF/GBS) use their own track list
	std::vector<fs::path> folderList;
	int folderIdx = -1;
	double t0 = nowSec();
	ImFont *fReg = nullptr, *fBold = nullptr, *fBig = nullptr, *fSmall = nullptr;
	float baseScale = 1.f;
	ImVec2 botMin, botMax; // bottom screen rect (client px), for drag & drop
	std::vector<std::wstring> pendingDrop;
	std::vector<std::wstring> pendingOpen; // opened from Explorer / another instance: load and play
	std::atomic<int> jobFiles{ -1 };      // files written by the last render job (-1 = count the log)
	std::mutex dropMx;
	ImVec2 dropPoint;
};
static App *g_app = nullptr;

static void say(App &a, const std::string &s, bool err = false) { a.message = s; a.messageAt = nowSec(); a.messageErr = err; }

static void stopAll(App &a)
{
	a.player.stop();
	a.cache.reset();
	a.bpmW.join();
	a.bpm = 0;
	a.bpmState = 0;
}

static void startBpm(App &a)
{
	a.bpm = 0;
	a.bpmState = 1;
	core::SongInfo si = a.si;
	int tr_ = a.track;
	a.bpmW.start(4, [&a, si, tr_]() {
		std::vector<float> mono;
		double secs = 0;
		gui_bpm(si, tr_, mono, secs);
		tempo::Result r = tempo::estimate(mono, 44100);
		a.beatPhase = r.firstBeat;
		a.bpm = r.bpm;
		a.bpmState = 2;
	});
}

static void startAnalysis(App &a)
{
	{ std::lock_guard<std::mutex> lk(a.stemMx); a.stems.clear(); a.checked.clear(); a.stemsReady = false; }
	a.live.reset();
	a.liveN = 0;
	a.duration = 0;
	g_log.clear();
	core::SongInfo si = a.si;
	int tr_ = a.track;
	a.worker.start(1, [&a, si, tr_]() {
		std::vector<Options::StemDesc> st;
		Options o;
		o.analysis = &st;
		t_songSeconds = 0;
		core::run(si, tr_, o);
		double secs = t_songSeconds;
		std::lock_guard<std::mutex> lk(a.stemMx);
		for (auto &s : st) { a.stems.push_back(s.key); a.checked.push_back(1); }
		a.duration = secs;
		a.stemsReady = true;
	});
}

static bool isMusicFile(const fs::path &p)
{
	std::string e = lower(u8(p.extension()));
	static const char *ok[] = { ".mini2sf", ".2sf", ".minipsf", ".psf", ".minigsf", ".gsf", ".miniusf", ".usf", ".spc", ".vgm", ".vgz", ".nsf", ".nsfe", ".gbs", ".m3u" };
	for (auto *x : ok) if (e == x) return true;
	return false;
}

// natural order: "2 x" before "10 x"
static bool naturalLess(const std::wstring &x, const std::wstring &y)
{
	size_t i = 0, j = 0;
	while (i < x.size() && j < y.size())
	{
		if (iswdigit(x[i]) && iswdigit(y[j]))
		{
			size_t i2 = i, j2 = j;
			while (i2 < x.size() && iswdigit(x[i2])) ++i2;
			while (j2 < y.size() && iswdigit(y[j2])) ++j2;
			std::wstring a = x.substr(i, i2 - i), b = y.substr(j, j2 - j);
			a.erase(0, std::min(a.find_first_not_of(L'0'), a.size() - 1));
			b.erase(0, std::min(b.find_first_not_of(L'0'), b.size() - 1));
			if (a.size() != b.size()) return a.size() < b.size();
			if (a != b) return a < b;
			i = i2; j = j2;
			continue;
		}
		wchar_t c1 = towlower(x[i]), c2 = towlower(y[j]);
		if (c1 != c2) return c1 < c2;
		++i; ++j;
	}
	return x.size() - i < y.size() - j;
}

static void buildFolderList(App &a, const fs::path &p)
{
	a.folderList.clear();
	a.folderIdx = -1;
	std::error_code ec;
	fs::path dir = p.parent_path();
	std::vector<fs::path> files;
	std::set<std::wstring> covered; // music files that an .m3u playlist already lists (NSF/GBS)
	for (auto &e : fs::directory_iterator(dir, ec))
	{
		if (!e.is_regular_file(ec) || !isMusicFile(e.path())) continue;
		files.push_back(e.path());
	}
	for (auto &f : files)
		if (lower(u8(f.extension())) == ".m3u")
		{
			fs::path target;
			std::vector<gmesplit::Job> jobs;
			try { gmesplit::collectJobs(f, target, jobs); covered.insert(fs::absolute(target).wstring()); } catch (...) {}
		}
	for (auto &f : files)
	{
		std::wstring ab = fs::absolute(f).wstring();
		if (covered.count(ab) && fs::absolute(p).wstring() != ab) continue;
		a.folderList.push_back(f);
	}
	std::sort(a.folderList.begin(), a.folderList.end(), [](const fs::path &x, const fs::path &y) { return naturalLess(x.filename().wstring(), y.filename().wstring()); });
	for (size_t i = 0; i < a.folderList.size(); ++i)
		if (fs::equivalent(a.folderList[i], p, ec)) a.folderIdx = (int)i;
}

static void loadFile(App &a, const fs::path &p)
{
	if (a.worker.busy && a.worker.kind == 2) { say(a, tr("Wait for the render to finish (or press Cancel)", u8"Сначала дождись окончания рендера (или нажми «Отмена»)"), true); return; }
	core::SongInfo si;
	try { si = core::probe(p); }
	catch (const std::exception &e) { say(a, std::string(tr("Cannot open: ", u8"Не получилось открыть: ")) + e.what(), true); return; }
	a.worker.join();
	stopAll(a);
	a.si = si;
	a.src = p;
	a.loaded = true;
	a.track = 0;
	a.doneAt = -1;
	a.lastFiles = 0;
	a.pendingSeek = -1;
	if (!a.outCustom) a.outDir = si.file.parent_path();
	// folder playlist (rescan only when the file comes from somewhere else)
	{
		std::error_code ec;
		int idx = -1;
		for (size_t i = 0; i < a.folderList.size(); ++i)
			if (fs::equivalent(a.folderList[i], p, ec)) { idx = (int)i; break; }
		if (idx < 0) buildFolderList(a, p);
		else a.folderIdx = idx;
	}
	startAnalysis(a);
}

static void closeFile(App &a)
{
	if (a.worker.busy && a.worker.kind == 2) { say(a, tr("Rendering — press Cancel first", u8"Идёт рендер — сначала «Отмена»"), true); return; }
	a.worker.join();
	stopAll(a);
	a.loaded = false;
	{ std::lock_guard<std::mutex> lk(a.stemMx); a.stems.clear(); a.checked.clear(); a.stemsReady = false; }
	a.live.reset();
	a.liveN = 0;
	a.duration = 0;
	g_log.clear();
}

static void changeTrack(App &a, int i)
{
	a.worker.join();
	stopAll(a);
	a.track = i;
	a.doneAt = -1;
	a.pendingSeek = -1;
	startAnalysis(a);
}

// rendered stem: WAV file + its stem key (empty key = full mix)
struct RenderedStem { fs::path file; std::string key; };

static std::vector<RenderedStem> mapStems(const std::vector<fs::path> &wavs, const std::vector<std::string> &keys)
{
	std::vector<RenderedStem> r;
	std::vector<char> used(wavs.size(), 0);
	for (auto &k : keys)
	{
		std::string want = sanitize(k);
		for (size_t i = 0; i < wavs.size(); ++i)
		{
			std::string st = u8(wavs[i].stem());
			if (!used[i] && st.size() >= want.size() && st.compare(st.size() - want.size(), want.size(), want) == 0)
			{ r.push_back({ wavs[i], k }); used[i] = 1; break; }
		}
	}
	for (size_t i = 0; i < wavs.size(); ++i) if (!used[i]) r.push_back({ wavs[i], "" });
	return r;
}

// notes of a stem: exact ones if the format provides them, otherwise estimated from the audio
static std::vector<NoteEv> stemNotes(const RenderedStem &st, const NoteMap &exact)
{
	auto it = exact.find(st.key);
	if (it != exact.end()) return it->second;
	std::vector<float> mono;
	unsigned rate = 0;
	if (!notes::readMono(st.file, mono, rate)) return {};
	return notes::detect(mono, rate);
}

// writes the stems (relative to `root`) into the output folder in the chosen format
static int saveConverted(const std::vector<RenderedStem> &items, const fs::path &root, const fs::path &od, int format,
	bool markers, const NoteMap &exact, double bpm, const std::string &songName)
{
	int n = 0, total = (int)items.size();
	if (format == FMT_MIDI)
	{
		std::vector<std::pair<std::string, std::vector<NoteEv>>> tracks;
		for (auto &it : items)
		{
			if (it.key.empty()) continue; // full mix has no notes
			out(fmt("\r  notes %d/%d... %d%%", (int)tracks.size() + 1, total, 0));
			tracks.push_back({ it.key, stemNotes(it, exact) });
		}
		std::error_code ec2;
		fs::create_directories(od, ec2);
		fs::path dst = od / fs::u8path(sanitize(songName + ".mid"));
		notes::writeMidi(dst, tracks, bpm);
		out("\r  -> " + u8(dst.filename()) + "\n");
		out(fmt("  1 file(s) saved to: %s\n", u8(od).c_str()));
		return 1;
	}
	for (auto &it : items)
	{
		const fs::path &f = it.file;
		fs::path rel = fs::relative(f, root);
		fs::path dst = od / rel;
		dst.replace_extension(enc::ext(format));
		std::error_code ec2;
		fs::create_directories(dst.parent_path(), ec2);
		int lastPct = -1;
		const char *verb = format == enc::WAV ? "copying" : "encoding";
		out(fmt("\r  %s %d/%d... 0%%", verb, n + 1, total));
		enc::convert(f, dst, format, [&](float fr) {
			int pct = (int)(fr * 100);
			if (pct != lastPct) { lastPct = pct; out(fmt("\r  %s %d/%d... %d%%", verb, n + 1, total, pct)); }
		});
		if (markers && !it.key.empty())
		{
			out(fmt("\r  markers %d/%d... 99%%", n + 1, total));
			std::vector<NoteEv> ns = stemNotes(it, exact);
			fs::path lab = dst;
			lab.replace_extension(".txt");
			notes::writeLabels(lab, ns);
			if (format == enc::WAV)
			{
				enc::WavInfo wi;
				if (enc::readWavInfo(dst, wi)) notes::embedCues(dst, ns, wi.rate);
			}
		}
		++n;
		out("\r  -> " + u8(dst.filename()) + "\n");
	}
	out(fmt("  %d file(s) saved to: %s\n", n, u8(od).c_str()));
	return n;
}

static void startRender(App &a)
{
	if (!a.loaded || !a.stemsReady || a.worker.busy) return;
	auto only = std::make_shared<std::set<std::string>>();
	std::vector<RenderedStem> copyList;
	std::vector<std::string> keys;
	bool fromCache = a.cache.state == 2;
	int fmt_ = g_fmt;
	bool mix = a.wantMix && fmt_ != FMT_MIDI;
	{
		std::lock_guard<std::mutex> lk(a.stemMx);
		for (size_t i = 0; i < a.stems.size(); ++i)
			if (a.checked[i])
			{
				only->insert(a.stems[i]);
				keys.push_back(a.stems[i]);
				if (fromCache)
				{
					if (i < a.cache.stemFile.size() && !a.cache.stemFile[i].empty()) copyList.push_back({ a.cache.stemFile[i], a.stems[i] });
					else fromCache = false;
				}
			}
	}
	if (only->empty() && !mix) { say(a, tr("Tick at least one stem", u8"Отметь хотя бы одну дорожку"), true); return; }
	if (fromCache && mix)
	{
		if (a.cache.mixFile.empty()) fromCache = false;
		else copyList.push_back({ a.cache.mixFile, "" });
	}
	std::error_code ec;
	fs::create_directories(a.outDir, ec);
	g_log.clear();
	a.doneAt = -1;
	a.jobFiles = -1;
	core::SongInfo si = a.si;
	int tr_ = a.track;
	fs::path od = a.outDir;
	a.lastOut = od;
	App *ap = &a;
	bool markers = g_markers && fmt_ != FMT_MIDI;
	double bpm = a.bpm > 0 ? (double)a.bpm : 120.0;
	std::string songName = u8(a.src.stem());
	if (a.si.tracks.size() > 1) songName += " - " + a.si.tracks[a.track];
	if (fromCache)
	{
		fs::path cdir = a.cache.dir;
		auto exact = std::make_shared<NoteMap>(a.cache.notes);
		a.worker.start(2, [ap, copyList, cdir, od, fmt_, markers, exact, bpm, songName]() {
			ap->jobFiles = saveConverted(copyList, cdir, od, fmt_, markers, *exact, bpm, songName);
		});
	}
	else
	{
		// render WAVs into a staging folder, then write them into the output folder in the chosen format
		fs::path stg = g_tempRoot / (L"render" + std::to_wstring(++g_cacheCounter));
		a.worker.start(2, [ap, si, tr_, od, mix, only, keys, stg, fmt_, markers, bpm, songName]() {
			std::error_code e1;
			fs::create_directories(stg, e1);
			struct Cleanup { fs::path p; ~Cleanup() { std::error_code e; fs::remove_all(p, e); } } cl{ stg };
			std::function<void(const std::string &)> filt = [](const std::string &s) {
				if (s.find("-> ") != std::string::npos || s.find("saved to:") != std::string::npos) return;
				g_log.add(s);
			};
			NoteMap exact;
			Options o;
			o.only = only.get();
			o.outDir = stg;
			o.mix = mix;
			t_sink = &filt;
			try { core::run(si, tr_, o); }
			catch (...) { t_sink = nullptr; throw; }
			t_sink = nullptr;
			std::vector<fs::path> wavs;
			for (auto &e : fs::recursive_directory_iterator(stg, e1))
				if (e.is_regular_file() && lower(u8(e.path().extension())) == ".wav") wavs.push_back(e.path());
			std::sort(wavs.begin(), wavs.end());
			ap->jobFiles = saveConverted(mapStems(wavs, keys), stg, od, fmt_, markers, exact, bpm, songName);
		});
	}
}

static void playAt(App &a, double sec, bool startPaused = false)
{
	if (!a.loaded) return;
	if (a.duration > 0) sec = std::min(sec, std::max(0.0, a.duration - 0.05));
	sec = std::max(0.0, sec);
	if (a.cache.state == 2 && a.live && a.player.startCache(a.cache, a.live.get(), sec, startPaused)) { a.pendingSeek = -1; return; }
	a.player.startStream(a.si, a.track, sec, startPaused);
	a.pendingSeek = sec > 0.5 ? sec : -1;
}

// one list for both kinds: the tracks of a multi-track file, otherwise the files of the folder
static int playlistSize(const App &a) { return a.si.tracks.size() > 1 ? (int)a.si.tracks.size() : (int)a.folderList.size(); }
static int playlistPos(const App &a) { return a.si.tracks.size() > 1 ? a.track : a.folderIdx; }
static void playlistGo(App &a, int i)
{
	if (!a.loaded || i < 0 || i >= playlistSize(a)) return;
	if (a.worker.busy && a.worker.kind == 2) { say(a, tr("Wait for the render to finish (or press Cancel)", u8"Сначала дождись окончания рендера (или нажми «Отмена»)"), true); return; }
	if (a.si.tracks.size() > 1) changeTrack(a, i);
	else loadFile(a, a.folderList[i]);
	playAt(a, 0);
}

static void togglePlay(App &a) // play / pause
{
	if (!a.loaded) return;
	if (!a.player.active) playAt(a, 0);
	else a.player.paused = !a.player.paused;
}

static void playPoupe()
{
	auto r = resource(RES_POUPE_WAV);
	if (r.first) PlaySoundW((LPCWSTR)r.first, nullptr, SND_MEMORY | SND_ASYNC | SND_NODEFAULT);
}

// ================================================================ drawing helpers
static ImU32 rgb(int r, int g, int b, int a = 255) { return IM_COL32(r, g, b, a); }

struct Map
{
	ImVec2 o; float s;
	ImVec2 operator()(float x, float y) const { return ImVec2(o.x + x * s, o.y + y * s); }
	float operator()(float v) const { return v * s; }
};

static void roundGrad(ImDrawList *dl, ImVec2 a, ImVec2 b, ImU32 top, ImU32 bot, float r)
{
	dl->AddRectFilled(a, b, bot, r);
	int steps = 12;
	for (int i = 0; i < steps; ++i)
	{
		float t0 = (float)i / steps, t1 = (float)(i + 1) / steps;
		ImVec4 ct = ImGui::ColorConvertU32ToFloat4(top), cb = ImGui::ColorConvertU32ToFloat4(bot);
		ImVec4 c(ct.x + (cb.x - ct.x) * t0, ct.y + (cb.y - ct.y) * t0, ct.z + (cb.z - ct.z) * t0, 1);
		float y0 = a.y + (b.y - a.y) * t0, y1 = a.y + (b.y - a.y) * t1;
		ImDrawFlags fl = i == 0 ? ImDrawFlags_RoundCornersTop : (i == steps - 1 ? ImDrawFlags_RoundCornersBottom : ImDrawFlags_RoundCornersNone);
		dl->AddRectFilled(ImVec2(a.x, y0), ImVec2(b.x, y1 + 0.5f), ImGui::ColorConvertFloat4ToU32(c), (i == 0 || i == steps - 1) ? r : 0, fl);
	}
}

static void textCentered(ImDrawList *dl, ImFont *f, float size, ImVec2 c, ImU32 col, const std::string &s)
{
	ImVec2 sz = f->CalcTextSizeA(size, FLT_MAX, 0, s.c_str());
	dl->AddText(f, size, ImVec2(c.x - sz.x / 2, c.y - sz.y / 2), col, s.c_str());
}

static std::string ellipsize(ImFont *f, float size, const std::string &s, float maxW)
{
	if (f->CalcTextSizeA(size, FLT_MAX, 0, s.c_str()).x <= maxW) return s;
	std::string t = s;
	while (!t.empty())
	{
		size_t k = t.size() - 1;
		while (k > 0 && (((unsigned char)t[k]) & 0xC0) == 0x80) --k;
		t.erase(k);
		if (f->CalcTextSizeA(size, FLT_MAX, 0, (t + "…").c_str()).x <= maxW) return t + "…";
	}
	return "…";
}

static bool consoleButton(const char *id, ImVec2 c, float r, ImU32 col, const char *label, ImFont *f, float fs, const char *tip)
{
	ImGui::SetCursorScreenPos(ImVec2(c.x - r, c.y - r));
	bool clicked = ImGui::InvisibleButton(id, ImVec2(r * 2, r * 2));
	bool hov = ImGui::IsItemHovered(), act = ImGui::IsItemActive();
	ImDrawList *dl = ImGui::GetWindowDrawList();
	dl->AddCircleFilled(ImVec2(c.x, c.y + r * 0.12f), r, rgb(10, 10, 12, 160), 32);
	ImVec4 cc = ImGui::ColorConvertU32ToFloat4(col);
	float k = act ? 0.75f : hov ? 1.15f : 1.f;
	ImU32 c2 = ImGui::ColorConvertFloat4ToU32(ImVec4(std::min(1.f, cc.x * k), std::min(1.f, cc.y * k), std::min(1.f, cc.z * k), 1));
	dl->AddCircleFilled(ImVec2(c.x, c.y + (act ? r * 0.08f : 0)), r, c2, 32);
	dl->AddCircle(ImVec2(c.x, c.y + (act ? r * 0.08f : 0)), r, rgb(255, 255, 255, 50), 32, 1.5f);
	if (label) textCentered(dl, f, fs, ImVec2(c.x, c.y + (act ? r * 0.08f : 0)), rgb(255, 255, 255, 230), label);
	if (hov && tip) ImGui::SetTooltip("%s", tip);
	return clicked;
}

static bool pillButton(const char *id, ImVec2 a, ImVec2 b, const char *label, ImFont *f, float fs, const char *tip)
{
	ImGui::SetCursorScreenPos(a);
	bool clicked = ImGui::InvisibleButton(id, ImVec2(b.x - a.x, b.y - a.y));
	bool hov = ImGui::IsItemHovered(), act = ImGui::IsItemActive();
	ImDrawList *dl = ImGui::GetWindowDrawList();
	dl->AddRectFilled(a, b, act ? rgb(20, 21, 24) : hov ? rgb(70, 72, 78) : rgb(44, 46, 51), (b.y - a.y) / 2);
	dl->AddRect(a, b, rgb(255, 255, 255, 40), (b.y - a.y) / 2);
	textCentered(dl, f, fs, ImVec2((a.x + b.x) / 2, (a.y + b.y) / 2), rgb(200, 202, 208), label);
	if (hov && tip) ImGui::SetTooltip("%s", tip);
	return clicked;
}

static bool touchButton(const char *label, ImVec2 size, ImU32 base, ImU32 text, bool enabled = true)
{
	ImGui::PushStyleColor(ImGuiCol_Button, base);
	ImVec4 b = ImGui::ColorConvertU32ToFloat4(base);
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(std::min(1.f, b.x * 1.08f + 0.03f), std::min(1.f, b.y * 1.08f + 0.03f), std::min(1.f, b.z * 1.08f + 0.03f), 1));
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(b.x * 0.85f, b.y * 0.85f, b.z * 0.85f, 1));
	ImGui::PushStyleColor(ImGuiCol_Text, text);
	ImGui::BeginDisabled(!enabled);
	bool r = ImGui::Button(label, size);
	ImGui::EndDisabled();
	ImGui::PopStyleColor(4);
	return r;
}

static const ImU32 C_ACCENT = IM_COL32(25, 180, 230, 255);
static const ImU32 C_TEXT = IM_COL32(40, 44, 52, 255);
static const ImU32 C_SUB = IM_COL32(110, 116, 128, 255);
static const ImU32 C_ORANGE = IM_COL32(230, 120, 20, 255);

// diagonal stripes; `shift` moves them (pixels), `wave` (256 values, -1..1) bends them, `amp` = pixels
static void drawStripes(ImDrawList *dl, ImVec2 a, ImVec2 b, ImU32 bg, ImU32 line, float step,
	float shift = 0, const float *wave = nullptr, float amp = 0)
{
	dl->AddRectFilled(a, b, bg);
	dl->PushClipRect(a, b, true);
	float h = b.y - a.y;
	float off = std::fmod(shift, step);
	if (off < 0) off += step;
	int k = 0;
	for (float x = a.x - h - step + off; x < b.x + step; x += step, ++k)
	{
		if (!wave || amp < 0.05f)
		{
			dl->AddLine(ImVec2(x, b.y), ImVec2(x + h, a.y), line, step * 0.35f);
			continue;
		}
		const int SEG = 14;
		ImVec2 pts[SEG + 1];
		for (int j = 0; j <= SEG; ++j)
		{
			float u = (float)j / SEG;
			float wv = wave[(j * 9 + k * 23) & 255];
			pts[j] = ImVec2(x + h * u + wv * amp, b.y - h * u);
		}
		dl->AddPolyline(pts, SEG + 1, line, ImDrawFlags_None, step * 0.35f);
	}
	dl->PopClipRect();
}

static void drawProgressBar(ImDrawList *dl, ImVec2 a, ImVec2 b, float frac, ImU32 fill)
{
	float r = (b.y - a.y) / 2;
	dl->AddRectFilled(a, b, rgb(214, 218, 225), r);
	if (frac > 0.001f)
		dl->AddRectFilled(a, ImVec2(a.x + std::max(r * 2, (b.x - a.x) * std::min(1.f, frac)), b.y), fill, r);
}

// ================================================================ the frame
static void frame(App &a, float W, float H, double dt)
{
	ImGuiIO &io = ImGui::GetIO();
	float s = std::min(W / 720.f, H / 940.f);
	Map M{ ImVec2((W - 720 * s) / 2, (H - 940 * s) / 2), s };
	if (s > 0.05f) io.FontGlobalScale = s / a.baseScale;
	float fsz = 17.f * s, fsmall = 14.f * s, fbig = 26.f * s;

	// ---------------- events
	int fin = a.worker.finished.exchange(0);
	if (fin)
	{
		if (a.worker.kind == 2)
		{
			if (fin == 1)
			{
				std::vector<std::string> l; std::string c;
				g_log.snapshot(l, c);
				int files = 0;
				for (auto &x : l) if (x.rfind("->", 0) == 0 && x.find(" - stems") == std::string::npos) ++files;
				a.lastFiles = a.jobFiles >= 0 ? a.jobFiles.load() : files;
				a.doneAt = nowSec();
				playPoupe();
			}
			else if (fin == 2) say(a, tr("Render cancelled", u8"Рендер отменён"));
			else { std::lock_guard<std::mutex> lk(a.worker.m); say(a, std::string(tr("Error: ", u8"Ошибка: ")) + a.worker.error, true); }
		}
		else if (a.worker.kind == 1)
		{
			if (fin == 1)
			{
				std::vector<std::string> keys;
				{
					std::lock_guard<std::mutex> lk(a.stemMx);
					keys = a.stems;
					a.liveN = a.stems.size();
					a.live.reset(new std::atomic<char>[std::max<size_t>(1, a.liveN)]);
					for (size_t i = 0; i < a.liveN; ++i) a.live[i] = a.checked[i];
				}
				a.cache.build(a.si, a.track, keys); // prepare stems for live mixing
				startBpm(a);
			}
			else if (fin == 3) { std::lock_guard<std::mutex> lk(a.worker.m); say(a, std::string(tr("Analysis error: ", u8"Ошибка анализа: ")) + a.worker.error, true); }
		}
	}
	if (int cf = a.cache.poll())
	{
		if (cf == 1)
		{
			if (a.duration <= 0 && a.cache.rate) a.duration = (double)a.cache.frames / a.cache.rate;
			// switch the running playback to live stem mixing at the same position
			if (a.player.active && a.player.mode == AudioPlayer::Stream && !a.player.buffering)
			{
				double pos = a.player.position();
				a.player.startCache(a.cache, a.live.get(), pos, a.player.paused);
			}
		}
	}
	// live mask
	if (a.live)
	{
		std::lock_guard<std::mutex> lk(a.stemMx);
		for (size_t i = 0; i < a.liveN && i < a.checked.size(); ++i) a.live[i] = a.checked[i];
	}
	// drops
	{
		std::vector<std::wstring> drops;
		ImVec2 dp;
		{ std::lock_guard<std::mutex> lk(a.dropMx); drops.swap(a.pendingDrop); dp = a.dropPoint; }
		if (!drops.empty())
		{
			bool onBottom = dp.x >= a.botMin.x && dp.x <= a.botMax.x && dp.y >= a.botMin.y && dp.y <= a.botMax.y;
			if (!onBottom) say(a, tr("Drop the file onto the bottom screen", u8"Кидай файл на нижний экран"), true);
			else
			{
				loadFile(a, fs::path(drops[0]));
				if (drops.size() > 1) say(a, tr("Opened the first file (one at a time)", u8"Открыт первый файл (по одному за раз)"));
			}
		}
	}
	{
		std::vector<std::wstring> opens;
		{ std::lock_guard<std::mutex> lk(a.dropMx); opens.swap(a.pendingOpen); }
		if (!opens.empty())
		{
			loadFile(a, fs::path(opens.back()));
			if (a.loaded && a.src == fs::path(opens.back())) playAt(a, 0);
		}
	}
	bool playing = a.player.active;
	bool isPaused = playing && a.player.paused;
	if (a.pendingSeek >= 0 && (!playing || !a.player.buffering)) a.pendingSeek = -1;
	if (a.bpmW.finished.exchange(0) && a.bpmState == 1) a.bpmState = 2; // failed / short track: no BPM
	if (playing && !isPaused && !a.player.buffering)
	{
		double bpmNow = a.bpm;
		if (bpmNow > 0)
		{
			double wpb = bpmNow > 190 ? 0.5 : 1.0; // arm waves per beat: arms up on every beat (every 2nd if very fast)
			double beats = (a.player.position() - a.beatPhase) * bpmNow / 60.0 * wpb;
			double w = std::floor(beats);
			a.konata.setWave((long long)w, beats - w);
		}
		else a.konata.advance(dt);
	}
	if (W < 64 || H < 64) return; // minimized
	bool rendering = a.worker.busy && a.worker.kind == 2;
	bool analyzing = a.worker.busy && a.worker.kind == 1;
	bool liveMode = playing && a.player.mode == AudioPlayer::Cache;
	double t = nowSec() - a.t0;
	// screen "vibration": a smoothed snapshot of the sound that is playing now
	float wave[256] = {};
	float waveAmp = 0;
	if (playing && !isPaused && !a.player.buffering)
	{
		static float raw[2048];
		a.player.scopeNow(raw, 2048);
		static float agc = 0.05f;
		float pk = 1e-4f;
		for (int i = 0; i < 256; ++i)
		{
			float m = 0;
			for (int k = 0; k < 8; ++k) m += raw[i * 8 + k];
			wave[i] = m / 8;
			pk = std::max(pk, std::fabs(wave[i]));
		}
		agc = std::max(pk, agc * 0.97f); // slow automatic gain so quiet music still moves the stripes
		for (auto &v : wave) v = std::max(-1.f, std::min(1.f, v / std::max(agc, 0.02f)));
		waveAmp = 1.f;
	}
	float stripeShift = -(float)t * 10.f * s; // slowly to the left
	double dur = a.duration;
	if (dur <= 0 && a.cache.state == 2 && a.cache.rate) dur = (double)a.cache.frames / a.cache.rate;

	// ------------------------------------------------ shell (background window)
	ImGui::SetNextWindowPos(ImVec2(0, 0));
	ImGui::SetNextWindowSize(ImVec2(W, H));
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGui::Begin("##shell", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus |
		ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollWithMouse);
	ImDrawList *dl = ImGui::GetWindowDrawList();
	dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(W, H), rgb(30, 31, 36), rgb(30, 31, 36), rgb(16, 17, 20), rgb(16, 17, 20));
	roundGrad(dl, M(20, 12), M(700, 470), rgb(62, 64, 71), rgb(36, 37, 42), M(30));
	dl->AddRect(M(20, 12), M(700, 470), rgb(255, 255, 255, 28), M(30), 0, M(1.5f));
	roundGrad(dl, M(36, 462), M(684, 506), rgb(22, 23, 26), rgb(48, 50, 56), M(16));
	dl->AddLine(M(60, 484), M(660, 484), rgb(255, 255, 255, 18), M(1));
	roundGrad(dl, M(20, 498), M(700, 932), rgb(52, 54, 60), rgb(30, 31, 35), M(30));
	dl->AddRect(M(20, 498), M(700, 932), rgb(255, 255, 255, 24), M(30), 0, M(1.5f));
	for (int side = 0; side < 2; ++side)
	{
		float x0 = side == 0 ? 30.f : 676.f;
		for (int r = 0; r < 9; ++r)
			for (int c = 0; c < 3; ++c)
				dl->AddCircleFilled(M(x0 + c * 6.5f, 190 + r * 9 + (c % 2) * 4.5f), M(1.7f), rgb(12, 12, 14), 8);
	}
	dl->AddCircleFilled(M(360, 30), M(5), rgb(8, 8, 10), 16);
	dl->AddCircleFilled(M(360, 30), M(2.2f), rgb(40, 50, 90), 12);
	dl->AddRectFilled(M(50, 44), M(670, 424), rgb(8, 8, 10), M(14));
	ImVec2 tsA = M(60, 54), tsB = M(660, 414); // 600 x 360 (5:3)
	// 3D slider = volume
	{
		ImVec2 sa = M(678, 60), sb = M(690, 170);
		dl->AddRectFilled(sa, sb, rgb(14, 14, 16), M(6));
		float v = a.player.volume;
		float ky = sb.y - M(10) - (sb.y - sa.y - M(20)) * v;
		ImGui::SetCursorScreenPos(ImVec2(sa.x - M(6), sa.y));
		ImGui::InvisibleButton("##vol", ImVec2(sb.x - sa.x + M(12), sb.y - sa.y));
		if (ImGui::IsItemActive())
		{
			float nv = (sb.y - M(10) - io.MousePos.y) / (sb.y - sa.y - M(20));
			a.player.volume = std::max(0.f, std::min(1.f, nv));
		}
		if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s: %d%%", tr("Volume", u8"Громкость"), (int)(a.player.volume * 100));
		dl->AddRectFilled(ImVec2(sa.x - M(3), ky - M(7)), ImVec2(sb.x + M(3), ky + M(7)), rgb(150, 154, 162), M(4));
		textCentered(dl, a.fSmall, fsmall * 0.8f, M(684, 182), rgb(150, 154, 162), "VOL");
	}
	float pulse = 0.5f + 0.5f * sinf((float)t * 4.f);
	dl->AddCircleFilled(M(84, 440), M(3.5f), playing ? rgb(60, 170, 255, (int)(140 + 115 * pulse)) : rgb(35, 70, 110), 12);
	dl->AddCircleFilled(M(100, 440), M(3.5f), rendering ? rgb(255, 150, 40, (int)(140 + 115 * pulse)) : rgb(90, 60, 30), 12);
	dl->AddText(a.fBold, fsmall, M(560, 434), rgb(150, 154, 162), "PUPUE SPLITTER");

	dl->AddRectFilled(M(110, 518), M(610, 898), rgb(8, 8, 10), M(12));
	ImVec2 bsA = M(120, 528), bsB = M(600, 888); // 480 x 360 (4:3)
	a.botMin = bsA; a.botMax = bsB;
	dl->AddCircleFilled(M(66, 590), M(34), rgb(20, 21, 24), 40);
	dl->AddCircleFilled(M(66, 590), M(26), rgb(70, 72, 79), 40);
	dl->AddCircle(M(66, 590), M(20), rgb(255, 255, 255, 25), 40, M(1));
	{
		ImVec2 c = M(66, 712);
		float w = M(13), L = M(36);
		dl->AddRectFilled(ImVec2(c.x - w, c.y - L), ImVec2(c.x + w, c.y + L), rgb(24, 25, 28), M(4));
		dl->AddRectFilled(ImVec2(c.x - L, c.y - w), ImVec2(c.x + L, c.y + w), rgb(24, 25, 28), M(4));
		dl->AddCircleFilled(c, M(6), rgb(40, 42, 46), 16);
		// D-pad left / right = previous / next track
		for (int side = 0; side < 2; ++side)
		{
			ImVec2 pa = side == 0 ? ImVec2(c.x - L, c.y - w) : ImVec2(c.x + w, c.y - w);
			ImGui::SetCursorScreenPos(pa);
			ImGui::PushID(side);
			bool clicked = ImGui::InvisibleButton("##dpad", ImVec2(L - w, 2 * w));
			bool hov = ImGui::IsItemHovered(), act = ImGui::IsItemActive();
			ImGui::PopID();
			if (hov || act) dl->AddRectFilled(pa, ImVec2(pa.x + L - w, pa.y + 2 * w), act ? rgb(10, 10, 12) : rgb(44, 46, 52), M(4));
			float ax = side == 0 ? c.x - L + M(8) : c.x + L - M(8), dir = side == 0 ? -1.f : 1.f;
			dl->AddTriangleFilled(ImVec2(ax, c.y), ImVec2(ax - dir * M(7), c.y - M(5)), ImVec2(ax - dir * M(7), c.y + M(5)), rgb(80, 84, 92));
			if (hov) ImGui::SetTooltip("%s", side == 0 ? tr("Previous track", u8"Предыдущий трек") : tr("Next track", u8"Следующий трек"));
			if (clicked && a.loaded) playlistGo(a, playlistPos(a) + (side == 0 ? -1 : 1));
		}
	}
	bool canRender = a.loaded && a.stemsReady && !a.worker.busy;
	if (consoleButton("##A", M(683, 632), M(13), rgb(214, 48, 49), "A", a.fBold, fsz, tr("A — Render the ticked stems", u8"A — Рендер выбранных дорожек"))) startRender(a);
	if (consoleButton("##B", M(662, 653), M(13), rgb(240, 180, 30), "B", a.fBold, fsz, tr("B — Stop / Cancel", u8"B — Стоп / Отмена")))
	{
		if (rendering) a.worker.cancel = true; else a.player.stop();
	}
	if (consoleButton("##X", M(662, 611), M(13), rgb(40, 120, 220), "X", a.fBold, fsz, tr("X — Play / Pause", u8"X — Слушать / Пауза"))) togglePlay(a);
	if (consoleButton("##Y", M(641, 632), M(13), rgb(40, 170, 90), "Y", a.fBold, fsz, tr("Y — Choose the output folder", u8"Y — Выбрать папку для дорожек")))
	{
		std::wstring w;
		if (pickFolder(w)) { a.outDir = fs::path(w); a.outCustom = true; }
	}
	if (pillButton("##sel", M(190, 906), M(262, 922), "SELECT", a.fSmall, fsmall * 0.8f, tr("Open a file", u8"Выбрать файл")))
	{
		std::wstring w;
		if (pickFile(w)) loadFile(a, fs::path(w));
	}
	if (pillButton("##home", M(326, 904), M(394, 924), "HOME", a.fBold, fsmall * 0.85f, tr("Close the file", u8"Закрыть файл"))) closeFile(a);
	if (pillButton("##start", M(458, 906), M(530, 922), "START", a.fSmall, fsmall * 0.8f, tr("Play / Pause", u8"Слушать / Пауза"))) togglePlay(a);
	dl->AddCircleFilled(M(670, 905), M(7), rgb(24, 25, 28), 16);
	dl->AddCircle(M(670, 905), M(4), rgb(120, 124, 132), 16, M(1.2f));
	dl->AddLine(M(670, 899), M(670, 904), rgb(120, 124, 132), M(1.2f));

	// ------------------------------------------------ TOP SCREEN
	{
		drawStripes(dl, tsA, tsB, rgb(244, 245, 248), rgb(232, 234, 239), M(14), stripeShift, wave, waveAmp * M(3.0f));
		// header bar: starts a pixel above the screen edge so no stripe peeks out above it
		ImVec2 hA = ImVec2(tsA.x, std::floor(tsA.y) - 1), hB = ImVec2(tsB.x, tsA.y + M(24));
		dl->AddRectFilledMultiColor(hA, hB, rgb(255, 255, 255), rgb(255, 255, 255), rgb(226, 229, 235), rgb(226, 229, 235));
		dl->AddLine(ImVec2(hA.x, hB.y), hB, rgb(200, 204, 212), M(1));
		dl->AddText(a.fBold, fsmall, ImVec2(hA.x + M(10), hA.y + M(5)), C_TEXT, "Pupue Splitter");
		SYSTEMTIME st; GetLocalTime(&st);
		std::string clock = fmt("%02d:%02d", st.wHour, st.wMinute);
		dl->AddText(a.fBold, fsmall, ImVec2(hB.x - M(96), hA.y + M(5)), C_TEXT, clock.c_str());
		// language switch (left of the clock)
		{
			const char *names[2] = { "EN", "RU" };
			float bw = M(30), bh = M(18), gx = hB.x - M(170), gy = hA.y + M(4);
			dl->AddRectFilled(ImVec2(gx, gy), ImVec2(gx + bw * 2, gy + bh), rgb(214, 218, 225), bh / 2);
			for (int i = 0; i < 2; ++i)
			{
				ImVec2 pa(gx + bw * i, gy), pb(gx + bw * (i + 1), gy + bh);
				ImGui::SetCursorScreenPos(pa);
				ImGui::PushID(i);
				if (ImGui::InvisibleButton("##lang", ImVec2(bw, bh)) && g_lang != i) { g_lang = i; saveLang(); }
				bool hov = ImGui::IsItemHovered();
				ImGui::PopID();
				if (g_lang == i) dl->AddRectFilled(pa, pb, C_ACCENT, bh / 2);
				else if (hov) dl->AddRectFilled(pa, pb, rgb(200, 205, 214), bh / 2);
				textCentered(dl, a.fBold, fsmall * 0.85f, ImVec2((pa.x + pb.x) / 2, (pa.y + pb.y) / 2), g_lang == i ? rgb(255, 255, 255) : C_SUB, names[i]);
			}
			if (ImGui::IsMouseHoveringRect(ImVec2(gx, gy), ImVec2(gx + bw * 2, gy + bh))) ImGui::SetTooltip("%s", tr("Language", u8"Язык"));
		}
		ImVec2 bA = ImVec2(hB.x - M(42), hA.y + M(7)), bB = ImVec2(hB.x - M(14), hA.y + M(19));
		dl->AddRect(bA, bB, C_SUB, M(2), 0, M(1.5f));
		dl->AddRectFilled(ImVec2(bB.x, bA.y + M(3)), ImVec2(bB.x + M(3), bB.y - M(3)), C_SUB);

		std::vector<std::string> lines; std::string cur;
		g_log.snapshot(lines, cur);
		std::string plabel; float pfrac = 0; bool hasP = parseProgress(cur, plabel, pfrac);
		float battery = 1.f;
		if (rendering) battery = hasP ? overallProgress(plabel, pfrac) : 0.f;
		dl->AddRectFilled(ImVec2(bA.x + M(2), bA.y + M(2)), ImVec2(bA.x + M(2) + (bB.x - bA.x - M(4)) * std::max(0.05f, battery), bB.y - M(2)),
			rendering ? rgb(255, 150, 40) : rgb(70, 190, 90), M(1));

		ImVec2 cA = ImVec2(tsA.x + M(14), hB.y + M(12)), cB = ImVec2(tsB.x - M(14), tsB.y - M(12));
		float x0 = cA.x;
		if (playing && !a.konata.frames.empty())
		{
			float side = cB.y - cA.y;
			ImVec2 gA = cA, gB = ImVec2(cA.x + side, cB.y);
			dl->AddRectFilled(ImVec2(gA.x - M(4), gA.y - M(4)), ImVec2(gB.x + M(4), gB.y + M(4)), rgb(255, 255, 255), M(10));
			dl->AddImageRounded((ImTextureID)(intptr_t)a.konata.frames[a.konata.cur], gA, gB, ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, M(8));
			x0 = gB.x + M(18);
		}
		float cw = cB.x - x0;
		float y = cA.y;
		auto line = [&](ImFont *f, float size, ImU32 col, const std::string &s) {
			std::string e = ellipsize(f, size, s, cw);
			dl->AddText(f, size, ImVec2(x0, y), col, e.c_str());
			y += size * 1.3f;
		};
		if (!a.loaded)
		{
			textCentered(dl, a.fBig, fbig, ImVec2((cA.x + cB.x) / 2, cA.y + M(70)), C_TEXT, tr("Drag game music", u8"Перетащи музыку"));
			textCentered(dl, a.fBig, fbig, ImVec2((cA.x + cB.x) / 2, cA.y + M(104)), C_TEXT, tr("onto the bottom screen", u8"на нижний экран"));
			float bob = sinf((float)t * 3.f) * M(6);
			ImVec2 ac = ImVec2((cA.x + cB.x) / 2, cA.y + M(160) + bob);
			dl->AddTriangleFilled(ImVec2(ac.x - M(22), ac.y - M(12)), ImVec2(ac.x + M(22), ac.y - M(12)), ImVec2(ac.x, ac.y + M(14)), C_ACCENT);
			dl->AddRectFilled(ImVec2(ac.x - M(9), ac.y - M(40)), ImVec2(ac.x + M(9), ac.y - M(12)), C_ACCENT, M(3));
			textCentered(dl, a.fReg, fsmall, ImVec2((cA.x + cB.x) / 2, cB.y - M(40)), C_SUB,
				u8"DS .mini2sf · PS1 .minipsf · GBA .minigsf · N64 .miniusf");
			textCentered(dl, a.fReg, fsmall, ImVec2((cA.x + cB.x) / 2, cB.y - M(18)), C_SUB,
				u8"SNES .spc · Mega Drive .vgm · NES .nsf · Game Boy .gbs");
		}
		else
		{
			std::string title = a.si.tracks.size() > 1 ? a.si.tracks[a.track] : u8(a.src.stem());
			line(a.fBig, fbig * 0.9f, C_TEXT, title);
			{
				std::string info = a.si.system + (a.si.tracks.size() > 1 ? fmt(tr(" · track %d of %d", u8" · трек %d из %d"), a.track + 1, (int)a.si.tracks.size()) : "");
				line(a.fReg, fsmall, C_SUB, info);
				y -= fsmall * 1.3f;
				float iw = a.fReg->CalcTextSizeA(fsmall, FLT_MAX, 0, ellipsize(a.fReg, fsmall, info, cw).c_str()).x;
				std::string b;
				if (a.bpm > 0) b = fmt(u8"  ♩ %.0f BPM", (double)a.bpm);
				else if (a.bpmState == 1) b = std::string(u8"  ♩ ") + tr("BPM…", u8"BPM…");
				if (!b.empty() && iw + M(90) < cw) dl->AddText(a.fBold, fsmall, ImVec2(x0 + iw, y), C_ORANGE, b.c_str());
				y += fsmall * 1.3f;
			}
			y += M(4);

			// ---- timeline
			{
				double pos = playing ? a.player.position() : 0;
				if (a.pendingSeek >= 0) pos = a.pendingSeek;
				float th = M(18);
				std::string ls = mmss(pos), rs = dur > 0 ? mmss(dur) : "--:--";
				if (a.scrubbing && dur > 0) ls = mmss(a.scrubFrac * dur);
				float lw = a.fBold->CalcTextSizeA(fsmall, FLT_MAX, 0, "00:00").x;
				ImVec2 ba(x0 + lw + M(8), y + th / 2 - M(3)), bb(x0 + cw - lw - M(8), y + th / 2 + M(3));
				dl->AddText(a.fBold, fsmall, ImVec2(x0, y + (th - fsmall) / 2 - M(1)), playing ? C_ACCENT : C_SUB, ls.c_str());
				ImVec2 rsz = a.fBold->CalcTextSizeA(fsmall, FLT_MAX, 0, rs.c_str());
				dl->AddText(a.fBold, fsmall, ImVec2(x0 + cw - rsz.x, y + (th - fsmall) / 2 - M(1)), C_SUB, rs.c_str());
				ImGui::SetCursorScreenPos(ImVec2(ba.x - M(6), y));
				ImGui::InvisibleButton("##timeline", ImVec2(bb.x - ba.x + M(12), th));
				bool hov = ImGui::IsItemHovered();
				if (ImGui::IsItemActive() && dur > 0)
				{
					a.scrubbing = true;
					a.scrubFrac = std::max(0.f, std::min(1.f, (io.MousePos.x - ba.x) / (bb.x - ba.x)));
				}
				if (ImGui::IsItemDeactivated() && a.scrubbing)
				{
					a.scrubbing = false;
					playAt(a, a.scrubFrac * dur, a.player.active && a.player.paused);
				}
				float frac = dur > 0 ? (float)(pos / dur) : 0.f;
				if (a.scrubbing) frac = a.scrubFrac;
				frac = std::max(0.f, std::min(1.f, frac));
				dl->AddRectFilled(ba, bb, rgb(214, 218, 225), M(3));
				// how far the live stems are ready (cache) — light stripe
				if (a.cache.state == 1) dl->AddRectFilled(ba, ImVec2(ba.x + (bb.x - ba.x) * a.cache.progress(), bb.y), rgb(255, 205, 150), M(3));
				dl->AddRectFilled(ba, ImVec2(ba.x + (bb.x - ba.x) * frac, bb.y), C_ACCENT, M(3));
				float kx = ba.x + (bb.x - ba.x) * frac;
				dl->AddCircleFilled(ImVec2(kx, (ba.y + bb.y) / 2), (hov || a.scrubbing) ? M(8) : M(6), rgb(255, 255, 255), 20);
				dl->AddCircle(ImVec2(kx, (ba.y + bb.y) / 2), (hov || a.scrubbing) ? M(8) : M(6), C_ACCENT, 20, M(2));
				if (hov && dur > 0 && !a.scrubbing)
				{
					float hf = std::max(0.f, std::min(1.f, (io.MousePos.x - ba.x) / (bb.x - ba.x)));
					ImGui::SetTooltip("%s", mmss(hf * dur).c_str());
				}
				y += th + M(6);
			}

			if (playing)
			{
				if (isPaused)
					line(a.fBold, fsz, C_SUB, std::string(u8"❚❚ ") + tr("Paused", u8"Пауза"));
				else if (a.player.buffering)
					line(a.fBold, fsz, C_ACCENT, a.pendingSeek >= 0 ? tr("Seeking…", u8"Перематываю…") : tr("Loading…", u8"Загружаю…"));
				else
					line(a.fBold, fsz, C_ACCENT, std::string(u8"♪ ") + tr("Playing", u8"Играет"));
				if (liveMode)
				{
					int n = 0, m = 0;
					{ std::lock_guard<std::mutex> lk(a.stemMx); for (char c : a.checked) { n += c; ++m; } }
					line(a.fReg, fsmall, rgb(40, 150, 70), fmt(tr("Live mix: %d of %d stems", u8"Живой микс: %d из %d дорожек"), n, m));
				}
				else if (a.cache.state == 1)
					line(a.fReg, fsmall, C_ORANGE, fmt(tr("Full mix for now · stems in %d%%", u8"Пока полный микс · дорожки: %d%%"), (int)(a.cache.progress() * 100)));
				y += M(2);
			}
			if (rendering)
			{
				line(a.fBold, fsz, C_ORANGE, tr("Rendering stems…", u8"Рендер дорожек…"));
				drawProgressBar(dl, ImVec2(x0, y), ImVec2(x0 + cw, y + M(14)), battery, rgb(255, 150, 40));
				y += M(22);
				if (hasP)
				{
					line(a.fReg, fsmall, C_SUB, plabel);
					drawProgressBar(dl, ImVec2(x0, y), ImVec2(x0 + cw, y + M(8)), pfrac, C_ACCENT);
					y += M(16);
				}
			}
			else if (analyzing)
			{
				int dots = (int)(t * 3) % 4;
				line(a.fBold, fsz, C_ACCENT, std::string(tr("Looking for stems", u8"Ищу дорожки")) + std::string(dots, '.'));
				if (hasP) { drawProgressBar(dl, ImVec2(x0, y), ImVec2(x0 + cw, y + M(10)), pfrac, C_ACCENT); y += M(18); }
			}
			else if (a.doneAt > 0)
			{
				line(a.fBold, fsz, rgb(40, 160, 70), fmt(tr("✓ Done! Files: %d", u8"✓ Готово! Файлов: %d"), a.lastFiles));
				line(a.fReg, fsmall, C_SUB, u8(a.lastOut));
			}
			else if (a.stemsReady && !playing)
			{
				int n = 0; for (char c : a.checked) n += c;
				line(a.fReg, fsz, C_TEXT, fmt(tr("Stems found: %d, ticked: %d", u8"Дорожек найдено: %d, выбрано: %d"), (int)a.stems.size(), n));
				line(a.fReg, fsmall, C_SUB, tr("Press Render (or A) on the bottom screen", u8"Жми «Рендер» (или A) на нижнем экране"));
			}
			// recent log lines
			float logTop = y + M(6);
			int maxLines = (int)((cB.y - logTop) / (fsmall * 1.25f));
			if (maxLines > 0)
			{
				std::vector<std::string> show;
				for (auto it = lines.rbegin(); it != lines.rend() && (int)show.size() < maxLines; ++it)
				{
					if (it->rfind("===", 0) == 0) continue;
					show.push_back(*it);
				}
				y = cB.y - show.size() * fsmall * 1.25f;
				for (auto it = show.rbegin(); it != show.rend(); ++it)
				{
					std::string x = *it;
					ImU32 col = C_SUB;
					if (x.rfind("->", 0) == 0) { x = u8"✓ " + trim(x.substr(2)); col = rgb(40, 150, 70); }
					else if (x.find("ERROR") != std::string::npos || x.find("!") == 0) col = rgb(200, 50, 50);
					dl->AddText(a.fReg, fsmall, ImVec2(x0, y), col, ellipsize(a.fReg, fsmall, x, cw).c_str());
					y += fsmall * 1.25f;
				}
			}
		}
		if (a.messageAt > 0 && nowSec() - a.messageAt < 4.0)
		{
			ImVec2 sz = a.fBold->CalcTextSizeA(fsmall, FLT_MAX, 0, a.message.c_str());
			sz.x = std::min(sz.x, tsB.x - tsA.x - M(40));
			ImVec2 mA = ImVec2((tsA.x + tsB.x) / 2 - sz.x / 2 - M(12), tsB.y - M(44)), mB = ImVec2((tsA.x + tsB.x) / 2 + sz.x / 2 + M(12), tsB.y - M(16));
			dl->AddRectFilled(mA, mB, a.messageErr ? rgb(200, 50, 60, 235) : rgb(40, 44, 52, 235), M(14));
			dl->AddText(a.fBold, fsmall, ImVec2(mA.x + M(12), mA.y + M(5)), rgb(255, 255, 255),
				ellipsize(a.fBold, fsmall, a.message, sz.x).c_str());
		}
	}
	ImGui::End();
	ImGui::PopStyleVar();

	// ------------------------------------------------ BOTTOM SCREEN
	ImGui::SetNextWindowPos(bsA);
	ImGui::SetNextWindowSize(ImVec2(bsB.x - bsA.x, bsB.y - bsA.y));
	ImGui::PushStyleColor(ImGuiCol_WindowBg, rgb(236, 238, 242));
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(M(12), M(10)));
	ImGui::Begin("##bottom", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar);
	{
		ImDrawList *bl = ImGui::GetWindowDrawList();
		drawStripes(bl, bsA, bsB, rgb(236, 238, 242), rgb(228, 231, 236), M(12), stripeShift, wave, waveAmp * M(2.5f));
		float w = bsB.x - bsA.x - M(24);
		if (!a.loaded)
		{
			ImVec2 dA = ImVec2(bsA.x + M(16), bsA.y + M(16)), dB = ImVec2(bsB.x - M(16), bsB.y - M(70));
			float dash = M(10), gap = M(7);
			auto dashed = [&](ImVec2 p, ImVec2 q) {
				float len = sqrtf((q.x - p.x) * (q.x - p.x) + (q.y - p.y) * (q.y - p.y));
				for (float d = 0; d < len; d += dash + gap)
				{
					float e = std::min(len, d + dash);
					bl->AddLine(ImVec2(p.x + (q.x - p.x) * d / len, p.y + (q.y - p.y) * d / len),
						ImVec2(p.x + (q.x - p.x) * e / len, p.y + (q.y - p.y) * e / len), C_ACCENT, M(2.5f));
				}
			};
			bl->AddRectFilled(dA, dB, rgb(255, 255, 255, 150), M(14));
			dashed(dA, ImVec2(dB.x, dA.y)); dashed(ImVec2(dB.x, dA.y), dB); dashed(dB, ImVec2(dA.x, dB.y)); dashed(ImVec2(dA.x, dB.y), dA);
			ImVec2 cc = ImVec2((dA.x + dB.x) / 2, dA.y + M(100));
			bl->AddRectFilled(ImVec2(cc.x - M(34), cc.y - M(40)), ImVec2(cc.x + M(34), cc.y + M(40)), rgb(60, 64, 72), M(6));
			bl->AddRectFilled(ImVec2(cc.x - M(26), cc.y - M(30)), ImVec2(cc.x + M(26), cc.y + M(8)), C_ACCENT, M(3));
			textCentered(bl, a.fBold, fsz * 1.3f, ImVec2(cc.x, cc.y - M(11)), rgb(255, 255, 255), u8"♪");
			for (int i = 0; i < 5; ++i) bl->AddRectFilled(ImVec2(cc.x - M(22) + i * M(10), cc.y + M(22)), ImVec2(cc.x - M(16) + i * M(10), cc.y + M(38)), rgb(200, 170, 60));
			textCentered(bl, a.fBold, fsz * 1.1f, ImVec2(cc.x, dA.y + M(178)), C_TEXT, tr("Drop a music file here", u8"Кинь сюда файл с музыкой"));
			textCentered(bl, a.fReg, fsmall, ImVec2(cc.x, dA.y + M(204)), C_SUB, u8".mini2sf .minipsf .minigsf .miniusf .spc .vgm .nsf .gbs .m3u");
			ImGui::SetCursorScreenPos(ImVec2(bsA.x + M(110), bsB.y - M(56)));
			if (touchButton(tr("Choose a file…", u8"Выбрать файл…"), ImVec2(M(260), M(40)), C_ACCENT, rgb(255, 255, 255)))
			{
				std::wstring wp;
				if (pickFile(wp)) loadFile(a, fs::path(wp));
			}
		}
		else
		{
			// file row
			ImGui::PushFont(a.fBold);
			std::string fname = u8(a.src.filename());
			ImGui::PushStyleColor(ImGuiCol_Text, C_TEXT);
			ImGui::TextUnformatted(ellipsize(a.fBold, fsz, fname, w - M(40)).c_str());
			ImGui::PopStyleColor();
			ImGui::PopFont();
			ImGui::SameLine(w - M(22));
			if (touchButton(u8"✕##close", ImVec2(M(32), M(26)), rgb(220, 224, 230), C_TEXT)) closeFile(a);
			// playlist: tracks of a multi-track file or the music files of the folder
			if (playlistSize(a) > 1)
			{
				bool multi = a.si.tracks.size() > 1;
				int n = playlistSize(a), cur = playlistPos(a);
				auto titleOf = [&](int i) -> std::string {
					if (multi) return a.si.tracks[i];
					return u8(a.folderList[i].stem());
				};
				ImGui::SetNextItemWidth(w);
				ImGui::PushStyleColor(ImGuiCol_FrameBg, rgb(255, 255, 255));
				ImGui::PushStyleColor(ImGuiCol_Text, C_TEXT);
				ImGui::PushStyleColor(ImGuiCol_PopupBg, rgb(250, 251, 252));
				std::string curT = cur >= 0 ? fmt("%d/%d  ", cur + 1, n) + titleOf(cur) : u8(a.src.stem());
				ImGui::BeginDisabled(rendering);
				int go = -1;
				if (ImGui::BeginCombo("##track", curT.c_str(), ImGuiComboFlags_HeightLarge))
				{
					for (int i = 0; i < n; ++i)
					{
						std::string lab = fmt("%d. ", i + 1) + titleOf(i);
						if (multi && a.si.jobs.size() > (size_t)i && a.si.jobs[i].length > 0) lab += "   (" + mmss(a.si.jobs[i].length) + ")";
						if (ImGui::Selectable((lab + "##t" + std::to_string(i)).c_str(), i == cur) && i != cur) go = i;
						if (i == cur && ImGui::IsWindowAppearing()) ImGui::SetScrollHereY();
					}
					ImGui::EndCombo();
				}
				ImGui::EndDisabled();
				ImGui::PopStyleColor(3);
				if (go >= 0) playlistGo(a, go); // starts playing right away
			}
			// stems header
			ImGui::PushStyleColor(ImGuiCol_Text, C_SUB);
			ImGui::TextUnformatted(tr("Stems:", u8"Дорожки:"));
			ImGui::PopStyleColor();
			ImGui::SameLine();
			bool ready = a.stemsReady;
			ImGui::BeginDisabled(!ready || rendering);
			if (touchButton(tr("All", u8"Все"), ImVec2(M(54), M(24)), rgb(220, 224, 230), C_TEXT)) { std::lock_guard<std::mutex> lk(a.stemMx); for (auto &c : a.checked) c = 1; }
			ImGui::SameLine();
			if (touchButton(tr("None", u8"Ничего"), ImVec2(M(70), M(24)), rgb(220, 224, 230), C_TEXT)) { std::lock_guard<std::mutex> lk(a.stemMx); for (auto &c : a.checked) c = 0; }
			ImGui::SameLine();
			ImGui::PushStyleColor(ImGuiCol_Text, C_TEXT);
			ImGui::PushStyleColor(ImGuiCol_FrameBg, rgb(255, 255, 255));
			ImGui::PushStyleColor(ImGuiCol_CheckMark, C_ACCENT);
			ImGui::Checkbox(tr("+ full mix", u8"+ полный микс"), &a.wantMix);
			if (false)
				ImGui::SetTooltip("%s", tr("Saves where every note of a stem starts: a .txt label file next to each stem\n(Audacity labels), and WAV files also get the markers inside (VEGAS, Reaper, Audition).\nDS and PS1: exact notes from the game; other systems: detected from the audio.",
					u8"Сохраняет, где начинается каждая нота дорожки: рядом с каждой дорожкой файл .txt\n(метки Audacity), а в WAV маркеры записываются прямо в файл (VEGAS, Reaper, Audition).\nDS и PS1: точные ноты из игры; остальные системы: ноты распознаются по звуку."));
			ImGui::PopStyleColor(3);
			ImGui::EndDisabled();

			// stems list: two columns, font shrinks so that everything fits
			float listH = (bsB.y - ImGui::GetCursorScreenPos().y) - M(108);
			ImGui::PushStyleColor(ImGuiCol_ChildBg, rgb(255, 255, 255, 220));
			ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, M(10));
			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(M(8), M(6)));
			ImGui::BeginChild("##stems", ImVec2(w, listH), ImGuiChildFlags_Borders);
			if (!ready)
			{
				int dots = (int)(t * 3) % 4;
				ImGui::PushStyleColor(ImGuiCol_Text, C_SUB);
				ImGui::TextUnformatted((std::string(tr("Analyzing", u8"Анализ")) + std::string(dots, '.')).c_str());
				ImGui::PopStyleColor();
			}
			else
			{
				std::lock_guard<std::mutex> lk(a.stemMx);
				int n = (int)a.stems.size();
				int rows = (n + 1) / 2;
				float baseFs = ImGui::GetFontSize();
				float padY = M(2), spY = M(3);
				float avail = listH - M(12);
				float need = rows * (baseFs + 2 * padY + spY);
				float k = need > avail && rows > 0 ? std::max(0.55f, (avail - rows * (2 * padY + spY)) / (rows * baseFs)) : 1.f;
				k = std::min(1.f, k);
				ImGui::SetWindowFontScale(k);
				ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(M(3), padY));
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(M(6), spY));
				ImGui::PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, ImVec2(M(5), M(3)));
				ImGui::PushStyleColor(ImGuiCol_Text, C_TEXT);
				ImGui::PushStyleColor(ImGuiCol_FrameBg, rgb(236, 238, 242));
				ImGui::PushStyleColor(ImGuiCol_CheckMark, C_ACCENT);
				ImGui::BeginDisabled(rendering);
				float colW = (ImGui::GetContentRegionAvail().x - M(10)) / 2;
				float boxW = ImGui::GetFrameHeight() + M(5);
				ImFont *f = ImGui::GetFont();
				float fsNow = ImGui::GetFontSize();
				float left = ImGui::GetCursorPosX();
				for (int r = 0; r < rows; ++r)
				{
					for (int c = 0; c < 2; ++c)
					{
						int i = c * rows + r;
						if (i >= n) continue;
						if (c == 1) ImGui::SameLine(left + colW + M(10));
						bool v = a.checked[i] != 0;
						std::string lab = ellipsize(f, fsNow, a.stems[i], colW - boxW);
						if (ImGui::Checkbox((lab + "##s" + std::to_string(i)).c_str(), &v)) a.checked[i] = v;
						if (ImGui::IsItemHovered() && lab != a.stems[i]) ImGui::SetTooltip("%s", a.stems[i].c_str());
					}
				}
				ImGui::EndDisabled();
				ImGui::PopStyleColor(3);
				ImGui::PopStyleVar(3);
				ImGui::SetWindowFontScale(1.f);
				if (n == 0)
				{
					ImGui::PushStyleColor(ImGuiCol_Text, C_SUB);
					ImGui::TextWrapped("%s", tr("No stems found — you can still save the full mix", u8"Дорожки не найдены — можно сохранить полный микс"));
					ImGui::PopStyleColor();
				}
			}
			ImGui::EndChild();
			ImGui::PopStyleVar(2);
			ImGui::PopStyleColor();

			// output folder
			ImGui::PushStyleColor(ImGuiCol_Text, C_SUB);
			std::string od = std::string(tr("Folder: ", u8"Папка: ")) + u8(a.outDir);
			ImGui::TextUnformatted(ellipsize(a.fReg, fsz, od, w - M(262)).c_str());
			ImGui::PopStyleColor();
			if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", u8(a.outDir).c_str());
			{
				const char *fn[3] = { "WAV", "FLAC", "MP3" };
				ImGui::SameLine(w - M(92) - M(150));
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(M(2), M(7)));
				ImGui::BeginDisabled(rendering);
				for (int i = 0; i < 3; ++i)
				{
					if (i) ImGui::SameLine();
					std::string lab = std::string(fn[i]) + "##fmt";
					if (touchButton(lab.c_str(), ImVec2(M(46), M(26)), g_fmt == i ? C_ACCENT : rgb(220, 224, 230), g_fmt == i ? rgb(255, 255, 255) : C_TEXT))
					{ g_fmt = i; saveLang(); }
					if (ImGui::IsItemHovered())
						ImGui::SetTooltip("%s", i == 0 ? tr("WAV — uncompressed (as rendered)", u8"WAV — без сжатия (как отрендерено)")
							: i == 1 ? tr("FLAC — lossless, ~2x smaller", u8"FLAC — без потерь, примерно в 2 раза меньше")
							: tr("MP3 — 320 kbps", u8"MP3 — 320 кбит/с"));
				}
				ImGui::EndDisabled();
				ImGui::PopStyleVar();
			}
			ImGui::SameLine(w - M(92));
			if (touchButton(tr("Change", u8"Изменить"), ImVec2(M(104), M(26)), rgb(220, 224, 230), C_TEXT, !rendering))
			{
				std::wstring wp;
				if (pickFolder(wp)) { a.outDir = fs::path(wp); a.outCustom = true; }
			}
			// transport (2x2: play/pause + stop, previous + next) + render + open folder
			float bh = M(52), sh = (bh - M(4)) / 2;
			float bx = bsA.x + M(12), by = bsB.y - bh - M(10);
			bool showPause = playing && !isPaused;
			int plN = playlistSize(a), plPos = playlistPos(a);
			ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(M(4), M(2)));
			ImGui::SetCursorScreenPos(ImVec2(bx, by));
			std::string playLab = showPause ? std::string(u8"❚❚ ") + tr("Pause", u8"Пауза") : std::string(u8"▶ ") + tr("Play", u8"Слушать");
			if (touchButton(playLab.c_str(), ImVec2(M(104), sh), showPause ? rgb(60, 64, 72) : rgb(40, 120, 220), rgb(255, 255, 255)))
				togglePlay(a);
			ImGui::SetCursorScreenPos(ImVec2(bx + M(108), by));
			std::string stopLab = std::string(u8"■ ") + tr("Stop", u8"Стоп");
			if (touchButton(stopLab.c_str(), ImVec2(M(84), sh), rgb(220, 224, 230), C_TEXT, playing)) a.player.stop();
			ImGui::SetCursorScreenPos(ImVec2(bx, by + sh + M(4)));
			std::string prevLab = std::string(u8"◀◀ ") + tr("Prev", u8"Пред.");
			if (touchButton(prevLab.c_str(), ImVec2(M(104), sh), rgb(220, 224, 230), C_TEXT, plN > 1 && plPos > 0 && !rendering)) playlistGo(a, plPos - 1);
			if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tr("Previous track in the list", u8"Предыдущий трек в списке"));
			ImGui::SetCursorScreenPos(ImVec2(bx + M(108), by + sh + M(4)));
			std::string nextLab = std::string(tr("Next", u8"След.")) + u8" ▶▶";
			if (touchButton(nextLab.c_str(), ImVec2(M(84), sh), rgb(220, 224, 230), C_TEXT, plN > 1 && plPos >= 0 && plPos + 1 < plN && !rendering)) playlistGo(a, plPos + 1);
			if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tr("Next track in the list", u8"Следующий трек в списке"));
			ImGui::PopStyleVar();
			ImGui::SetCursorScreenPos(ImVec2(bx + M(198), by));
			if (rendering)
			{
				if (touchButton(tr("Cancel", u8"Отмена"), ImVec2(M(124), bh), rgb(240, 180, 30), rgb(40, 30, 0))) a.worker.cancel = true;
			}
			else
			{
				std::string rl = std::string(tr("Render", u8"Рендер")) + "  (A)";
				if (touchButton(rl.c_str(), ImVec2(M(124), bh), rgb(214, 48, 49), rgb(255, 255, 255), canRender)) startRender(a);
			}
			ImGui::SameLine();
			if (touchButton(tr("Open\nfolder", u8"Открыть\nпапку"), ImVec2(ImGui::GetContentRegionAvail().x, bh), rgb(220, 224, 230), C_TEXT, a.doneAt > 0 || fs::exists(a.outDir)))
				ShellExecuteW(nullptr, L"open", (a.lastOut.empty() ? a.outDir : a.lastOut).wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
		}
	}
	ImGui::End();
	ImGui::PopStyleVar();
	ImGui::PopStyleColor();
}

// ================================================================ window
static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
	switch (msg)
	{
		case WM_SIZE:
			if (wParam == SIZE_MINIMIZED) return 0;
			g_resizeW = (UINT)LOWORD(lParam);
			g_resizeH = (UINT)HIWORD(lParam);
			return 0;
		case WM_GETMINMAXINFO:
		{
			auto *mm = (MINMAXINFO *)lParam;
			mm->ptMinTrackSize.x = 380;
			mm->ptMinTrackSize.y = 500;
			return 0;
		}
		case WM_DROPFILES:
		{
			HDROP h = (HDROP)wParam;
			POINT pt; DragQueryPoint(h, &pt);
			UINT n = DragQueryFileW(h, 0xFFFFFFFF, nullptr, 0);
			std::vector<std::wstring> files;
			for (UINT i = 0; i < n; ++i)
			{
				UINT len = DragQueryFileW(h, i, nullptr, 0);
				std::wstring s(len, L'\0');
				DragQueryFileW(h, i, &s[0], len + 1);
				files.push_back(s);
			}
			DragFinish(h);
			if (g_app)
			{
				std::lock_guard<std::mutex> lk(g_app->dropMx);
				g_app->pendingDrop = files;
				g_app->dropPoint = ImVec2((float)pt.x, (float)pt.y);
			}
			return 0;
		}
		case WM_COPYDATA:
		{
			auto *cd = (COPYDATASTRUCT *)lParam;
			if (cd && cd->dwData == 0x50555045 && g_app && cd->cbData >= sizeof(wchar_t))
			{
				std::wstring f((const wchar_t *)cd->lpData, cd->cbData / sizeof(wchar_t));
				while (!f.empty() && f.back() == 0) f.pop_back();
				std::lock_guard<std::mutex> lk(g_app->dropMx);
				g_app->pendingOpen.push_back(f);
				return TRUE;
			}
			break;
		}
		case WM_SYSCOMMAND:
			if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
	}
	return DefWindowProcW(hWnd, msg, wParam, lParam);
}

static int runGui(const std::vector<std::wstring> &args)
{
	CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
	ImGui_ImplWin32_EnableDpiAwareness();
	// single instance: hand the file to the running window and quit
	{
		CreateMutexW(nullptr, FALSE, L"PupueSplitter.SingleInstance");
		if (GetLastError() == ERROR_ALREADY_EXISTS)
		{
			std::wstring file;
			for (auto &a : args) if (!a.empty() && a[0] != L'-') { file = fs::absolute(fs::path(a)).wstring(); break; }
			for (int i = 0; i < 100; ++i)
			{
				HWND w = FindWindowW(L"PupueSplitter3DS", nullptr);
				if (w)
				{
					if (!file.empty())
					{
						COPYDATASTRUCT cds;
						cds.dwData = 0x50555045;
						cds.cbData = (DWORD)((file.size() + 1) * sizeof(wchar_t));
						cds.lpData = (PVOID)file.c_str();
						SendMessageTimeoutW(w, WM_COPYDATA, 0, (LPARAM)&cds, SMTO_ABORTIFHUNG, 5000, nullptr);
					}
					if (IsIconic(w)) ShowWindow(w, SW_RESTORE);
					SetForegroundWindow(w);
					return 0;
				}
				Sleep(50); // the first instance may still be starting
			}
		}
	}
	psfsplit::initHE();
	loadLang();
	cleanupStaleTemp();

	WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandleW(nullptr), nullptr, LoadCursor(nullptr, IDC_ARROW), nullptr, nullptr, L"PupueSplitter3DS", nullptr };
	wc.hIcon = (HICON)LoadImageW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), 0);
	wc.hIconSm = (HICON)LoadImageW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
	RegisterClassExW(&wc);
	RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
	int availH = wa.bottom - wa.top, availW = wa.right - wa.left;
	int ch = std::min((int)(availH * 0.92) - 40, 1100);
	int cw = (int)(ch * 720.0 / 940.0);
	if (cw > availW - 40) { cw = availW - 40; ch = (int)(cw * 940.0 / 720.0); }
	RECT rc = { 0, 0, cw, ch };
	AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);
	int ww = rc.right - rc.left, wh = rc.bottom - rc.top;
	g_hwnd = CreateWindowExW(WS_EX_ACCEPTFILES, wc.lpszClassName, L"Pupue Splitter", WS_OVERLAPPEDWINDOW,
		wa.left + (availW - ww) / 2, wa.top + std::max(0, (availH - wh) / 2), ww, wh, nullptr, nullptr, wc.hInstance, nullptr);
	if (!createDevice(g_hwnd)) { cleanupDevice(); MessageBoxW(nullptr, L"Direct3D 11 is not available", L"Pupue Splitter", MB_ICONERROR); return 1; }
	DragAcceptFiles(g_hwnd, TRUE);
	ShowWindow(g_hwnd, SW_SHOWDEFAULT);
	UpdateWindow(g_hwnd);

	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO &io = ImGui::GetIO();
	io.IniFilename = nullptr;
	ImGui::StyleColorsLight();
	ImGuiStyle &st = ImGui::GetStyle();
	st.FrameRounding = 9; st.ChildRounding = 10; st.GrabRounding = 8; st.PopupRounding = 8; st.WindowRounding = 0;
	st.FramePadding = ImVec2(8, 5); st.ItemSpacing = ImVec2(8, 7);
	st.Colors[ImGuiCol_Border] = ImVec4(0.80f, 0.82f, 0.86f, 1);
	st.Colors[ImGuiCol_Header] = ImVec4(0.10f, 0.70f, 0.90f, 0.25f);
	st.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.10f, 0.70f, 0.90f, 0.40f);
	st.Colors[ImGuiCol_HeaderActive] = ImVec4(0.10f, 0.70f, 0.90f, 0.60f);
	st.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.85f, 0.94f, 0.98f, 1);
	st.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.75f, 0.90f, 0.97f, 1);
	ImGui_ImplWin32_Init(g_hwnd);
	ImGui_ImplDX11_Init(g_dev, g_ctx);

	App *app = new App();
	g_app = app;
	RECT cr; GetClientRect(g_hwnd, &cr);
	app->baseScale = std::min((cr.right - cr.left) / 720.f, (cr.bottom - cr.top) / 940.f);
	float s = app->baseScale;
	static ImVector<ImWchar> ranges;
	{
		ImFontGlyphRangesBuilder b;
		b.AddRanges(io.Fonts->GetGlyphRangesCyrillic());
		b.AddText(u8"…·✓✕▶◀■♪♩❚↓—«»№");
		b.BuildRanges(&ranges);
	}
	auto addFont = [&](const char *file, float size) -> ImFont * {
		std::string p = std::string("C:\\Windows\\Fonts\\") + file;
		if (GetFileAttributesA(p.c_str()) == INVALID_FILE_ATTRIBUTES) return nullptr;
		ImFont *f = io.Fonts->AddFontFromFileTTF(p.c_str(), size, nullptr, ranges.Data);
		if (f && GetFileAttributesA("C:\\Windows\\Fonts\\seguisym.ttf") != INVALID_FILE_ATTRIBUTES)
		{
			ImFontConfig mc; mc.MergeMode = true;
			io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\seguisym.ttf", size, &mc, ranges.Data);
		}
		return f;
	};
	app->fReg = addFont("segoeui.ttf", 17.f * s);
	app->fBold = addFont("segoeuib.ttf", 17.f * s);
	app->fBig = addFont("segoeuib.ttf", 26.f * s);
	app->fSmall = addFont("segoeui.ttf", 14.f * s);
	if (!app->fReg) { ImFontConfig c; c.SizePixels = 15.f * s; app->fReg = io.Fonts->AddFontDefault(&c); }
	if (!app->fBold) app->fBold = app->fReg;
	if (!app->fBig) app->fBig = app->fBold;
	if (!app->fSmall) app->fSmall = app->fReg;
	io.FontDefault = app->fReg;

	auto gif = resource(RES_KONATA_GIF);
	app->konata.load(gif.first, gif.second);

	g_outSink = [](const std::string &s) { g_log.add(s); };

	for (auto &a : args)
		if (!a.empty() && a[0] != L'-') { app->pendingOpen.push_back(fs::absolute(fs::path(a)).wstring()); break; }

	double last = nowSec();
	bool done = false;
	while (!done)
	{
		MSG msg;
		while (PeekMessageW(&msg, nullptr, 0U, 0U, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessageW(&msg);
			if (msg.message == WM_QUIT) done = true;
		}
		if (done) break;
		if (g_resizeW != 0 && g_resizeH != 0)
		{
			cleanupRT();
			g_swap->ResizeBuffers(0, g_resizeW, g_resizeH, DXGI_FORMAT_UNKNOWN, 0);
			g_resizeW = g_resizeH = 0;
			createRT();
		}
		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		double now = nowSec();
		frame(*app, io.DisplaySize.x, io.DisplaySize.y, now - last);
		last = now;
		ImGui::Render();
		const float clear[4] = { 0.07f, 0.07f, 0.08f, 1 };
		g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
		g_ctx->ClearRenderTargetView(g_rtv, clear);
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
		if (g_swap->Present(1, 0) == DXGI_STATUS_OCCLUDED || IsIconic(g_hwnd)) Sleep(16);
	}
	app->worker.join();
	app->player.stop();
	app->cache.reset();
	{ std::error_code ec; fs::remove_all(g_tempRoot, ec); }
	g_outSink = nullptr;
	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();
	cleanupDevice();
	DestroyWindow(g_hwnd);
	UnregisterClassW(wc.lpszClassName, wc.hInstance);
	CoUninitialize();
	return 0;
}

} // namespace gui
#endif
