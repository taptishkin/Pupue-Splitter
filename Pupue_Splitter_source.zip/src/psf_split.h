/*
 * PSF (PlayStation 1) part of the splitter.
 * Emulation: Highly Experimental by Neill Corlett (GPLv3), with a per-voice
 * capture added to the SPU core (see he/spucore.c, "spucap").
 * Included from main.cpp (uses its helpers).
 */
#pragma once

#include "he/psx.h"
#include "he/iop.h"
#include "he/r3000.h"
#include "he/spu.h"
#include "he/spucore.h"
#include "he/bios.h"

namespace psfsplit
{
#ifdef REFMIX
static FILE *g_refmix = nullptr;
#endif

static const uint8_t HE_BIOS_PACKED[] = {
#include "he/scph10000_he.inc"
};

struct PsxImage
{
	std::vector<uint8_t> ram = std::vector<uint8_t>(0x200000, 0);
	uint32_t lo = 0xFFFFFFFF, hi = 0; // uploaded range
	uint32_t pc = 0, gp = 0, sp = 0;
	bool haveRegs = false;
	int refresh = 0;
};

static void applyExe(PsxImage &img, const std::vector<uint8_t> &exe, bool takeRegs, const fs::path &p)
{
	if (exe.size() < 0x800 || memcmp(exe.data(), "PS-X EXE", 8) != 0)
		throw std::runtime_error("not a PS-X EXE inside: " + u8(p));
	uint32_t pc = rd32(&exe[0x10]), gp = rd32(&exe[0x14]);
	uint32_t addr = rd32(&exe[0x18]) & 0x1FFFFF, size = rd32(&exe[0x1C]);
	uint32_t sp = rd32(&exe[0x30]);
	if (size > exe.size() - 0x800) size = (uint32_t)(exe.size() - 0x800);
	if (addr + size > 0x200000) size = 0x200000 - addr;
	memcpy(&img.ram[addr], &exe[0x800], size);
	img.lo = std::min(img.lo, addr);
	img.hi = std::max(img.hi, addr + size);
	if (takeRegs && !img.haveRegs)
	{
		img.pc = pc; img.gp = gp; img.sp = sp ? sp : 0x801FFFF0;
		img.haveRegs = true;
		std::string region((const char *)&exe[0x4C], strnlen((const char *)&exe[0x4C], 0x7B4));
		if (!img.refresh)
			img.refresh = (region.find("Europe") != std::string::npos) ? 50 : 60;
	}
}

// PSF1 rules: _lib is loaded first and its header gives PC/GP/SP; then the
// file itself; then _lib2.._libN.
static void loadChain(const fs::path &p, PsxImage &img, int depth, PSFFile *top)
{
	if (depth > 10)
		throw std::runtime_error("_lib nesting too deep");
	PSFFile f = readPSF(p, 0x01);
	fs::path dir = p.parent_path();
	bool hasLib = f.tags.count("_lib") > 0;
	if (hasLib)
	{
		fs::path lp = dir / fs::u8path(f.tags["_lib"]);
		if (!fs::exists(lp))
			throw std::runtime_error("library not found: " + f.tags["_lib"] + " (put it next to the .minipsf)");
		loadChain(lp, img, depth + 1, nullptr);
	}
	if (!f.program.empty())
		applyExe(img, f.program, !hasLib, p);
	for (int i = 2; i < 100; ++i)
	{
		std::string k = "_lib" + std::to_string(i);
		if (!f.tags.count(k)) break;
		loadChain(dir / fs::u8path(f.tags[k]), img, depth + 1, nullptr);
	}
	if (f.tags.count("_refresh"))
		img.refresh = atoi(f.tags["_refresh"].c_str());
	if (top)
		*top = std::move(f);
}

static void initHE()
{
	static bool done = false;
	if (done) return;
	static std::vector<uint8_t> bios;
	uLongf n = 524288;
	bios.resize(n);
	if (uncompress(bios.data(), &n, HE_BIOS_PACKED, sizeof(HE_BIOS_PACKED)) != Z_OK)
		throw std::runtime_error("internal BIOS image is damaged");
	bios.resize(n);
	bios_set_embedded_image(bios.data(), (uint32)bios.size());
	if (psx_init() != 0)
		throw std::runtime_error("PS1 emulator init failed");
	done = true;
}

struct VoiceStats
{
	double peak = 0;
	std::map<uint32_t, int> samples; // SPU sample start address -> key-on count
	int keyons = 0;
};

struct CapCtx
{
	std::function<void(int)> onChunk;
	VoiceStats *stats = nullptr;
	bool groups = false;
	std::map<uint32_t, int> groupOf;  // sample address -> group id (in key-on order)
	std::vector<uint32_t> groupAddr;  // group id -> sample address
	std::vector<int> groupKeyons;
	// notes per group (group mode) or per voice
	size_t *frameNow = nullptr;
	bool wantNotes = false;
	std::vector<std::vector<NoteEv>> notes = std::vector<std::vector<NoteEv>>(SPUCAP_MAXG);
	int openGrp[24], openIdx[24];
	CapCtx() { for (int v = 0; v < 24; ++v) { openGrp[v] = -1; openIdx[v] = -1; } }
	void closeNote(int voice)
	{
		if (openGrp[voice] < 0) return;
		NoteEv &n = notes[openGrp[voice]][openIdx[voice]];
		n.dur = (double)*frameNow / 44100.0 - n.t;
		openGrp[voice] = -1;
	}
};

static void capChunk(void *ctx, int samples) { ((CapCtx *)ctx)->onChunk(samples); }
static void capKeyon(void *ctx, int voice, uint32 addr, uint32 pitch)
{
	auto *c = (CapCtx *)ctx;
	if (voice < 0 || voice >= 24) return;
	if (c->stats)
	{
		c->stats[voice].samples[addr]++;
		c->stats[voice].keyons++;
	}
	if (c->groups)
	{
		auto it = c->groupOf.find(addr);
		int g;
		if (it == c->groupOf.end())
		{
			g = std::min((int)c->groupAddr.size(), SPUCAP_MAXG - 1);
			if ((int)c->groupAddr.size() < SPUCAP_MAXG)
			{
				c->groupOf[addr] = g;
				c->groupAddr.push_back(addr);
				c->groupKeyons.push_back(0);
			}
		}
		else g = it->second;
		c->groupKeyons[g]++;
		spucap_voice_group[voice] = g;
	}
	if (c->wantNotes && c->frameNow && pitch > 0)
	{
		int g = c->groups ? spucap_voice_group[voice] : voice;
		c->closeNote(voice);
		NoteEv n;
		n.t = (double)*c->frameNow / 44100.0;
		n.key = (int)std::lround(60.0 + 12.0 * std::log2(pitch / 4096.0)); // relative to the sample's own pitch
		n.key = std::max(0, std::min(127, n.key));
		n.vel = 100;
		c->notes[g].push_back(n);
		c->openGrp[voice] = g;
		c->openIdx[voice] = (int)c->notes[g].size() - 1;
	}
}
static void capKeyoff(void *ctx, int voice)
{
	auto *c = (CapCtx *)ctx;
	if (c->wantNotes && c->frameNow && voice >= 0 && voice < 24) c->closeNote(voice);
}

// Runs the emulation for totalFrames; perFrame(frameIndex, const float* lr[], count) per frame.
// Voice mode: count = 24 voices. Group mode: count = groups so far (one per instrument sample).
template <typename CB>
static void renderPSF(const PsxImage &img, size_t totalFrames, VoiceStats *stats, const char *label, CB perFrame,
	bool groups = false, CapCtx *ctxOut = nullptr)
{
	std::vector<uint8_t> st(psx_get_state_size(1));
	psx_clear_state(st.data(), 1);
	psx_set_refresh(st.data(), img.refresh ? img.refresh : 60);
	void *iop = psx_get_iop_state(st.data());
	iop_upload_to_ram(iop, img.lo, &img.ram[img.lo], img.hi - img.lo);
	void *cpu = iop_get_r3000_state(iop);
	r3000_setreg(cpu, R3000_REG_PC, img.pc);
	r3000_setreg(cpu, R3000_REG_GEN + 29, img.sp);
	if (img.gp) r3000_setreg(cpu, R3000_REG_GEN + 28, img.gp);

	spucap_reset();
	spucap_group_mode = groups ? 1 : 0;
	size_t frame = 0;
	CapCtx localCtx;
	CapCtx &ctx = ctxOut ? *ctxOut : localCtx;
	ctx.stats = stats;
	ctx.groups = groups;
	ctx.frameNow = &frame;
	std::vector<const float *> gptr(SPUCAP_MAXG, nullptr);
	static const float zeros[2 * 200] = {};
	const float *ptrs[24];
	ctx.onChunk = [&](int n) {
		int ng = groups ? spucap_group_count() : 24;
		const float *base[SPUCAP_MAXG];
		if (groups)
			for (int g = 0; g < ng; ++g) { const float *o = spucap_group_out(g); base[g] = o ? o : zeros; }
		for (int i = 0; i < n && frame < totalFrames; ++i)
		{
			if (groups)
			{
				for (int g = 0; g < ng; ++g) gptr[g] = base[g] + 2 * i;
				perFrame(frame, gptr.data(), ng);
			}
			else
			{
				for (int v = 0; v < 24; ++v) ptrs[v] = &spucap_out[v][2 * i];
				perFrame(frame, ptrs, 24);
			}
			++frame;
		}
	};
	spucap_ctx = &ctx;
	spucap_cb = capChunk;
	spucap_keyon_cb = capKeyon;
	spucap_keyoff_cb = capKeyoff;

	std::vector<int16_t> mixbuf(2 * 4096);
	int lastPct = -1;
	auto cleanup = [&]() { for (int v = 0; v < 24; ++v) ctx.closeNote(v); ctx.frameNow = nullptr; spucap_cb = nullptr; spucap_keyon_cb = nullptr; spucap_keyoff_cb = nullptr; spucap_ctx = nullptr; spucap_group_mode = 0; spucap_reset(); };
	try
	{
		while (frame < totalFrames)
		{
			uint32 n = (uint32)std::min<size_t>(4096, totalFrames - frame);
			sint32 r = psx_execute(st.data(), 0x7FFFFFFF, mixbuf.data(), &n, 0);
			if (r < 0)
				throw std::runtime_error("PS1 emulation stopped with an error");
			if (n == 0)
				throw std::runtime_error("PS1 emulation does not produce sound");
#ifdef REFMIX
			if (g_refmix) fwrite(mixbuf.data(), 4, n, g_refmix);
#endif
			int pct = (int)(frame * 100 / std::max<size_t>(totalFrames, 1));
			if (pct != lastPct) { lastPct = pct; out(fmt("\r  %s... %d%%   ", label, pct)); }
		}
	}
	catch (...) { cleanup(); throw; }
	cleanup();
}

static int processPSF(const fs::path &inPath, const Options &opt)
{
	out("\n=== " + u8(inPath.filename()) + "  [PlayStation PSF]\n");
	initHE();
	PsxImage img;
	PSFFile top;
	loadChain(inPath, img, 0, &top);
	if (!img.haveRegs)
		throw std::runtime_error("no start address in the PSF data");

	double length = 0, fade = opt.defaultFade;
	if (top.tags.count("length")) length = parseTime(top.tags["length"]);
	if (top.tags.count("fade")) fade = parseTime(top.tags["fade"]);
	if (length <= 0) length = opt.defaultLength > 0 ? opt.defaultLength : 150;
	double volume = 1.0;
	if (top.tags.count("volume")) { double v = atof(top.tags["volume"].c_str()); if (v > 0) volume = v; }

	const unsigned rate = 44100; // PS1 SPU native rate
	size_t fadeStart = (size_t)(length * rate), fadeLen = (size_t)(fade * rate);
	size_t total = fadeStart + fadeLen;
	t_songSeconds = (double)total / rate;
	auto fadeGain = [&](size_t f) -> float {
		if (f < fadeStart) return 1.f;
		if (!fadeLen) return 0.f;
		float g = 1.f - (float)(f - fadeStart) / (float)fadeLen;
		return g < 0 ? 0.f : g;
	};
	out(fmt("  length %d:%02d + fade %gs, %d Hz refresh\n", (int)length / 60, (int)length % 60, fade, img.refresh));

	if (opt.preview)
	{
		PreviewFeeder pf(opt);
		renderPSF(img, total, nullptr, "preview", [&](size_t f, const float **lr, int nv) {
			float g = fadeGain(f) * (float)volume / 32768.f, ml = 0, mr = 0;
			for (int v = 0; v < nv; ++v) { ml += lr[v][0]; mr += lr[v][1]; }
			pf.push(ml * g, mr * g);
		});
		pf.flush();
		return 0;
	}

	fs::path dir = opt.outFor(inPath);
	std::string stem = u8(inPath.stem());

	if (!opt.psfByVoice && !g_psfVoices)
	{
		// ---- one stem per instrument sample: voices are grouped by the SPU sample they play
		// pass 1: levels per sample
		CapCtx c1;
		c1.wantNotes = opt.notes != nullptr;
		std::vector<double> gpeak(SPUCAP_MAXG, 0.0), genergy(SPUCAP_MAXG, 0.0);
		double peakMix = 0;
		renderPSF(img, total, nullptr, "analyzing", [&](size_t f, const float **lr, int ng) {
			float g = fadeGain(f) * (float)volume, ml = 0, mr = 0;
			for (int k = 0; k < ng; ++k)
			{
				float l = lr[k][0] * g, r = lr[k][1] * g;
				ml += l; mr += r;
				double a = std::max(std::fabs(l), std::fabs(r));
				if (a > gpeak[k]) gpeak[k] = a;
				genergy[k] += (double)l * l + (double)r * r;
			}
			peakMix = std::max(peakMix, (double)std::max(std::fabs(ml), std::fabs(mr)));
		}, true, &c1);
		double peak = peakMix, totalE = 0;
		for (double p : gpeak) peak = std::max(peak, p);
		for (double e : genergy) totalE += e;
		if (peak < 1.0)
			throw std::runtime_error("the file produced no sound");
		float gain = 1.0f;
		if (peak > 32000.0)
		{
			gain = (float)(32000.0 / peak);
			out(fmt("\r  level lowered by %.1f dB to avoid clipping (equally for all stems)\n", -20 * std::log10(gain)));
		}
		// audible samples, sorted by address
		std::vector<int> keep;
		for (int k = 0; k < (int)c1.groupAddr.size(); ++k)
			if (gpeak[k] * gain >= 2.0 && genergy[k] > totalE * 1e-7) keep.push_back(k);
		std::sort(keep.begin(), keep.end(), [&](int x, int y) { return c1.groupAddr[x] < c1.groupAddr[y]; });
		out(fmt("\r  %d instrument samples found                \n", (int)keep.size()));
		std::vector<std::string> keyOf(SPUCAP_MAXG);
		for (size_t i = 0; i < keep.size(); ++i)
			keyOf[keep[i]] = fmt("Inst %02d (smp %05X)", (int)i + 1, c1.groupAddr[keep[i]]);
		if (opt.notes)
			for (int k : keep) (*opt.notes)[keyOf[k]] = c1.notes[k];
		if (opt.analysis)
		{
			for (int k : keep) opt.analysis->push_back({ keyOf[k] });
			return 0;
		}
		// pass 2: write (group ids are the same: the emulation is deterministic)
		std::vector<WavStream> ws(SPUCAP_MAXG);
		WavStream mixWs;
		std::vector<std::string> names;
		for (int k : keep)
		{
			if (!opt.wants(keyOf[k])) continue;
			std::string name = sanitize(stem + " - " + keyOf[k] + ".wav");
			ws[k].open(dir / fs::u8path(name), rate);
			names.push_back(name);
		}
		if (opt.mix)
		{
			std::string name = sanitize(stem + " - Full Mix.wav");
			mixWs.open(dir / fs::u8path(name), rate);
			names.push_back(name);
		}
#ifdef REFMIX
		g_refmix = fopen("refmix.raw", "wb");
#endif
		renderPSF(img, total, nullptr, "rendering", [&](size_t f, const float **lr, int ng) {
			float g = fadeGain(f) * (float)volume * gain, ml = 0, mr = 0;
			for (int k = 0; k < ng; ++k)
			{
				float l = lr[k][0] * g, r = lr[k][1] * g;
				ml += l; mr += r;
				if (ws[k].f) ws[k].push(l, r);
			}
			// samples that have not been played yet: silence, so every file starts at 0:00
			for (int k : keep)
				if (k >= ng && ws[k].f) ws[k].push(0, 0);
			if (mixWs.f) mixWs.push(ml, mr);
		}, true);
#ifdef REFMIX
		fclose(g_refmix); g_refmix = nullptr;
#endif
		for (auto &w : ws) w.close();
		mixWs.close();
		out("\r                                \r");
		for (auto &n : names) out("  -> " + n + "\n");
		out(fmt("  %d file(s) saved to: %s\n", (int)names.size(), u8(dir).c_str()));
		return (int)names.size();
	}

	// ---- one stem per SPU voice (--psf-voices)
	// pass 1: levels and which voices are used
	VoiceStats stats[24];
	double peakMix = 0;
	CapCtx cv;
	cv.wantNotes = opt.notes != nullptr;
	renderPSF(img, total, stats, "analyzing", [&](size_t f, const float **lr, int) {
		float g = fadeGain(f) * (float)volume, ml = 0, mr = 0;
		for (int v = 0; v < 24; ++v)
		{
			float l = lr[v][0] * g, r = lr[v][1] * g;
			ml += l; mr += r;
			double a = std::max(std::fabs(l), std::fabs(r));
			if (a > stats[v].peak) stats[v].peak = a;
		}
		peakMix = std::max(peakMix, (double)std::max(std::fabs(ml), std::fabs(mr)));
	}, false, &cv);
	double peak = peakMix;
	for (auto &s : stats) peak = std::max(peak, s.peak);
	if (peak < 1.0)
		throw std::runtime_error("the file produced no sound");
	float gain = 1.0f;
	if (peak > 32000.0)
	{
		gain = (float)(32000.0 / peak);
		out(fmt("\r  level lowered by %.1f dB to avoid clipping (equally for all stems)\n", -20 * std::log10(gain)));
	}
	WavStream ws[24], mixWs;
	std::vector<std::string> names;
	// the driver keys on every voice once with the same dummy sample at start-up: ignore it
	std::map<uint32_t, int> everywhere;
	for (int v = 0; v < 24; ++v)
		for (auto &kv : stats[v].samples)
			if (kv.second == 1) everywhere[kv.first]++;
	for (auto &kv : everywhere)
		if (kv.second == 24)
			for (int v = 0; v < 24; ++v) stats[v].samples.erase(kv.first);
	for (int v = 0; v < 24; ++v)
	{
		if (stats[v].peak * gain < 2.0) continue;
		uint32_t best = 0; int bc = -1;
		for (auto &kv : stats[v].samples) if (kv.second > bc) { bc = kv.second; best = kv.first; }
		std::string key = fmt("Voice %02d (smp %05X%s)", v + 1, best,
			stats[v].samples.size() > 1 ? fmt(" +%d", (int)stats[v].samples.size() - 1).c_str() : "");
		if (opt.notes) (*opt.notes)[key] = cv.notes[v];
		if (opt.analysis) { opt.analysis->push_back({ key }); continue; }
		if (!opt.wants(key)) continue;
		std::string name = sanitize(stem + " - " + key + ".wav");
		ws[v].open(dir / fs::u8path(name), rate);
		names.push_back(name);
	}
	if (opt.analysis) return 0;
	if (opt.mix)
	{
		std::string name = sanitize(stem + " - Full Mix.wav");
		mixWs.open(dir / fs::u8path(name), rate);
		names.push_back(name);
	}
	renderPSF(img, total, nullptr, "rendering", [&](size_t f, const float **lr, int) {
		float g = fadeGain(f) * (float)volume * gain, ml = 0, mr = 0;
		for (int v = 0; v < 24; ++v)
		{
			float l = lr[v][0] * g, r = lr[v][1] * g;
			ml += l; mr += r;
			if (ws[v].f) ws[v].push(l, r);
		}
		if (mixWs.f) mixWs.push(ml, mr);
	});
	for (auto &w : ws) w.close();
	mixWs.close();
	out("\r                                \r");
	for (auto &n : names) out("  -> " + n + "\n");
	out(fmt("  %d file(s) saved to: %s\n", (int)names.size(), u8(dir).c_str()));
	return (int)names.size();
}

} // namespace psfsplit
